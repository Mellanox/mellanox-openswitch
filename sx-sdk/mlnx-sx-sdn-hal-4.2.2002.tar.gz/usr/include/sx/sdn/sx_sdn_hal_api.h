/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_API_H__
#define __SX_SDN_HAL_API_H__

#include <complib/sx_log.h>
#include <sx/sdn/sx_sdn_hal_types.h>


/************************************************
 *  API functions
 ***********************************************/

/**
 * This function initializes SDN HAL.
 *
 * @param[in] profile - SDN HAL system profile
 * @param[in] logging_cb - Optional log messages callback
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_init(const sx_sdn_hal_system_profile_t *profile,
                                    sx_log_cb_t                        logging_cb);

/**
 *  This function de-initializes SDN HAL.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_deinit(void);

/**
 * This function activates SDN HAL.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_activate(void);

/**
 *  This function sets SDN HAL capabilities.
 *
 * @param[in] cap - SDN HAL capabilities.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_capabilities_set(const sx_sdn_hal_capabilities_t *cap);

/**
 *  This function retrieves SDN HAL capabilities.
 *
 * @param[out] cap - SDN HAL capabilities.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_capabilities_get(sx_sdn_hal_capabilities_t *cap);

/**
 * This function sends log messages into SDN HAL.
 *
 * @param[in] severity - Log message severity
 * @param[in] module_name - Module name
 * @param[in] msg - Log message
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_log(sx_log_severity_t severity,
                                   const char *module_name,
                                   char *msg, ...) __attribute__((format(printf, 3, 4)));

#endif /* __SX_SDN_HAL_API_H__ */
