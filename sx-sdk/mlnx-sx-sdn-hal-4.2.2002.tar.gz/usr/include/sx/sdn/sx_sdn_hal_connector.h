/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_CONNECTOR_H__
#define __SX_SDN_HAL_CONNECTOR_H__

#include <complib/sx_log.h>
#include <sx/sdn/sx_sdn_hal_types.h>


/************************************************
 *  Type definitions
 ***********************************************/

typedef enum sx_sdn_hal_conn_config_type {
    SX_SDN_HAL_CONN_CONFIG_TYPE_CONNECTION,
    SX_SDN_HAL_CONN_CONFIG_TYPE_CAPABILITIES,
    SX_SDN_HAL_CONN_CONFIG_TYPE_LOG_LEVEL,

    SX_SDN_HAL_CONN_CONFIG_TYPE_MIN = SX_SDN_HAL_CONN_CONFIG_TYPE_CONNECTION,
    SX_SDN_HAL_CONN_CONFIG_TYPE_MAX = SX_SDN_HAL_CONN_CONFIG_TYPE_LOG_LEVEL,
} sx_sdn_hal_conn_config_type_t;

typedef union sx_sdn_hal_conn_config_msg {
    struct {
        sx_ip_addr_t agent_ip;
        uint16_t     agent_port;
        sx_ip_addr_t controller_ip;
        uint16_t     controller_port;
        uint64_t     datapath_id;
    } connection;
    sx_sdn_hal_capabilities_t capabilities;
    sx_log_level_t            log_level;
} sx_sdn_hal_conn_config_msg_t;

typedef enum sx_sdn_hal_conn_event_type {
    SX_SDN_HAL_CONN_EVENT_TYPE_START = 1 << 0,
        SX_SDN_HAL_CONN_EVENT_TYPE_STOP = 1 << 1,
        SX_SDN_HAL_CONN_EVENT_TYPE_PORT_ENABLE = 1 << 2,
        SX_SDN_HAL_CONN_EVENT_TYPE_PORT_DISABLE = 1 << 3,
        SX_SDN_HAL_CONN_EVENT_TYPE_PROTOCOL = 1 << 4,
} sx_sdn_hal_conn_event_type_t;

typedef union sx_sdn_hal_conn_event_msg {
    struct {
        sx_port_log_id_t      log_port_id;
        uint32_t              ifindex;
        uint32_t              lag_id;
        char                  port_name[SX_SDN_HAL_PORT_NAME_LEN];
        sx_sdn_hal_mac_addr_t hw_addr;
    } port_event;
    struct {
        sx_sdn_hal_command_t             cmd;
        sx_sdn_hal_control_protocol_id_t protocol;
    } protocol_event;
} sx_sdn_hal_conn_event_msg_t;

typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_init_t)(sx_log_cb_t logging_cb);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_init_done_hal_t)(void);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_init_done_shim_t)(void);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_deinit_t)(void);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_config_callback_t)(sx_sdn_hal_conn_config_type_t type,
                                                                 sx_sdn_hal_conn_config_msg_t *data);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_config_callback_register_t)(sx_sdn_hal_conn_config_callback_t callback);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_event_callback_t)(sx_sdn_hal_conn_event_type_t type,
                                                                sx_sdn_hal_conn_event_msg_t *data);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_event_callback_register_t)(sx_sdn_hal_conn_event_callback_t callback,
                                                                         uint32_t                         event_mask);
typedef sx_sdn_hal_status_t (*sx_sdn_hal_conn_config_params_get_t)(sx_sdn_hal_conn_config_type_t type,
                                                                   sx_sdn_hal_conn_config_msg_t *data);
typedef void (*sx_sdn_hal_conn_log_t)(sx_log_severity_t severity, const char *module_name, char *msg);

#endif /* __SX_SDN_HAL_CONNECTOR__ */
