/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_ACL_H__
#define __SXD_EMAD_ACL_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_acl_data.h>

#ifdef SXD_EMAD_ACL_C_

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Defines
 ***********************************************/

#define SXD_ACL_TCAM_REGION_SIZE_BYTES 16
#define SXD_ACL_INFO_SIZE_BYTES        16


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD ACL MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_acl_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                              IN sx_verbosity_level_t *verbosity_level_p);


sxd_status_t sxd_emad_ptar_set(sxd_emad_ptar_data_t *ptar_data_arr, uint32_t ptar_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_ptar_get(sxd_emad_ptar_data_t *ptar_data_arr, uint32_t ptar_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pacl_set(sxd_emad_pacl_data_t *pacl_data_arr, uint32_t pacl_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pacl_get(sxd_emad_pacl_data_t *pacl_data_arr, uint32_t pacl_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_ptce_set(sxd_emad_ptce_data_t *ptce_data_arr, uint32_t ptce_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_ptce_get(sxd_emad_ptce_data_t *ptce_data_arr, uint32_t ptce_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_prcr_set(sxd_emad_prcr_data_t *prcr_data_arr, uint32_t prcr_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_prcr_get(sxd_emad_prcr_data_t *prcr_data_arr, uint32_t prcr_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_ppbt_set(sxd_emad_ppbt_data_t *ppbt_data_arr, uint32_t ppbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_ppbt_get(sxd_emad_ppbt_data_t *ppbt_data_arr, uint32_t ppbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pvbt_set(sxd_emad_pvbt_data_t *pvbt_data_arr, uint32_t pvbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pvbt_get(sxd_emad_pvbt_data_t *pvbt_data_arr, uint32_t pvbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pagt_set(sxd_emad_pagt_data_t *pagt_data_arr, uint32_t pagt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pagt_get(sxd_emad_pagt_data_t *pagt_data_arr, uint32_t pagt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pprr_set(sxd_emad_pprr_data_t *pprr_data_arr, uint32_t pprr_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pprr_get(sxd_emad_pprr_data_t *pprr_data_arr, uint32_t pprr_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pvgt_set(sxd_emad_pvgt_data_t *pvgt_data_arr, uint32_t pvgt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


sxd_status_t sxd_emad_pvgt_get(sxd_emad_pvgt_data_t *pvgt_data_arr, uint32_t pvgt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pgcr_set(sxd_emad_pgcr_data_t *pgcr_data_arr, uint32_t pgcr_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pgcr_get(sxd_emad_pgcr_data_t *pgcr_data_arr, uint32_t pgcr_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_ppbs_set(sxd_emad_ppbs_data_t *ppbs_data_arr, uint32_t ppbs_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_ppbs_get(sxd_emad_ppbs_data_t *ppbs_data_arr, uint32_t ppbs_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_puet_set(sxd_emad_puet_data_t *puet_data_arr, uint32_t puet_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_puet_get(sxd_emad_puet_data_t *puet_data_arr, uint32_t puet_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_ptce2_set(sxd_emad_ptce2_data_t *ptce2_data_arr, uint32_t ptce2_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_ptce2_get(sxd_emad_ptce2_data_t *ptce_data_arr, uint32_t ptce2_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pefa_set(sxd_emad_pefa_data_t *pefa_data_arr, uint32_t pefa_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pefa_get(sxd_emad_pefa_data_t *pefa_data_arr, uint32_t pefa_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_prbt_set(sxd_emad_prbt_data_t *prbt_data_arr, uint32_t prbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_prbt_get(sxd_emad_prbt_data_t *prbt_data_arr, uint32_t prbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pecb_set(sxd_emad_pecb_data_t *pecb_data_arr, uint32_t pefa_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pecb_get(sxd_emad_pecb_data_t *pecb_data_arr, uint32_t pefa_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pemb_set(sxd_emad_pemb_data_t *pemb_data_arr, uint32_t prbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);

sxd_status_t sxd_emad_pemb_get(sxd_emad_pemb_data_t *pemb_data_arr, uint32_t prbt_data_num,
                               sxd_emad_completion_handler_t handler, void *context);


#endif /* __SXD_EMAD_ACL_H__ */
