/*
 *                  - Mellanox Confidential and Proprietary -
 *
 *  Copyright (C) January 2010, Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
 *
 *  Except as specifically permitted herein, no portion of the information,
 *  including but not limited to object code and source code, may be reproduced,
 *  modified, distributed, republished or otherwise exploited in any form or by
 *  any means for any purpose without the prior written permission of Mellanox
 *  Technologies Ltd. Use of software subject to the terms and conditions
 *  detailed in the file "LICENSE.txt".
 *
 */

#ifndef __SXD_EMAD_REDECN_H__
#define __SXD_EMAD_REDECN_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_redecn_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD REDECN MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_redecn_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwgcr_set(sxd_emad_cwgcr_data_t        *cwgcr_data_arr,
                                uint32_t                      cwgcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_tqpdp_data_num
 */
sxd_status_t sxd_emad_cwgcr_get(sxd_emad_cwgcr_data_t        *cwgcr_data_arr,
                                uint32_t                      cwgcr_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwtp_set(sxd_emad_cwtp_data_t         *cwtp_data_arr,
                               uint32_t                      cwtp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwtp_get(sxd_emad_cwtp_data_t         *cwtp_data_arr,
                               uint32_t                      cwtp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwtpm_set(sxd_emad_cwtpm_data_t        *cwtpm_data_arr,
                                uint32_t                      cwtpm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwtpm_get(sxd_emad_cwtpm_data_t        *cwtpm_data_arr,
                                uint32_t                      cwtpm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwpp_set(sxd_emad_cwpp_data_t         *cwpp_data_arr,
                               uint32_t                      cwpp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwpp_get(sxd_emad_cwpp_data_t         *cwpp_data_arr,
                               uint32_t                      cwpp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwppm_set(sxd_emad_cwppm_data_t        *cwppm_data_arr,
                                uint32_t                      cwppm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cwppm_get(sxd_emad_cwppm_data_t        *cwppm_data_arr,
                                uint32_t                      cwppm_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cpqe_set(sxd_emad_cpqe_data_t         *cpqe_data_arr,
                               uint32_t                      cpqe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_cpqe_get(sxd_emad_cpqe_data_t         *cpqe_data_arr,
                               uint32_t                      cpqe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);
#endif /* __SXD_EMAD_COS_H__ */
