/*
 * Copyright (c) 2014 Mellanox, LTD. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/errno.h>
#include <linux/etherdevice.h>
#include <linux/string.h>
#include <linux/spinlock.h>
#include <linux/netdevice.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/tcp.h>
#include <linux/ip.h>
#include <linux/icmp.h>
#include <net/ip.h>
#include <linux/vmalloc.h>
#include <linux/if_ether.h>
#include <linux/if_vlan.h>
#include <linux/rtnetlink.h>

#include <linux/mlx_sx/cmd.h>
#include <linux/mlx_sx/device.h>
#include <linux/mlx_sx/driver.h>
#include <linux/mlx_sx/cmd.h>
#include <linux/mlx_sx/kernel_user.h>
#include "sx_netdev.h"

MODULE_AUTHOR("Amos Hersch");
MODULE_DESCRIPTION("Mellanox SwitchX Network Device Driver");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_VERSION(DRV_VERSION);

static char sx_netdev_version[] =
	PFX "Mellanox SwitchX Network Device Driver "
	DRV_VERSION " (" DRV_RELDATE ")\n";

static struct net_device *lag_rp_netdev_db[MAX_LAG_NUM];
static struct net_device *port_rp_netdev_db[MAX_SYSPORT_NUM];
struct net_device *port_l2_netdev_db[MAX_SYSPORT_NUM];
struct net_device *lag_l2_netdev_db[MAX_LAG_NUM];
struct sx_netdev_rsc *g_netdev_resources = NULL;  /* Should be replaced in the core with sx_dev context */
struct sx_dev* g_sx_dev = NULL;
struct net_device *bridge_netdev_db[MAX_BRIDGE_NUM];

u64 sx_netdev_mac_to_u64(u8 *addr)
{
	u64 mac = 0;
	int i;

	for (i = 0; i < ETH_ALEN; i++) {
		mac <<= 8;
		mac |= addr[i];
	}
	return mac;
}

void sx_netdev_u64_to_mac(u8* addr, u64 mac)
{
	int i;

	for (i = ETH_ALEN - 1; i >= 0; i--) {
		addr[i] = (u8)(mac & 0xFF);
		mac >>= 8;
	}
}

/*
 * NETDEV is loaded with admin state down. User can change the admin state to UP and not the driver
 *
static void netdev_adminstate_set(struct net_device *netdev, int should_rtnl_lock)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	if (should_rtnl_lock)
		rtnl_lock();

	if (net_priv->admin_state) {
		dev_change_flags(netdev, netdev->flags | IFF_UP);
	} else {
		dev_change_flags(netdev, netdev->flags & ~IFF_UP);
	}

	if (should_rtnl_lock)
		rtnl_unlock();
}
*/

static void netdev_linkstate_set(struct net_device *netdev)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	if (net_priv->is_oper_state_up) {
		netif_carrier_on(netdev);
		netif_start_queue(netdev);
	}
	else {
		netif_tx_disable(netdev);
		netif_carrier_off(netdev);
	}
}

static void sx_netdev_fix_sx_skb(struct completion_info *comp_info, struct sk_buff *skb,
                                 struct net_device *netdev)
{
	struct ethhdr *eth_h = (struct ethhdr *)(skb->data);


	if (comp_info->hw_synd == ETH_L3_MTUERROR_TRAP_ID) {
		struct iphdr *ipptr;
		u32 new_checksum;
		u16 old_frag_off;

		if (be16_to_cpu(eth_h->h_proto) == ETH_P_8021Q) {
			ipptr = (struct iphdr *)(skb->data + VLAN_ETH_HLEN);
		} else
			ipptr = (struct iphdr *)(skb->data + ETH_HLEN);

		/* RFC 1624 describes how to recalculate the checksum via incremental update */
		old_frag_off = be16_to_cpu(ipptr->frag_off); /* save old flags */
		if (!(old_frag_off & 0x4000)) { /* If don't fragment bit is not set */
			ipptr->frag_off = cpu_to_be16(old_frag_off | 0x4000); /* set DF bit */
			/* calculate the new checksum */
			new_checksum = (~old_frag_off & 0xffff) + (be16_to_cpu(ipptr->frag_off) & 0xffff); /* hc' = ~m+m' */
			new_checksum += (~be16_to_cpu(ipptr->check) & 0xffff); /* hc' += ~hc */
			new_checksum = (new_checksum & 0xffff) + (new_checksum >> 16); /* Add carry if such exists */
			ipptr->check = cpu_to_be16(~(new_checksum + (new_checksum >> 16))); /* hc' = ~hc' */
		}
	}
	else if (comp_info->hw_synd == ETH_L3_LBERROR_TRAP_ID) {
	    memcpy(eth_h->h_dest, netdev->dev_addr, netdev->addr_len);
	}

	skb->dev = netdev;
	skb->protocol = eth_type_trans(skb, netdev);
	skb->ip_summed = CHECKSUM_UNNECESSARY; /* don't check it */
}


static void sx_netdev_l2_rx_pkt(struct completion_info *comp_info, void *context)
{
	/* Get routed netdev */
	struct sx_net_priv *net_priv = NULL;
	struct net_device *netdev =  NULL;
	struct sk_buff *skb;

	if (comp_info->is_lag) {
	    /* on CQE the LAG ID is shifted 4 bits [15:4] */
	    netdev = lag_l2_netdev_db[(comp_info->sysport >> 4)];
	}
	else {
	    netdev = port_l2_netdev_db[comp_info->sysport];
	}
	if ((netdev == NULL) || ((netdev->flags & IFF_UP) == 0)) {
		/* netdev is down or not exists */
		return;
	}

	net_priv = netdev_priv(netdev);

	/* TODO! Should we check untagged VLAN packets and add their VIDs? */
	/* In the meanwhile, we are going to just duplicate the SKB */
	skb_get(comp_info->skb);
	skb = skb_copy(comp_info->skb, GFP_ATOMIC);
	kfree_skb(comp_info->skb);
	if (!skb) {
		net_priv->stats.rx_dropped++;
		return;
	}

	sx_netdev_fix_sx_skb(comp_info, skb, netdev);

	net_priv->stats.rx_packets++;
	net_priv->stats.rx_bytes += skb->len;

	netif_rx(skb);
}

static void sx_netdev_handle_rx_pkt(struct completion_info *comp_info, void *context)
{
	struct net_device *netdev = context;
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	struct sk_buff *skb = comp_info->skb;
	u8 is_tagged = comp_info->is_tagged;
	u16 vid = comp_info->vid;
	struct ethhdr *eth_h = NULL;
	struct vlan_hdr *vhdr = NULL;
	struct net_device *vlan_netdev = NULL;
	u16 dev_vlan_id = 0;

	eth_h = (struct ethhdr *) (skb->data);
	if (be16_to_cpu(eth_h->h_proto) == ETH_P_8021Q) {
		vhdr = (struct vlan_hdr *) (skb->data + ETH_HLEN);
		dev_vlan_id = be16_to_cpu(vhdr->h_vlan_TCI) & 0xFFF;
	} else {
		dev_vlan_id = vid;
	}

	if (net_priv != NULL && net_priv->vlgrp != NULL) {
		/* check if VLAN interface is DOWN , drop the packets */
		vlan_netdev = vlan_group_get_device(net_priv->vlgrp, dev_vlan_id);
		if (vlan_netdev != NULL && !(vlan_netdev->flags & IFF_UP)) {
			return;
		}
	}

	skb_get(skb);
	if (!is_tagged && net_priv->vlgrp) {
		/* We can't use vlan_hwaccel_rx since it calls netif_nit_deliver which causes an oops
		when not using NAPI. Therefore we add the vlan tag.
		printk(KERN_DEBUG PFX "sx_netdev_handle_rx_pkt: vlgrp is not NULL, vid = %u. calling vlan_hwaccel_rx\n", vid);
		vlan_hwaccel_rx(skb, net_priv->vlgrp, vid);
		 */
		struct sk_buff *old_skb = skb;
		u8 *p_skb_data;
		u32 vlan_tag = ETH_P_8021Q << 16;
		vlan_tag |= (vid & 0x3fff);

		skb = alloc_skb(old_skb->len + 4, GFP_ATOMIC);
		if (!skb) {
			net_priv->stats.rx_dropped++;
			kfree_skb(old_skb);
			return;
		}

		p_skb_data = skb_put(skb, old_skb->len + 4);
		if (!p_skb_data) {
			net_priv->stats.rx_dropped++;
			kfree_skb(old_skb);
			kfree_skb(skb);
			return;
		}

		vlan_tag = cpu_to_be32(vlan_tag);
		memcpy(p_skb_data, old_skb->data, 12);
		memcpy(p_skb_data + 12, &vlan_tag, 4);
		memcpy(p_skb_data + 16, old_skb->data + 12, old_skb->len - 12);
		kfree_skb(old_skb);
	} else {
		struct sk_buff *new_skb = skb_copy(skb, GFP_ATOMIC);

		kfree_skb(skb);
		if (!new_skb) {
			net_priv->stats.rx_dropped++;
			return;
		}

		skb = new_skb;
	}

	sx_netdev_fix_sx_skb(comp_info, skb, netdev);

	net_priv->stats.rx_packets++;
	net_priv->stats.rx_bytes += skb->len;

	netif_rx(skb);

	return;
}

/* Called on every PUDE event */
static void sx_netdev_handle_pude_event(struct completion_info *comp_info, void *context)
{
	struct net_device *netdev = NULL;
	struct sxd_emad_pude_reg* pude = (struct sxd_emad_pude_reg *)comp_info->skb->data;
	struct sx_emad *emad_header = &pude->emad_header;
	struct sx_net_priv *net_priv;
	int reg_id = be16_to_cpu(emad_header->emad_op.register_id);
	unsigned int logical_port;
	int sysport;
	int is_up, is_lag;

	if ((comp_info->info.eth.ethtype != ETHTYPE_EMAD) || (reg_id != PUDE_REG_ID) ||
	    ((pude->tlv_header.type >> EMAD_TLV_TYPE_SHIFT) != TLV_TYPE_REG_E) ||
	    (pude->tlv_header.len != 4)) {
		printk("%s: Called wrongly with ethtype = %04X and reg-id = %04X, type = %d, len = %d\n",
			__func__, comp_info->info.eth.ethtype, reg_id, pude->tlv_header.type, pude->tlv_header.len);
		return;
	}

	logical_port = 0x10000 + (pude->local_port << SX_PORT_PHY_ID_OFFS);
	sysport = translate_user_port_to_sysport(g_sx_dev, logical_port, &is_lag);
	/* if port is a LAG port do nothing */
	if (is_lag) {
	    return;
    }
	is_up = pude->oper_status == PORT_OPER_STATUS_UP;
	netdev = port_l2_netdev_db[sysport];

	printk("%s: Called for logical port - %05X status %s\n", __func__,
		logical_port, is_up ? "UP" : "DOWN");

	/* Change port status for L2 netdev per port */
	if (netdev) {
		net_priv = netdev_priv(netdev);
		net_priv->is_oper_state_up = is_up;
		netdev_linkstate_set(netdev);
	}
}

static void sx_netdev_remove_vlan_header(struct sk_buff *skb)
{
    struct vlan_ethhdr *veth = NULL;
    veth = (struct vlan_ethhdr *)(skb->data);

    if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q) {
        /* No vlan header */
        return;
    }

    /* set the protocol in ETH header */
    veth->h_vlan_proto = veth->h_vlan_encapsulated_proto;

    /* remove the VLAN header */
    memmove(skb->data + VLAN_HLEN, skb->data, ETH_HLEN);
    skb->mac_header += VLAN_HLEN;
    skb_pull(skb, VLAN_HLEN);

    skb_reset_network_header(skb);
    skb_reset_transport_header(skb);
    /* skb_reset_mac_len */
    skb->mac_len = skb->network_header - skb->mac_header;

}

static void sx_netdev_handle_global_pkt(struct completion_info *comp_info,
					void *context)
{
	struct net_device *netdev = NULL;
	int err = 0;
	u16 vlan = 0;

	if (comp_info->bridge_id) {
	    if (comp_info->bridge_id < MIN_BRIDGE_ID
	            || comp_info->bridge_id > MAX_BRIDGE_ID) {
	        printk(KERN_ERR PFX "Bridge ID %u is out of range [%u,%u]\n",
	               comp_info->bridge_id, MIN_BRIDGE_ID, MAX_BRIDGE_ID);
	        return;
	    }
	    netdev = bridge_netdev_db[comp_info->bridge_id - MIN_BRIDGE_ID];

	    sx_netdev_remove_vlan_header(comp_info->skb);
	}
	else if (comp_info->is_lag){
		u16 lag_id = (comp_info->sysport >> 4) & 0xfff;
		netdev = lag_rp_netdev_db[lag_id];
	}
	else {
		netdev = port_rp_netdev_db[comp_info->sysport];
	}

	/* if RP netdev existed than pass the packet up with this netdev */
	if (netdev && (netdev->flags & IFF_UP)){
		struct sx_net_priv *net_priv = netdev_priv(netdev);
		err = sx_core_get_rp_vlan(net_priv->dev, comp_info, &vlan);
		if (err) {
			printk(KERN_ERR PFX "Failed sx_core_get_rp_vlan(). err: %d \n",err);
		}
		comp_info->vid = vlan;
		sx_netdev_handle_rx_pkt(comp_info, netdev);
	}
}

static int sx_netdev_register_global_event_handler(void)
{
	int err = 0;
	union ku_filter_critireas crit;

	/* Register listener for Ethernet SWID */
	memset(&crit, 0, sizeof(crit));

	err = sx_core_add_synd(ROUTER_PORT_SWID, NUM_HW_SYNDROMES, L2_TYPE_DONT_CARE, 0,
	                       crit, sx_netdev_handle_global_pkt, NULL,
	                       CHECK_DUP_DISABLED_E, NULL);
	if (err) {
		printk(KERN_ERR PFX "%s: Failed registering global rx_handler", __func__);
		return err;
	}
    err = sx_core_add_synd(0, SX_TRAP_ID_PUDE, L2_TYPE_DONT_CARE, 0,
                           crit, sx_netdev_handle_pude_event, NULL,
                           CHECK_DUP_DISABLED_E, NULL);
    if (err) {
        printk(KERN_ERR PFX "%s: Failed registering PUDE event rx_handler", __func__);
        return err;
    }

	return 0;
}

static int sx_netdev_unregister_global_event_handler(void)
{
	int err = 0;
	union ku_filter_critireas crit;

	memset(&crit, 0, sizeof(crit));
	sx_core_remove_synd(ROUTER_PORT_SWID, NUM_HW_SYNDROMES, L2_TYPE_DONT_CARE, 0,
	                    crit, NULL, NULL);
	if (err) {
		printk(KERN_ERR PFX "error: Failed deregistering on "
				"0x%x syndrome.\n", NUM_HW_SYNDROMES);
		return err;
	}

    sx_core_remove_synd(0, SX_TRAP_ID_PUDE, L2_TYPE_DONT_CARE, 0,
                        crit, NULL, NULL);
    if (err) {
        printk(KERN_ERR PFX "error: Failed deregistering on "
                "0x%x syndrome.\n", SX_TRAP_ID_PUDE);
        return err;
    }

    sx_core_flush_synd_by_handler(sx_netdev_handle_global_pkt);

	return err;
}

static int sx_netdev_open(struct net_device *netdev)
{
	int err = 0;
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	union ku_filter_critireas crit;
	int i;

	printk(KERN_INFO PFX "%s: called\n", __func__);

	if ((netdev->dev_addr[0] == 0) && (netdev->dev_addr[1] == 0) &&
	(netdev->dev_addr[2] == 0) && (netdev->dev_addr[3] == 0) &&
	(netdev->dev_addr[4] == 0) && (netdev->dev_addr[5] == 0)) {
		printk(KERN_ERR PFX "error %s, no mac address set.\n",
				netdev->name);
		return -EINVAL;
	}

	netdev_linkstate_set(netdev);

	/* register the listener according to the swid */
	memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
	crit.eth.from_rp = IS_RP_NOT_FROM_RP_E;
	crit.eth.from_bridge = IS_BRIDGE_NOT_FROM_BRIDGE_E;

	for (i = 0; i < net_priv->num_of_traps[L3_NETDEV]; i++) {
		/* TODO - should we filter according to dmac? */
		err = sx_core_add_synd(net_priv->swid, net_priv->trap_ids[L3_NETDEV][i], L2_TYPE_ETH, 0,
				crit, sx_netdev_handle_rx_pkt, netdev, 
				CHECK_DUP_DISABLED_E, net_priv->dev);
		if (err) {
			printk(KERN_ERR PFX "error %s, L3 Failed registering on "
					"0x%x syndrome.\n", netdev->name, net_priv->trap_ids[L3_NETDEV][i]);
			goto out;
		}
	}

	memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
	crit.eth.from_rp = IS_RP_DONT_CARE_E;
	crit.eth.from_bridge = IS_BRIDGE_DONT_CARE_E;

	for (i = 0; i <net_priv->num_of_traps[L2_NETDEV]; i++) {
		/* TODO - should we filter according to dmac? */
		err = sx_core_add_synd(net_priv->swid, net_priv->trap_ids[L2_NETDEV][i], L2_TYPE_ETH, 0,
				crit, sx_netdev_l2_rx_pkt, netdev,
				CHECK_DUP_DISABLED_E, net_priv->dev);
		if (err) {
			printk(KERN_ERR PFX "error %s, L2 Failed registering on "
					"0x%x syndrome.\n", netdev->name, net_priv->trap_ids[L2_NETDEV][i]);
			goto out;
		}
	}

out:
	printk(KERN_INFO PFX "%s: exit\n", __func__);
	return err;
}

static int sx_netdev_stop(struct net_device *netdev)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	union ku_filter_critireas crit;
	int i;

	printk(KERN_INFO PFX "%s: called\n", __func__);

	/* unregister the listener according to the swid */
	memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
	crit.eth.from_rp = IS_RP_NOT_FROM_RP_E;
	crit.eth.from_bridge = IS_BRIDGE_NOT_FROM_BRIDGE_E;

	for (i = 0; i < net_priv->num_of_traps[L3_NETDEV]; i++)
		sx_core_remove_synd(net_priv->swid, net_priv->trap_ids[L3_NETDEV][i], L2_TYPE_ETH, 0,
				crit, netdev, net_priv->dev);

	memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
	crit.eth.from_rp = IS_RP_DONT_CARE_E;
	crit.eth.from_bridge = IS_BRIDGE_DONT_CARE_E;

	for (i = 0; i < net_priv->num_of_traps[L2_NETDEV]; i++)
		sx_core_remove_synd(net_priv->swid, net_priv->trap_ids[L2_NETDEV][i], L2_TYPE_ETH, 0,
				crit, netdev, net_priv->dev);

	netif_tx_disable(netdev);
	netif_carrier_off(netdev);

	printk(KERN_INFO PFX "%s: exit\n", __func__);
	return 0;
}

static int sx_netdev_get_rp_prio_to_tc(struct net_device *netdev,
                                       struct sk_buff *skb, uint8_t *tc)
{
    struct sx_net_priv *net_priv = netdev_priv(netdev);
    uint8_t pcp;
    u16 vlan_tci;
    struct vlan_ethhdr *veth = NULL;
    int err = 0;

    *tc = 0;

    veth = (struct vlan_ethhdr *)(skb->data);
    if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q){
        /* We can reach this case if pkt was sent from phys. port netdev */
#ifdef SX_DEBUG_RP
        printk(KERN_DEBUG PFX "VETH proto (0x%x) is not ETH_P_8021Q !\n",
               veth->h_vlan_proto);
#endif
        *tc = SX_PACKET_DEFAULT_TC;
        return 0;
    }

    vlan_tci = ntohs(veth->h_vlan_TCI);
    pcp = (vlan_tci & SX_VLAN_PRIO_MASK) >> SX_VLAN_PRIO_SHIFT;

    err = sx_core_get_prio2tc(net_priv->dev,
                  net_priv->port, net_priv->is_lag, pcp, tc);

    return err;
}

static int sx_netdev_set_vlan_according_hw(struct net_device *netdev,
                                       struct sk_buff *skb)
{
    struct sx_net_priv *net_priv = netdev_priv(netdev);
    uint16_t vlan;
    uint8_t is_tagged, is_prio_tagged;
    struct vlan_ethhdr *veth = NULL;
    int err = 0;

    veth = (struct vlan_ethhdr *)(skb->data);
    if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q){
        /* We can reach this case if pkt was sent from phys. port netdev */
#ifdef SX_DEBUG_RP
        printk(KERN_DEBUG PFX "VETH proto (0x%x) is not ETH_P_8021Q !\n",
               veth->h_vlan_proto);
#endif
        return 0;
    }

    vlan = ntohs(veth->h_vlan_TCI) & VLAN_VID_MASK;
    if (vlan > 4094){
        printk(KERN_ERR PFX "VETH vlan (%d) is very big . MAX: %d !\n",
               vlan, 4094);
        return -EINVAL;
    }

    err = sx_core_get_vlan_tagging(net_priv->dev,
                   net_priv->port, net_priv->is_lag, vlan, &is_tagged);
    if (err){
       printk(KERN_ERR PFX "sx_core_get_vlan_tagging is failed. err: %d\n", err);
       return err;
    }

    err = sx_core_get_prio_tagging(net_priv->dev,
                   net_priv->port, net_priv->is_lag, &is_prio_tagged);
    if (err){
       printk(KERN_ERR PFX "sx_core_get_prio_tagging is failed. err: %d\n", err);
       return err;
    }

#ifdef SX_DEBUG_RP
    printk(KERN_ERR PFX "VETH is_lag:%d, port:0x%x, vlan:%d, is_vtag:%d, is_prio_tag:%d  \n",
           net_priv->is_lag, net_priv->port, vlan,is_tagged,is_prio_tagged );
#endif

    /*
     * If port is VLAN tagged than send the packet with TAG
     * Else if port is Prio-tagged send the packet with Prio tag ( zero the VLAN id)
     * Else send packet untagged
     */
    if (!is_tagged && is_prio_tagged){
        /* port is PRIO tagged (but not VLAN tagged) than ssend the packet prio tagged */
        veth->h_vlan_TCI &= ~(htons(VLAN_VID_MASK));
#ifdef SX_DEBUG_RP
        printk(KERN_ERR PFX "Pkt isnot vtag but prio tag , clear the vlan : vlan_tci:0x%x \n",
               veth->h_vlan_TCI);
#endif
    }
    else if (!is_tagged && !is_prio_tagged){
#ifdef SX_DEBUG_RP
        printk(KERN_ERR PFX "Pkt isnot vtag and not prio tag , rem. vlan hdr \n");
#endif
        /* send the packet untagged */
        sx_netdev_remove_vlan_header(skb);
    }
#ifdef SX_DEBUG_RP
    else{
        printk(KERN_ERR PFX "Pkt is vlan tagged. do nothing !\n");
    }
    /* else port is VLAN tagged and send the packet as is */
#endif

    return 0;
}


static int sx_netdev_override_icmp_ip(struct net_device *netdev,
                                  struct sk_buff *skb)
{
    struct sx_net_priv *net_priv = netdev_priv(netdev);
    uint16_t vlan;
    struct vlan_ethhdr *veth = NULL;
    int err = 0;
    uint32_t ip_addr;
    struct iphdr* iph = NULL;
    struct icmphdr* icmph = NULL;


    veth = (struct vlan_ethhdr *)(skb->data);
    if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q){
        /* We can reach this case if pkt was sent from phys. port netdev */
#ifdef SX_DEBUG_RP
        printk(KERN_DEBUG PFX "VETH proto (0x%x) is not ETH_P_8021Q !\n",
               veth->h_vlan_proto);
#endif
        return 0;
    }

    /* is packet icmp type 5 */

    vlan = ntohs(veth->h_vlan_TCI) & VLAN_VID_MASK;
    if (vlan > 4094){
        printk(KERN_ERR PFX "VETH vlan (%d) is very big . MAX: %d !\n",
                       vlan, 4094);
        return -EINVAL;
    }

    err = sx_core_get_vlan2ip(net_priv->dev, vlan, &ip_addr);
    if (err){
       printk(KERN_ERR PFX "sx_core_get_vlan2ip is failed. err: %d\n", err);
       return err;
    }

    if (ip_addr == 0){
        return 0;
    }

    iph = (struct iphdr*)(skb->data + sizeof(struct vlan_ethhdr));
    if (iph->protocol != IPPROTO_ICMP){
        return 0;
    }

    icmph = (struct icmphdr *)skb_transport_header(skb);
    if (icmph->type != ICMP_REDIRECT){
        return 0;
    }

    /* override SIP with DB IP */
    iph->saddr = htonl(ip_addr);

    /* recalc csum */
    ip_send_check(iph);

    return 0;
}

static int sx_netdev_skb_add_vlan(struct sk_buff *old_skb,
                                  struct sk_buff **new_skb_p,
                                  uint16_t vlan)
{
    struct vlan_ethhdr *veth = NULL;
    u8 *p_skb_data;
    u32 vlan_tag;
    struct sk_buff *new_skb = NULL;

    *new_skb_p = NULL;

    /* If no vlan header - add empty vlan header */
    veth = (struct vlan_ethhdr *)(old_skb->data);
    if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q) {
        new_skb = alloc_skb(old_skb->len + 4 + ISX_HDR_SIZE, GFP_ATOMIC);
        if (!new_skb) {
            printk(KERN_ERR PFX "sx_netdev_skb_add_vlan new_skb alloc failed\n");
            return -ENOMEM;
        }

        skb_reserve(new_skb, ISX_HDR_SIZE);

        p_skb_data = skb_put(new_skb, old_skb->len + 4);
        if (!p_skb_data) {
            kfree_skb(new_skb);
            return -ENOMEM;
        }

        vlan_tag = ETH_P_8021Q << 16;
        vlan_tag |= (vlan & 0x3fff);
        vlan_tag = cpu_to_be32(vlan_tag);
        memcpy(p_skb_data, old_skb->data, 12);
        memcpy(p_skb_data + 12, &vlan_tag, 4);
        memcpy(p_skb_data + 16, old_skb->data + 12, old_skb->len - 12);
        *new_skb_p = new_skb;
    }

    return 0;
}

static int sx_netdev_hard_start_xmit(struct sk_buff *skb, struct net_device *netdev)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	int err;
	int len = 0;
	struct isx_meta meta;
	struct sk_buff *tmp_skb = NULL;
	uint8_t tc;
	uint16_t rif_id = 0;
	uint16_t vlan = 0;
    struct vlan_ethhdr *veth = NULL;

    sx_netdev_override_icmp_ip(netdev, skb);

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "sx_netdev_hard_start_xmit\n");
#endif
	netdev->trans_start = jiffies; /* save the timestamp */

	memset(&meta, 0, sizeof(meta));
	meta.dev_id = net_priv->dev->device_id;
	meta.lp = 0;
	meta.rdq = 0;
	meta.swid = net_priv->swid;
	meta.to_cpu = 0;

	if (net_priv->is_bridge) {

	    meta.type = SX_PKT_TYPE_ETH_DATA;
        meta.rx_is_router = 0;
        meta.fid_valid = 1;
        meta.fid = net_priv->bridge_id;

        /* If no vlan header - add empty vlan header */
        veth = (struct vlan_ethhdr *)(skb->data);
        if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q) {
            /* this func add vlan header in case packet sent untagged */
            err = sx_netdev_skb_add_vlan(skb, &tmp_skb, 1);
            if (err) {
                if (printk_ratelimit())
                    printk(KERN_ERR PFX "sx_netdev_hard_start_"
                            "xmit: Err: alloc skb with vlan heasder\n");
                net_priv->stats.tx_dropped++;
                kfree_skb(skb);
                return err;
            }
            kfree_skb(skb);
            skb = tmp_skb;
        }

	} else if (!net_priv->is_port_netdev && !net_priv->is_l2_port) {
	    /* swid0_eth */

		meta.system_port_mid = 0;
		meta.type = SX_PKT_TYPE_ETH_DATA;
		meta.etclass = SX_PACKET_DEFAULT_TC; /* High priority */

	} else if (net_priv->send_to_rp_as_data_supported == false ||
	        net_priv->is_l2_port) {
	    /*
	     * SwitchX : RP port / RP LAG
	     * SwitchX / Spectrum:  L2 port / L2 LAG
	     */

		meta.system_port_mid =
				(net_priv->is_lag ? net_priv->mid : net_priv->port );

		meta.type = SX_PKT_TYPE_ETH_CTL_UC;

		err = sx_netdev_get_rp_prio_to_tc(netdev, skb, &tc);
		if (err) {
		    if (printk_ratelimit())
                printk(KERN_ERR PFX "sx_netdev_hard_start_"
                        "xmit: Err: can't get prio to tc\n");
            net_priv->stats.tx_dropped++;
            kfree_skb(skb);
            return err;
		}
		meta.etclass = tc; /* High priority */

		err = sx_netdev_set_vlan_according_hw(netdev, skb);
        if (err) {
            if (printk_ratelimit())
                printk(KERN_ERR PFX "sx_netdev_hard_start_"
                        "xmit: Err: can't set vlan according hw.\n");
            net_priv->stats.tx_dropped++;
            kfree_skb(skb);
            return err;
        }
	}
	else { /* net_priv->send_to_rp_as_data_supported == true */
	    /*
	     * Spc: RP
	     */
	    meta.type = SX_PKT_TYPE_ETH_DATA;
	    meta.rx_is_router = 1;
	    meta.fid_valid = 1;

	    /* this func add vlan header in case packet sent untagged */
	    /* If no vlan header - add empty vlan header */
        veth = (struct vlan_ethhdr *)(skb->data);

        /* if no VLAN hdr add one */
        if (ntohs(veth->h_vlan_proto) != ETH_P_8021Q) {
            /* using VLAN 0 for next flow when will be replced by PVID */
            err = sx_netdev_skb_add_vlan(skb, &tmp_skb, 0);
            if (err) {
                if (printk_ratelimit())
                    printk(KERN_ERR PFX "sx_netdev_hard_start_"
                            "xmit: Err: alloc skb with vlan heasder\n");
                kfree_skb(skb);
                net_priv->stats.tx_dropped++;
                return err;
            }
            kfree_skb(skb);
            skb = tmp_skb;
        }

        /* extract VLAN from VLAN header */
	    if (ntohs(veth->h_vlan_proto) == ETH_P_8021Q) {
	        vlan = ntohs(veth->h_vlan_TCI) & VLAN_VID_MASK;
	        if (vlan > 4094){
	            printk(KERN_ERR PFX "VETH vlan (%d) is very big . MAX: %d !\n",
	                   vlan, 4094);
	            net_priv->stats.tx_dropped++;
	            kfree_skb(skb);
	            return -EINVAL;
	        }
	    }

	    /* if no vlan header or vlan = 0, get port default vlan (pvid) */
	    if (vlan == 0) {
	        err = sx_core_get_pvid(net_priv->dev, net_priv->port,
	                               net_priv->is_lag, &vlan);
	        if (err) {
	            if (printk_ratelimit())
	                printk(KERN_ERR PFX "sx_netdev_hard_start_xmit: "
	                        "Err: can't get pvid for port\n");
	            net_priv->stats.tx_dropped++;
	            kfree_skb(skb);
	            return err;
	        }

	        if (ntohs(veth->h_vlan_proto) == ETH_P_8021Q) {
	            veth->h_vlan_TCI = (veth->h_vlan_TCI & htons(~VLAN_VID_MASK)) | htons(vlan);
	        }
	    }

	    err = sx_core_get_rp_rif_id(net_priv->dev,
	                  net_priv->port, net_priv->is_lag, vlan, &rif_id);
        if (err) {
            if (printk_ratelimit())
                printk(KERN_ERR PFX "sx_netdev_hard_start_xmit: "
                        "Err: can't get rp rif\n");
            net_priv->stats.tx_dropped++;
            kfree_skb(skb);
            return err;
        }

        meta.fid = rif_id + TX_HEADER_RP_RIF_TO_FID;
	}

	/* If there's no place for the ISX header
	 * need to alloc a new skb and use it instead */
	tmp_skb = skb;
    len = skb->len;
	if (skb_headroom(skb) < ISX_HDR_SIZE) {
#ifdef SX_DEBUG
		printk(KERN_INFO PFX "sx_netdev_hard_start_xmit: "
				"No place for the ISX header, allocating a new "
				"SKB\n");
#endif
		tmp_skb = alloc_skb(ISX_HDR_SIZE + len, GFP_ATOMIC);
		if (!tmp_skb) {
			if (printk_ratelimit())
				printk(KERN_ERR PFX "sx_netdev_hard_start_"
						"xmit: Err: failed allocating "
						"SKB\n");
			net_priv->stats.tx_dropped++;
			kfree_skb(skb);
			return -ENOMEM;
		}

		skb_reserve(tmp_skb, ISX_HDR_SIZE);
		memcpy(skb_put(tmp_skb, len), skb->data, len);
		kfree_skb(skb);
		len += ISX_HDR_SIZE;
	}

	err = sx_core_post_send(net_priv->dev, tmp_skb, &meta);
	if (err) {
		printk(KERN_ERR PFX "error %s, Failed sending packet\n",
				netdev->name);
		net_priv->stats.tx_dropped++;
		/*
		   We don't free the packet because sx_core_post_send free the packet in case of an error.
		   We return NETDEV_TX_OK in case of ERROR because a nonzero return value indicates that the packet
		   could not be transmitted at this time and the kernel will retry later.
		*/
		return NETDEV_TX_OK;
	}

	net_priv->stats.tx_bytes += len;
	net_priv->stats.tx_packets++;

	return NETDEV_TX_OK;
}

static struct net_device_stats *sx_netdev_get_stats(struct net_device *netdev)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	return &net_priv->stats;
}

static void sx_netdev_set_multicast(struct net_device *netdev)
{
	return;
}

static int sx_netdev_set_mac(struct net_device *netdev, void *p)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	struct sockaddr *addr = p;

	if (!is_valid_ether_addr(addr->sa_data)) {
		printk(KERN_INFO PFX "address not given.");
		return -EADDRNOTAVAIL;
	}

	memcpy(netdev->dev_addr, addr->sa_data, netdev->addr_len);
	net_priv->mac = sx_netdev_mac_to_u64(netdev->dev_addr);

	return 0;
}

static int sx_netdev_change_mtu(struct net_device *netdev, int new_mtu)
{
	if (new_mtu < ETH_ZLEN || new_mtu > MAX_JUMBO_FRAME_SIZE) {
		return -EINVAL;
	}

	netdev->mtu = new_mtu;

	return 0;
}

static int sx_netdev_do_ioctl(struct net_device *netdev, struct ifreq *ifr, int cmd)
{
	return -EOPNOTSUPP;
}

static void sx_netdev_vlan_rx_register(struct net_device *netdev,
		struct vlan_group *grp)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	net_priv->vlgrp = grp;
}

static void sx_netdev_vlan_rx_add_vid(struct net_device *netdev, unsigned short vid)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	if (!net_priv->vlgrp)
		return;

#ifdef SX_DEBUG
	printk(KERN_INFO PFX "adding VLAN:%d (vlgrp entry:%p)\n",
			 vid, vlan_group_get_device(net_priv->vlgrp, vid));
#endif
}

static void sx_netdev_vlan_rx_kill_vid(struct net_device *netdev, unsigned short vid)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	if (!net_priv->vlgrp)
		return;

#ifdef SX_DEBUG
	printk(KERN_INFO PFX "Killing VID:%d (vlgrp:%p vlgrp "
			 "entry:%p)\n", vid, net_priv->vlgrp,
			 vlan_group_get_device(net_priv->vlgrp, vid));
#endif
	vlan_group_set_device(net_priv->vlgrp, vid, NULL);
}

int sx_netdev_register_device(struct net_device *netdev, int should_rtnl_lock,
                              int admin_state)
{
	int err = 0;
	struct sx_net_priv *net_priv = netdev_priv(netdev);

	printk(KERN_INFO PFX "%s: called for device %s\n", __func__, netdev->name);

	/* set netdev defaults and function callbacks */
	netdev->base_addr 		= 0;
	netdev->irq 			= 0;
	netdev->features 		|= NETIF_F_HW_VLAN_RX;
	netdev->open 			= sx_netdev_open;
	netdev->stop 			= sx_netdev_stop;
	netdev->hard_start_xmit = sx_netdev_hard_start_xmit;
	netdev->get_stats 		= sx_netdev_get_stats;
	netdev->set_multicast_list 	= sx_netdev_set_multicast;
	netdev->set_mac_address 	= sx_netdev_set_mac;
	netdev->change_mtu 		= sx_netdev_change_mtu;
	netdev->do_ioctl 		= sx_netdev_do_ioctl;
	netdev->vlan_rx_register 	= sx_netdev_vlan_rx_register;
	netdev->vlan_rx_add_vid 	= sx_netdev_vlan_rx_add_vid;
	netdev->vlan_rx_kill_vid 	= sx_netdev_vlan_rx_kill_vid;
	sx_netdev_u64_to_mac(netdev->dev_addr, net_priv->mac);
	netdev->mtu = DEFAULT_FRAME_SIZE;

	/* Disable the transmit timeout function.  */
	netdev->tx_timeout = NULL;

	if (should_rtnl_lock)
		 rtnl_lock();
	err = register_netdevice(netdev);
    if (admin_state && net_priv->mac) {
		dev_change_flags(netdev, netdev->flags | IFF_UP);
    } else {
        netif_tx_disable(netdev);
        netif_carrier_off(netdev);
    }
    if (should_rtnl_lock)
		 rtnl_unlock();

	if (err) {
		printk(KERN_ERR PFX "Net Device registration "
				"has failed. err=%d\n", err);
		return err;
	}

	printk(KERN_INFO PFX "%s: exit\n", __func__);
	return 0;
}

static void sx_netdev_unregister_device(struct net_device *netdev)
{
	netif_tx_disable(netdev);
	netif_carrier_off(netdev);

    sx_core_flush_synd_by_context(netdev);

	unregister_netdev(netdev); /* It will call our stop function */
	free_netdev(netdev);
}

static void  *__sx_netdev_init_one_netdev(struct sx_dev *dev, int swid, int synd, u64 mac)
{
	struct sx_net_priv *net_priv;
	struct net_device *netdev;
	int err;
	char name[10];
	int i;

	printk(KERN_INFO PFX "Initializing\n");

	if (swid < 0 || swid >= NUMBER_OF_SWIDS) /* only swids 0-7 are allowed */
		return NULL;

	sprintf(name,"swid%d_eth", swid);
	netdev = alloc_netdev(sizeof(*net_priv), name, ether_setup);
	if (!netdev) {
		printk(KERN_ERR PFX  "Net Device struct %s alloc failed, "
			"aborting.\n", name);
		return NULL;
	}

	netdev->hard_header_len = ETH_HLEN + ISX_HDR_SIZE;
	memset(netdev_priv(netdev), 0, sizeof(*net_priv));
	net_priv = netdev_priv(netdev);
	net_priv->swid = swid;
	net_priv->dev = dev;
	net_priv->mac = mac;
	net_priv->is_l2_port = 0;
	net_priv->is_oper_state_up = 1;

	for (i = 0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		net_priv->trap_ids[L3_NETDEV][i] = SX_INVALID_TRAP_ID;
	}
	net_priv->num_of_traps[L3_NETDEV] = 0;

	for (i = 0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		net_priv->trap_ids[L2_NETDEV][i] = SX_INVALID_TRAP_ID;
	}
	net_priv->num_of_traps[L2_NETDEV] = 0;

	err = sx_netdev_register_device(netdev, 1, 1);
	if (err)
		goto out;

	return netdev;

out:
	free_netdev(netdev);
	return NULL;
}

static void  *__sx_netdev_init_one_port_netdev(struct sx_dev *dev, u16 sysport, u8 is_lag,
											   u16 mid, char *name, int swid, u8 send_to_rp_as_data)
{
	struct sx_net_priv *net_priv;
	struct net_device *netdev;
	int err;
	int i;

	printk(KERN_INFO PFX "Initializing\n");

	if (swid < 0 || swid >= NUMBER_OF_SWIDS) /* only swids 0-7 are allowed */
		return NULL;


	netdev = alloc_netdev(sizeof(*net_priv), name, ether_setup);
	if (!netdev) {
		printk(KERN_ERR PFX  "Net Device struct %s alloc failed, "
			"aborting.\n", name);
		return NULL;
	}

	netdev->hard_header_len = ETH_HLEN + ISX_HDR_SIZE;
	memset(netdev_priv(netdev), 0, sizeof(*net_priv));
	net_priv = netdev_priv(netdev);
	net_priv->swid = swid;
	net_priv->dev = dev;
	net_priv->mac = 0;
	net_priv->port = sysport;
	net_priv->is_lag = is_lag;
	net_priv->is_l2_port = 0;
	net_priv->is_oper_state_up = 1;
	if (net_priv->is_lag) {
		net_priv->mid = mid;
	}
	net_priv->is_port_netdev = 1;

	for (i = 0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		net_priv->trap_ids[L3_NETDEV][i] = SX_INVALID_TRAP_ID;
	}
	net_priv->num_of_traps[L3_NETDEV] = 0;

	for (i = 0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		net_priv->trap_ids[L2_NETDEV][i] = SX_INVALID_TRAP_ID;
	}
	net_priv->num_of_traps[L2_NETDEV] = 0;

	net_priv->send_to_rp_as_data_supported = send_to_rp_as_data;
	err = sx_netdev_register_device(netdev, 1, 0);
	if (err)
		goto out;

	return netdev;

out:
	free_netdev(netdev);
	return NULL;
}

static int sx_netdev_init_one_netdev(struct sx_dev *dev,
		struct sx_netdev_rsc *resources, int swid, int synd, u64 mac)
{
	struct net_device *netdev = NULL;

	spin_lock(&resources->rsc_lock);
	if (resources->allocated[swid]) {
		spin_unlock(&resources->rsc_lock);
		printk(KERN_ERR PFX  "Net Device for swid %d was already"
				" allocated\n", swid);
		return -EFAULT;
	}

	resources->allocated[swid] = 1;
	spin_unlock(&resources->rsc_lock);
	netdev = __sx_netdev_init_one_netdev(dev, swid, synd, mac);
	if (!netdev) {
		spin_lock(&resources->rsc_lock);
		resources->allocated[swid] = 0;
		spin_unlock(&resources->rsc_lock);

		return -EFAULT;
	}

	resources->sx_netdevs[swid] = netdev;

	return 0;
}

static int sx_netdev_init_one_port_netdev(struct sx_dev *dev,
		struct sx_netdev_rsc *resources, u16 port, u8 is_lag, u16 mid, char *name, int swid,
		u8 send_to_rp_as_data)
{
	struct net_device *netdev = NULL;

	spin_lock(&resources->rsc_lock);
	if (resources->port_allocated[port]) {
		spin_unlock(&resources->rsc_lock);
		printk(KERN_ERR PFX  "Net Device for port %u was already"
				" allocated\n", port);
		return -EFAULT;
	}

	resources->port_allocated[port] = 1;
	spin_unlock(&resources->rsc_lock);
	netdev = __sx_netdev_init_one_port_netdev(dev, port, is_lag, mid, name, swid,
	                                          send_to_rp_as_data);
	if (!netdev) {
		spin_lock(&resources->rsc_lock);
		resources->port_allocated[port] = 0;
		spin_unlock(&resources->rsc_lock);

		return -EFAULT;
	}

	resources->sx_port_netdevs[port] = netdev;

	if (is_lag){
	    lag_rp_netdev_db[port] = netdev;
	}
	else{
	    port_rp_netdev_db[port] = netdev;
	}

	return 0;
}

static void sx_netdev_remove_one_netdev(struct sx_dev *dev, void *rsc, int swid)
{
	struct net_device *netdev;
	struct sx_netdev_rsc *resources = rsc;
	unsigned long flags;

	spin_lock_irqsave(&resources->rsc_lock, flags);
	netdev = resources->sx_netdevs[swid];
	if (!resources->allocated[swid]) {
		spin_unlock_irqrestore(&resources->rsc_lock, flags);
		return;
	}

	resources->sx_netdevs[swid] = NULL;
	resources->allocated[swid] = 0;
	spin_unlock_irqrestore(&resources->rsc_lock, flags);
	sx_netdev_unregister_device(netdev);
}

static void sx_netdev_remove_one_port_netdev(struct sx_dev *dev, void *rsc, u16 port)
{
	struct net_device *netdev;
	struct sx_netdev_rsc *resources = rsc;
	unsigned long flags;
	struct sx_net_priv *net_priv;

	spin_lock_irqsave(&resources->rsc_lock, flags);
	netdev = resources->sx_port_netdevs[port];
	if (netdev == NULL || !resources->port_allocated[port]) {
		spin_unlock_irqrestore(&resources->rsc_lock, flags);
		return;
	}
	net_priv = netdev_priv(netdev);

	// TODO: ADD LOCKS
	if (net_priv->is_lag) {
		lag_rp_netdev_db[port] = NULL;
	}
	else {
		port_rp_netdev_db[port] = NULL;
	}

	resources->sx_port_netdevs[port] = NULL;
	resources->port_allocated[port] = 0;
	spin_unlock_irqrestore(&resources->rsc_lock, flags);
	sx_netdev_unregister_device(netdev);
}

static void *sx_netdev_init_one(struct sx_dev *dev)
{
	static int sx_netdev_version_printed = 0;
	struct sx_netdev_rsc *resources;
	int i;

	printk(KERN_DEBUG PFX "sx_netdev_init_one\n");
	if (!sx_netdev_version_printed) {
		printk(KERN_INFO "%s", sx_netdev_version);
		++sx_netdev_version_printed;
	}

	resources = vmalloc(sizeof(*resources));
	if (!resources)
		return NULL;

	for (i = 0; i < NUMBER_OF_SWIDS; i++) {
		resources->sx_netdevs[i] = NULL;
		resources->allocated[i] = 0;
	}

	for (i = 0; i < MAX_SYSPORT_NUM; i++) {
		resources->sx_port_netdevs[i] = NULL;
		resources->port_allocated[i] = 0;
	}

	spin_lock_init(&resources->rsc_lock);

	g_netdev_resources = resources;
	g_sx_dev = dev;

	return resources;
}

static void sx_netdev_remove_one(struct sx_dev *dev, void *rsc)
{
	int i;
	struct sx_netdev_rsc *resources = rsc;

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "sx_netdev_remove_one\n");
#endif
	for (i = 0; i < NUMBER_OF_SWIDS; i++)
		sx_netdev_remove_one_netdev(dev, resources, i);

	for (i = 0; i < MAX_SYSPORT_NUM; i++)
		sx_netdev_remove_one_port_netdev(dev, resources, i);

	vfree(resources);
}



static int __sx_netdev_dev_synd_add(struct net_device *netdev, enum sx_net_priv_netdev_type net_dev_type, void *rsc, u16 synd)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	int err = 0, i = 0;
	union ku_filter_critireas crit;
	cq_handler netdev_callback = 0;

	if (net_priv->num_of_traps[net_dev_type] == MAX_NUM_TRAPS_TO_REGISTER) {
		printk(KERN_ERR PFX "%s: swid %s Too many traps\n",
					__func__, netdev->name);
		err = -ERANGE;
		goto out;
	}

	/* validate that the trap at new index is INVALID */
	BUG_ON(net_priv->trap_ids[net_dev_type][net_priv->num_of_traps[net_dev_type]] != SX_INVALID_TRAP_ID);

    for (i=0; i < net_priv->num_of_traps[net_dev_type] ; i++) {
        if (net_priv->trap_ids[net_dev_type][i] == synd) {
            printk(KERN_INFO PFX "The synd 0x%x is already added.\n",synd);
            err = 0;
            goto out;
        }
    }

	/* add trap to traps_db */
    net_priv->trap_ids[net_dev_type][net_priv->num_of_traps[net_dev_type]] = synd;
    net_priv->num_of_traps[net_dev_type]++;

	/* if netdev is active (opened) than config the synd, else the synd will be added after dev open */
	if (netdev->flags & IFF_UP) {

		memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
		switch (net_dev_type){
			case L2_NETDEV:
				netdev_callback = sx_netdev_l2_rx_pkt;
				crit.eth.from_rp = IS_RP_DONT_CARE_E;
				crit.eth.from_bridge = IS_BRIDGE_DONT_CARE_E;
				break;
			case L3_NETDEV:
				netdev_callback = sx_netdev_handle_rx_pkt;
				crit.eth.from_rp = IS_RP_NOT_FROM_RP_E;
				crit.eth.from_bridge = IS_BRIDGE_NOT_FROM_BRIDGE_E;
				break;
			default :
				printk("unsupported netdev type(%d) .\n", net_dev_type);
				err = -ERANGE;
				goto out;
				break;
		}

		/* register the listener according to the swid */
		err = sx_core_add_synd(net_priv->swid, synd, L2_TYPE_ETH, 0,
			crit, netdev_callback, netdev,
			CHECK_DUP_DISABLED_E, net_priv->dev);

		if (err) {
			printk(KERN_ERR PFX "error %s, Failed registering on "
					"0x%x syndrome.\n", netdev->name, synd);
			goto out;
		}
	}

out:
	return err;
}


static int __sx_netdev_dev_synd_remove(struct net_device *netdev, enum sx_net_priv_netdev_type net_dev_type, void *rsc, u16 synd)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	int err = 0;
	int trap_was_found = 0;
	int i;
	union ku_filter_critireas crit;

	for (i=0; i<net_priv->num_of_traps[net_dev_type]; i++) {
		if (net_priv->trap_ids[net_dev_type][i] == synd) {
			printk(KERN_INFO PFX "The synd 0x%x was found and will be removed.\n",synd);
			net_priv->trap_ids[net_dev_type][i] = net_priv->trap_ids[net_dev_type][net_priv->num_of_traps[net_dev_type] - 1];
			net_priv->trap_ids[net_dev_type][net_priv->num_of_traps[net_dev_type] - 1] = SX_INVALID_TRAP_ID;
			net_priv->num_of_traps[net_dev_type]--;
			trap_was_found = 1;
			break;
		}
	}

	if (trap_was_found && (netdev->flags & IFF_UP)) {

		memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
		switch (net_dev_type){
			case L2_NETDEV:
				crit.eth.from_rp = IS_RP_DONT_CARE_E;
				crit.eth.from_bridge = IS_BRIDGE_DONT_CARE_E;
				break;
			case L3_NETDEV:
				crit.eth.from_rp = IS_RP_NOT_FROM_RP_E;
				crit.eth.from_bridge = IS_BRIDGE_NOT_FROM_BRIDGE_E;
				break;
			default :
				printk("unsupported netdev type(%d) .\n", net_dev_type);
				err = -ERANGE;
				goto out;
				break;
		}

		err = sx_core_remove_synd(net_priv->swid, synd, L2_TYPE_ETH, 0,
		                          crit, netdev, net_priv->dev);

		if (err) {
			printk(KERN_ERR PFX "error %s, Failed deregistering on "
					"0x%x syndrome.\n", netdev->name, synd);
			goto out;
		}
	}

out:
	return err;
}

static void sx_netdev_set_synd_l3(struct sx_dev *dev, void *rsc, u16 synd, enum sx_dev_event event)
{
	struct sx_netdev_rsc *resources = rsc;
	unsigned long flags;
	int i;
    int err;
    union ku_filter_critireas crit;

	spin_lock_irqsave(&resources->rsc_lock, flags);

	/* go over all per swid devices */
	for (i = 0; i < NUMBER_OF_SWIDS; i++) {
		if (resources->sx_netdevs[i] != NULL) {
			if (event == SX_DEV_EVENT_ADD_SYND_NETDEV) {
				__sx_netdev_dev_synd_add(resources->sx_netdevs[i], L3_NETDEV, rsc, synd);
			} else {
				__sx_netdev_dev_synd_remove(resources->sx_netdevs[i] , L3_NETDEV, rsc, synd);
			}
		}
	}

    /* register the listener according to the swid */
    memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
    crit.eth.from_rp = IS_RP_FROM_RP_E;
    if (event == SX_DEV_EVENT_ADD_SYND_NETDEV) {
        err = sx_core_add_synd(0, synd, L2_TYPE_ETH, 0,
                crit, sx_netdev_handle_global_pkt, NULL,
                CHECK_DUP_DISABLED_E, NULL);
        if (err) {
            printk(KERN_ERR PFX "Failed registering RP rx_handle on "
                    "syndrome %d.\n", synd);
        }
    } else {
        err = sx_core_remove_synd(0, synd, L2_TYPE_ETH, 0,
                crit, NULL, NULL);
        if (err) {
            printk(KERN_ERR PFX "Failed unregistering RP rx_handle on "
                    "syndrome %d.\n", synd);
        }
    }

    /* register the listener according to the swid */
    memset(&crit, 0, sizeof(crit)); /* sets all ETH values to default */
    crit.eth.from_bridge = IS_BRIDGE_FROM_BRIDGE_E;
    if (event == SX_DEV_EVENT_ADD_SYND_NETDEV) {
        err = sx_core_add_synd(0, synd, L2_TYPE_ETH, 0,
                crit, sx_netdev_handle_global_pkt, NULL,
                CHECK_DUP_DISABLED_E, NULL);
        if (err) {
            printk(KERN_ERR PFX "Failed registering bridge rx_handle on "
                    "syndrome %d.\n", synd);
        }
    } else {
        err = sx_core_remove_synd(0, synd, L2_TYPE_ETH, 0,
                crit, NULL, NULL);
        if (err) {
            printk(KERN_ERR PFX "Failed unregistering bridge rx_handle on "
                    "syndrome %d.\n", synd);
        }
    }

	spin_unlock_irqrestore(&resources->rsc_lock, flags);
}

static void sx_netdev_set_synd_l2(struct sx_dev *dev, void *rsc, u16 synd, enum sx_dev_event event)
{
	struct sx_netdev_rsc *resources = rsc;
	unsigned long flags;
	int i;

	spin_lock_irqsave(&resources->rsc_lock, flags);

	/* go over all per swid devices */
	for (i = 0; i < NUMBER_OF_SWIDS; i++) {
		if (resources->sx_netdevs[i] != NULL) {
			if (event == SX_DEV_EVENT_ADD_SYND_NETDEV) {
				__sx_netdev_dev_synd_add(resources->sx_netdevs[i], L2_NETDEV, rsc, synd);
			} else {
				__sx_netdev_dev_synd_remove(resources->sx_netdevs[i], L2_NETDEV, rsc, synd);
			}
		}
	}
	spin_unlock_irqrestore(&resources->rsc_lock, flags);
}


void __sx_netdev_dump_per_dev(struct net_device *netdev)
{
	struct sx_net_priv *net_priv = netdev_priv(netdev);
	int i;

	printk("======   Netdev %s dump:   =====\n",netdev->name);
	printk("l3_traps.num_of_traps: %d\n",	net_priv->num_of_traps[L3_NETDEV]);
	for (i=0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		if (net_priv->trap_ids[L3_NETDEV][i] != SX_INVALID_TRAP_ID) {
			printk("trap[%d]: 0x%x\n", i, net_priv->trap_ids[L3_NETDEV][i]);
		}
	}

	printk("======   Netdev %s dump:   =====\n",netdev->name);
	printk("num_of_l2_traps: %d\n",	net_priv->num_of_traps[L2_NETDEV]);
	for (i=0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		if (net_priv->trap_ids[L2_NETDEV][i] != SX_INVALID_TRAP_ID) {
			printk("trap[%d]: 0x%x\n", i, net_priv->trap_ids[L2_NETDEV][i]);
		}
	}
}

static void sx_netdev_debug_dump(struct sx_dev *dev, void *rsc)
{
	struct sx_netdev_rsc *resources = rsc;
	unsigned long flags;
	int i, port;

	spin_lock_irqsave(&resources->rsc_lock, flags);

	/* go over all per swid devices */
	for (i = 0; i < NUMBER_OF_SWIDS; i++){
		if (resources->sx_netdevs[i] != NULL) {
			__sx_netdev_dump_per_dev(resources->sx_netdevs[i]);
		}
	}

	/* go over all per port devices */
	for (port = 0; port < MAX_SYSPORT_NUM; port++){
		if (resources->sx_port_netdevs[port] != NULL) {
			__sx_netdev_dump_per_dev(resources->sx_port_netdevs[port]);
		}
	}

	spin_unlock_irqrestore(&resources->rsc_lock, flags);

    /* go over all bridge devices */
    for (i = 0; i < MAX_BRIDGE_NUM; i++){
        if (bridge_netdev_db[i] != NULL) {
            __sx_netdev_dump_per_dev(bridge_netdev_db[i]);
        }
    }
}


static void sx_netdev_event(struct sx_dev *dev, void *resources,
		enum sx_dev_event event, union sx_event_data *event_data)
{
	switch (event) {
	case SX_DEV_EVENT_ETH_SWID_UP:
		printk(KERN_INFO PFX "sx_netdev_event: Got ETH swid up event. "
				"dev = %p, dev_id = %u, swid = %d, "
				"synd = 0x%x, mac = 0x%llx\n",
			dev, dev->device_id, event_data->eth_swid_up.swid,
			event_data->eth_swid_up.synd, event_data->eth_swid_up.mac);
		sx_netdev_init_one_netdev(dev, resources, event_data->eth_swid_up.swid,
				event_data->eth_swid_up.synd, event_data->eth_swid_up.mac);
		return;
	case SX_DEV_EVENT_ETH_SWID_DOWN:
		printk(KERN_INFO PFX "sx_netdev_event: Got ETH swid down event. "
				"dev = %p, dev_id = %u, swid = %d\n",
			dev, dev->device_id, event_data->eth_swid_down.swid);
		sx_netdev_remove_one_netdev(dev, resources, event_data->eth_swid_down.swid);
		return;
	case SX_DEV_EVENT_OPEN_PORT_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got OPEN NETDEV event. "
				"dev = %p, dev_id = %u, port = 0x%x, name = %s, is_lag = %d, mid = 0x%x\n",
			dev, dev->device_id, event_data->port_netdev_set.sysport,
			event_data->port_netdev_set.name, event_data->port_netdev_set.is_lag, event_data->port_netdev_set.mid);
		sx_netdev_init_one_port_netdev(dev, resources, event_data->port_netdev_set.sysport,
				event_data->port_netdev_set.is_lag, event_data->port_netdev_set.mid,
				event_data->port_netdev_set.name, event_data->port_netdev_set.swid,
				event_data->port_netdev_set.send_to_rp_as_data_supported);
		return;
	case SX_DEV_EVENT_CLOSE_PORT_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got CLOSE NETDEV event. "
				"dev = %p, dev_id = %u, port = 0x%x\n",
			dev, dev->device_id, event_data->port_netdev_set.sysport);
		sx_netdev_remove_one_port_netdev(dev, resources, event_data->port_netdev_set.sysport);
		return;
	case SX_DEV_EVENT_ADD_SYND_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got ADD_SYND_L3 event. "
				"dev = %p, dev_id = %u, trap_id = 0x%x\n",
			dev, dev->device_id, event_data->eth_l3_synd.hw_synd );
		sx_netdev_set_synd_l3(dev, resources, event_data->eth_l3_synd.hw_synd,
							  SX_DEV_EVENT_ADD_SYND_NETDEV);
		break;
	case SX_DEV_EVENT_REMOVE_SYND_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got REMOVE_SYND_L3 event. "
				"dev = %p, dev_id = %u, trap_id = 0x%x\n",
			dev, dev->device_id, event_data->eth_l3_synd.hw_synd );
		sx_netdev_set_synd_l3(dev, resources, event_data->eth_l3_synd.hw_synd,
							  SX_DEV_EVENT_REMOVE_SYND_NETDEV);
		break;
	case SX_DEV_EVENT_ADD_SYND_L2_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got ADD_SYND_L2 event. "
				"dev = %p, dev_id = %u, trap_id = 0x%x\n",
			dev, dev->device_id, event_data->eth_l3_synd.hw_synd );
		sx_netdev_set_synd_l2(dev, resources, event_data->eth_l3_synd.hw_synd,
							  SX_DEV_EVENT_ADD_SYND_NETDEV);
		break;
	case SX_DEV_EVENT_REMOVE_SYND_L2_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got REMOVE_SYND_L2 event. "
				"dev = %p, dev_id = %u, trap_id = 0x%x\n",
			dev, dev->device_id, event_data->eth_l3_synd.hw_synd );
		sx_netdev_set_synd_l2(dev, resources, event_data->eth_l3_synd.hw_synd,
							  SX_DEV_EVENT_REMOVE_SYND_NETDEV);
		break;
	case SX_DEV_EVENT_DEBUG_NETDEV:
		printk(KERN_INFO PFX "sx_netdev_event: Got DEBUG_NETDEV event. "
				"dev = %p, dev_id = %u, trap_id = 0x%x\n",
			dev, dev->device_id, event_data->eth_l3_synd.hw_synd );
		sx_netdev_debug_dump(dev, resources);
		break;
	case SX_DEV_EVENT_CATASTROPHIC_ERROR:
	default:
		return;
	}
}

static struct sx_interface sx_netdev_interface = {
	.add = sx_netdev_init_one,
	.remove = sx_netdev_remove_one,
	.event = sx_netdev_event
};

static int __init sx_netdev_init(void)
{
	int ret;

	printk(KERN_INFO PFX "sx_netdev_init\n");

	ret = sx_register_interface(&sx_netdev_interface);
	if (ret)
	    return ret;

	ret = sx_netdev_register_global_event_handler();
	if (ret)
		goto out1;

	ret = sx_netdev_rtnl_link_register();
	if (ret)
		goto out2;

    ret = sx_bridge_rtnl_link_register();
    if (ret)
        goto out2;

	return 0;

out2:
	sx_netdev_unregister_global_event_handler();

out1:
	sx_unregister_interface(&sx_netdev_interface);

	return ret;
}

static void __exit sx_netdev_cleanup(void)
{
	printk(KERN_INFO PFX "sx_netdev_cleanup \n");

	sx_bridge_rtnl_link_unregister();
	sx_netdev_rtnl_link_unregister();
	sx_netdev_unregister_global_event_handler();
	sx_unregister_interface(&sx_netdev_interface);
}

module_init(sx_netdev_init);
module_exit(sx_netdev_cleanup);
