/*
 * Copyright (c) 2014 Mellanox, LTD. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/errno.h>
#include <linux/etherdevice.h>
#include <linux/string.h>
#include <linux/spinlock.h>
#include <linux/netdevice.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/tcp.h>
#include <linux/ip.h>
#include <linux/icmp.h>
#include <net/ip.h>
#include <linux/vmalloc.h>
#include <linux/if_ether.h>
#include <linux/if_vlan.h>
#include <linux/rtnetlink.h>

#include <linux/mlx_sx/cmd.h>
#include <linux/mlx_sx/device.h>
#include <linux/mlx_sx/driver.h>
#include <linux/mlx_sx/cmd.h>
#include <linux/mlx_sx/kernel_user.h>
#include "sx_netdev.h"
#include <linux/mlx_sx/device.h>

static void sx_netdev_setup(struct net_device *dev)
{
	struct sx_net_priv *net_priv = netdev_priv(dev);

	printk(KERN_INFO PFX "%s: called\n", __func__);

	memset(net_priv, 0, sizeof(*net_priv));
	ether_setup(dev);
	dev->hard_header_len = ETH_HLEN + ISX_HDR_SIZE;
}

static int sx_netdev_validate(struct nlattr *tb[], struct nlattr *data[])
{
	__u32 id;
	int is_lag;
	
	printk(KERN_INFO PFX "%s: called\n", __func__);

	if (tb[IFLA_ADDRESS]) {
		if (nla_len(tb[IFLA_ADDRESS]) != ETH_ALEN) {
			pr_debug("invalid link address (not ethernet)\n");
			return -EINVAL;
		}

		if (!is_valid_ether_addr(nla_data(tb[IFLA_ADDRESS]))) {
			pr_debug("invalid all zero ethernet address\n");
			return -EADDRNOTAVAIL;
		}
	}

	if (!data) {
		printk(KERN_INFO PFX "%s: Data invalid\n", __func__);
		return -EINVAL;
	}

	if (!data[IFLA_SX_NETDEV_SWID]) {
		printk(KERN_INFO PFX "%s: SWID doesn't exists\n", __func__);
		return -EINVAL;
	}

	id = nla_get_u32(data[IFLA_SX_NETDEV_SWID]);
	if (id >= NUMBER_OF_SWIDS) {
		printk(KERN_INFO PFX "%s: SWID is out of range - %d\n", __func__, id);
		return -ERANGE;
	}

	if (data[IFLA_SX_NETDEV_PORT]) {
		id = translate_user_port_to_sysport(g_sx_dev, nla_get_u32(data[IFLA_SX_NETDEV_PORT]), &is_lag);
		if (id >= MAX_SYSPORT_NUM) {
			printk(KERN_INFO PFX "%s: PORT is out of range - %d\n", __func__, id);
			return -ERANGE;
		}
		if (is_lag) {
		    if (id >= MAX_LAG_NUM) {
			printk(KERN_INFO PFX "%s: LAG is out of range - %d\n", __func__, id);
			return -ERANGE;
		    }
		}
	}

	if (data[IFLA_SX_NETDEV_TYPE]) {
		id = nla_get_u32(data[IFLA_SX_NETDEV_TYPE]);
		if (id >= __IFLA_SX_NETDEV_TYPE_MAX) {
			printk(KERN_INFO PFX "%s: TYPE is out of range - %d\n", __func__, id);
			return -ERANGE;
		}
 	}

	printk(KERN_INFO PFX "%s: exit\n", __func__);
	return 0;
}

static size_t sx_netdev_get_size(const struct net_device *dev)
{
	return  nla_total_size(sizeof(__u32)) +	/* IFLA_SX_NETDEV_SWID */
		nla_total_size(sizeof(__u32)) +	/* IFLA_SX_NETDEV_PORT */
		nla_total_size(sizeof(__u32)) + /* IFLA_SX_NETDEV_TYPE */
		0;
}

static int sx_netdev_fill_info(struct sk_buff *skb, const struct net_device *dev)
{
	struct sx_net_priv *net_priv = netdev_priv(dev);
	__u32 type;

	if (nla_put_u32(skb, IFLA_SX_NETDEV_SWID, net_priv->swid))
		goto nla_put_failure;

	if (nla_put_u32(skb, IFLA_SX_NETDEV_PORT, translate_sysport_to_user_port(g_sx_dev, net_priv->port, net_priv->is_lag)))
		goto nla_put_failure;

	if (net_priv->is_l2_port)
		type = IFLA_SX_NETDEV_TYPE_L2;
	else if (net_priv->is_port_netdev)
		type = IFLA_SX_NETDEV_TYPE_L3;
	else 
		goto nla_put_failure;

	if (nla_put_u32(skb, IFLA_SX_NETDEV_TYPE, type))
		goto nla_put_failure;		

	return 0;

nla_put_failure:
	return -EMSGSIZE;
}

static int sx_netdev_newlink(struct net *net, struct net_device *dev,
			struct nlattr *tb[], struct nlattr *data[])
{
	struct ku_access_paos_reg paos_reg_data;
	struct ku_access_ppad_reg ppad_reg_data;
	struct sx_net_priv *net_priv = netdev_priv(dev);
	int swid;
	int err;
	int i;
	unsigned int logical_port;
	__u32 type;

	printk(KERN_INFO PFX "%s: called\n", __func__);
	memset(&paos_reg_data, 0, sizeof(struct ku_access_paos_reg));
	memset(&ppad_reg_data, 0, sizeof(struct ku_access_ppad_reg));

	if (!data[IFLA_SX_NETDEV_SWID]) 
		return -EINVAL;
	if (!data[IFLA_SX_NETDEV_TYPE])
		return -EINVAL;
	if (!data[IFLA_SX_NETDEV_PORT])
		return -EINVAL;

	swid = nla_get_u32(data[IFLA_SX_NETDEV_SWID]);
	if (swid >= NUMBER_OF_SWIDS) {
		printk(KERN_INFO PFX "%s: SWID is out of range - %d\n", __func__, swid);
		return -EINVAL;
	}

	if (!g_netdev_resources->sx_netdevs[swid]) {
		printk(KERN_INFO PFX "%s: SWID %d, doesn't exists\n", __func__, swid);
		return -EINVAL;
	}

	logical_port = nla_get_u32(data[IFLA_SX_NETDEV_PORT]);
	type = nla_get_u32(data[IFLA_SX_NETDEV_TYPE]);
	if ((type != IFLA_SX_NETDEV_TYPE_L2) && (type != IFLA_SX_NETDEV_TYPE_L3)) {
		printk(KERN_INFO PFX "%s: Unknown type - %d\n", __func__, type);
		return -EINVAL;
	}
	
	net_priv->swid = swid;
	net_priv->dev = ((struct sx_net_priv*)netdev_priv(g_netdev_resources->sx_netdevs[swid]))->dev;
	net_priv->port = translate_user_port_to_sysport(g_sx_dev, logical_port, &net_priv->is_lag);

	printk(KERN_INFO PFX "%s: Adding sys_port %d for logical_port %06X\n", __func__, net_priv->port, logical_port);

	if (type == IFLA_SX_NETDEV_TYPE_L2) {
		net_priv->is_l2_port = 1;
        if (net_priv->is_lag) {
            net_priv->is_oper_state_up = 1;
        }
        else { /* the port is a system port */
            /* Query port state via PAOS register */
            paos_reg_data.dev_id = g_sx_dev->device_id;
            sx_cmd_set_op_tlv(&paos_reg_data.op_tlv, PAOS_REG_ID, EMAD_METHOD_QUERY);
            paos_reg_data.paos_reg.local_port = SX_PORT_PHY_ID_GET(logical_port);
            paos_reg_data.paos_reg.admin_status = 0;
            paos_reg_data.paos_reg.oper_status = 0;
            paos_reg_data.paos_reg.ase = 0;
            paos_reg_data.paos_reg.ee = 0;
            paos_reg_data.paos_reg.e = 0;
            err = sx_ACCESS_REG_PAOS(g_sx_dev, &paos_reg_data);
            if (err) {
                printk(KERN_INFO PFX "%s: Unable to get port state, port = %5X err = %d\n", __func__, logical_port, err);
                paos_reg_data.paos_reg.oper_status = 0;
            }
            printk(KERN_INFO PFX "%s: Port state for %5X = %d\n", __func__, logical_port, paos_reg_data.paos_reg.oper_status);
            net_priv->is_oper_state_up = (paos_reg_data.paos_reg.oper_status == PORT_OPER_STATUS_UP);
        }
	}
	else {
		/* L3 netdev */
		net_priv->is_l2_port = 0;
		net_priv->is_oper_state_up = 1;
		net_priv->is_port_netdev = 1;
	}

	/* Read MAC address */
    if (net_priv->is_lag) {
        memset(dev->dev_addr, 0, ETH_ALEN);
    }
    else { /* the port is a system port */
        ppad_reg_data.dev_id = g_sx_dev->device_id;
        sx_cmd_set_op_tlv(&ppad_reg_data.op_tlv, PPAD_REG_ID, EMAD_METHOD_QUERY);
        err = sx_ACCESS_REG_PPAD(g_sx_dev, &ppad_reg_data);
        if (err) {
            printk(KERN_INFO PFX "%s: Unable to get base MAC address, err = %d\n", __func__, err);
            random_ether_addr(dev->dev_addr);
        }
        else {
            memcpy(dev->dev_addr, ppad_reg_data.ppad_reg.mac, ETH_ALEN);
            dev->dev_addr[ETH_ALEN - 1] = SX_PORT_PHY_ID_GET(logical_port);

        }
    }
	net_priv->mac = sx_netdev_mac_to_u64(dev->dev_addr);
	printk(KERN_INFO PFX "%s: Newly device %s MAC address = %llx\n", __func__, dev->name, net_priv->mac);

	for (i = 0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		net_priv->trap_ids[L3_NETDEV][i] = SX_INVALID_TRAP_ID;
	}
	net_priv->num_of_traps[L3_NETDEV] = 0;

	for (i = 0; i < MAX_NUM_TRAPS_TO_REGISTER; i++) {
		net_priv->trap_ids[L2_NETDEV][i] = SX_INVALID_TRAP_ID;
	}
	net_priv->num_of_traps[L2_NETDEV] = 0;

	err = sx_netdev_register_device(dev, 0, 0);
	if (err) {
		printk(KERN_INFO PFX "%s: sx_netdev_register_device() failed error - %d\n", __func__, err);
		return ENXIO;
	}

	if (net_priv->is_l2_port) {
	    if (net_priv->is_lag) {
	        lag_l2_netdev_db[net_priv->port] = dev;
            err = sx_core_get_lag_mid(net_priv->dev, net_priv->port, &(net_priv->mid));
            if (err) {
                printk(KERN_INFO PFX "%s: sx_core_get_lag_mid() failed error - %d\n", __func__, err);
                return err;
            }
        }
	    else {
	        port_l2_netdev_db[net_priv->port] = dev;
	    }
	}

	printk(KERN_INFO PFX "%s: exit\n", __func__);

	return 0;	
}

static void sx_netdev_dellink(struct net_device *dev, struct list_head *head)
{
	struct sx_net_priv *net_priv = netdev_priv(dev);

	printk(KERN_INFO PFX "%s: called\n", __func__);

	if (net_priv->is_l2_port) {
	    if (net_priv->is_lag) {
           lag_l2_netdev_db[net_priv->port] = NULL;
        }
	    else {
		port_l2_netdev_db[net_priv->port] = NULL;
	    }
	}

	netif_tx_disable(dev);
	netif_carrier_off(dev);

	sx_core_flush_synd_by_context(dev);

	unregister_netdevice_queue(dev, head);

	printk(KERN_INFO PFX "%s: exit\n", __func__);
}


static const struct nla_policy sx_netdev_policy[IFLA_SX_NETDEV_MAX + 1] = {
	[IFLA_SX_NETDEV_SWID]	=	{ .type = NLA_U32 },
	[IFLA_SX_NETDEV_PORT]	=	{ .type = NLA_U32 },
	[IFLA_SX_NETDEV_TYPE]	=	{ .type = NLA_U32 }	
};

static struct rtnl_link_ops sx_netdev_link_ops __read_mostly = {
	.kind		= "sx_netdev",
	.maxtype	= IFLA_SX_NETDEV_MAX,
	.policy		= sx_netdev_policy,
	.priv_size 	= sizeof(struct sx_net_priv),
	.setup		= sx_netdev_setup,
	.validate	= sx_netdev_validate,
	.newlink	= sx_netdev_newlink,
	.dellink	= sx_netdev_dellink,
	.get_size 	= sx_netdev_get_size,
	.fill_info	= sx_netdev_fill_info
};

int sx_netdev_rtnl_link_register()
{
	return rtnl_link_register(&sx_netdev_link_ops);
}

void sx_netdev_rtnl_link_unregister()
{
	rtnl_link_unregister(&sx_netdev_link_ops);
}
