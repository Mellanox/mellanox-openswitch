/*
 * Copyright (c) 2014 Mellanox, LTD. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#ifndef SX_NETDEV_H
#define SX_NETDEV_H

#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/etherdevice.h>
#include <linux/kthread.h>
#include <linux/mm.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/netlink.h>
#include <linux/mlx_sx/device.h>
#include <linux/mlx_sx/driver.h>
#include <linux/mlx_sx/kernel_user.h>

#define DRV_NAME	"sx_netdev"
#define PFX		DRV_NAME ": "
#define DRV_VERSION	"1.0"
#define DRV_RELDATE	"Jan, 2012"

#define ISX_HDR_SIZE			16
#define MAX_JUMBO_FRAME_SIZE		10000
#define DEFAULT_FRAME_SIZE		9216
#define MAX_NUM_TRAPS_TO_REGISTER	256
#define SX_INVALID_TRAP_ID		0xFFFF
#define SX_PORT_TO_ISX_LAG_ID(port)		(port<<4)
#define SX_PACKET_DEFAULT_TC    5 
#define TX_HEADER_RP_RIF_TO_FID (15*1024)


enum sx_net_priv_netdev_type {
	L2_NETDEV = 0,
	L3_NETDEV = 1,
	NUM_OF_NET_DEV_TYPE
};

struct sx_net_priv {
	u8							swid;
	u16 						trap_ids[NUM_OF_NET_DEV_TYPE][MAX_NUM_TRAPS_TO_REGISTER];
	u16 						num_of_traps[NUM_OF_NET_DEV_TYPE];
	struct sx_dev				*dev;
	struct net_device_stats		stats;
	u64							mac;
	struct vlan_group			*vlgrp;
	u16							port;
	u16			                mid;
	int			                is_lag;
	int			                is_port_netdev;
	int			                is_l2_port;
	int			                is_oper_state_up;
    u8                          send_to_rp_as_data_supported;
    int                         is_bridge;
    u16                         bridge_id; /* bridge id == fid */
};

struct sx_netdev_rsc {
	struct net_device	*sx_netdevs[NUMBER_OF_SWIDS];
	spinlock_t		rsc_lock; /* the resource's lock */
	u8			allocated[NUMBER_OF_SWIDS];
	struct net_device	*sx_port_netdevs[MAX_SYSPORT_NUM];
	struct net_device   *sx_lag_netdevs[MAX_LAG_NUM];
	u8			port_allocated[MAX_SYSPORT_NUM];
};

#define SX_VLAN_PRIO_MASK          0xe000 /* Priority Code Point */
#define SX_VLAN_PRIO_SHIFT         13

u64 sx_netdev_mac_to_u64(u8 *addr);
void sx_netdev_u64_to_mac(u8* addr, u64 mac);
int sx_netdev_register_device(struct net_device *netdev, int should_rtnl_lock,
                              int admin_state);

/* Global core context */
extern struct net_device *port_l2_netdev_db[MAX_SYSPORT_NUM];
extern struct net_device *lag_l2_netdev_db[MAX_LAG_NUM];
extern struct net_device *bridge_netdev_db[MAX_BRIDGE_NUM];
extern struct sx_netdev_rsc *g_netdev_resources; 
extern struct sx_dev* g_sx_dev;

/* TODO! Should be move to include/uapi/linux/if_link.h */
/* IP tools policies */
enum {
    IFLA_SX_NETDEV_UNSPEC,
	IFLA_SX_NETDEV_SWID,
	IFLA_SX_NETDEV_PORT,
    IFLA_SX_NETDEV_TYPE,
    __IFLA_SX_NETDEV_MAX
};
enum {
    IFLA_SX_NETDEV_TYPE_L2 = 0,
    IFLA_SX_NETDEV_TYPE_L3 = 1,
    __IFLA_SX_NETDEV_TYPE_MAX
};
#define IFLA_SX_NETDEV_MAX  (__IFLA_SX_NETDEV_MAX - 1)

enum {
    IFLA_SX_BRIDGE_UNSPEC,
    IFLA_SX_BRIDGE_ID,
    __IFLA_SX_BRIDGE_MAX
};
#define IFLA_SX_BRIDGE_MAX  (__IFLA_SX_BRIDGE_MAX - 1)

int sx_netdev_rtnl_link_register(void);
void sx_netdev_rtnl_link_unregister(void);
int sx_bridge_rtnl_link_register(void);
void sx_bridge_rtnl_link_unregister(void);

#endif /* SX_NETDEV_H */
