/*
 * Copyright (c) 2014 Mellanox, LTD. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <linux/module.h>
#include <linux/skbuff.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/workqueue.h>
#include <linux/interrupt.h>
#include <linux/if_ether.h>
#include <linux/mlx_sx/kernel_user.h>
#include <rdma/ib_verbs.h>
#include "cq.h"
#include "ib.h"

/************************************************
 *  Define
 ***********************************************/
#define CR_SPACE_COMMAND_SIZE 12 /* without the FCS */
#define CR_SPACE_SEGMENT_SIZE 4
#define CR_SPACE_DATA_SIZE 8 /* data + padding */

#define SGMII_RX_RING_SIZE 128 /* Should come from the profile in the future */
#define SGMII_TX_RING_SIZE 128 /* Should come from the profile in the future */
#define SGMII_RX_BUFF_SIZE 4096
#define SGMII_OP_RECV (1ul << 31)
#define SGMII_MAX_POLL_TX_WC 10
#define SGMII_MAX_POLL_RX_WC 10
#define SGMII_MAX_REPOLLS 100

/************************************************
 *  Structures
 ***********************************************/
struct sgmii_buf {
	struct sk_buff *skb;
	u64		mapping[3];
};

struct sx_sgmii_flow {
	struct ib_mr *mr;
	struct ib_cq *recv_cq;
	struct ib_cq *send_cq;
	struct ib_qp *qp;
	struct sgmii_buf tx_ring[SGMII_TX_RING_SIZE];
	struct sgmii_buf rx_ring[SGMII_RX_RING_SIZE];
	spinlock_t rx_ring_lock;
	spinlock_t tx_ring_lock;
	int tx_idx; /* This is the tail index */
	struct ib_flow *flow_id;
};

struct sx_sgmii_device {
	struct ib_device *ib_device;
	int port_number;
	struct ib_pd *pd;
	struct sx_sgmii_flow flow[MAX_SGMII_FLOWS];
};

/************************************************
 *  Globals
 ***********************************************/
extern struct sx_globals sx_glb;
extern int rx_debug_sgmii;
extern int rx_dump_sgmii;
extern int tx_debug_sgmii;
extern int tx_dump_sgmii;
extern char *sgmii_dev_name;
extern int sgmii_port_number;

/* SGMII CMD IFC globals */
struct semaphore sgmii_cmd_sem; /* Used for serializing all SGMII transactions */
struct sk_buff *cmd_resp = NULL;
u8 cr_space_token = 0;

/* SGMII RX/TX globals. Can be moved to sx_glb */
struct tasklet_struct sx_sgmii_tasklet;
int sgmii_err = 0;
struct sx_sgmii_device sgmii_dev;

/************************************************
 * Functions
 ***********************************************/
int sgmii_post_recv(int id);

static int sgmii_dma_map_tx(struct sgmii_buf *tx_req)
{
	struct sk_buff *skb = tx_req->skb;
	u64 *mapping = tx_req->mapping;
	int i;
	int off;

	if (skb_headlen(skb)) {
		mapping[0] = ib_dma_map_single(sgmii_dev.ib_device, skb->data,
				skb_headlen(skb), DMA_TO_DEVICE);
		if (unlikely(ib_dma_mapping_error(sgmii_dev.ib_device, mapping[0])))
			return -EIO;

		off = 1;
	} else
		off = 0;

	for (i = 0; i < skb_shinfo(skb)->nr_frags; ++i) {
		const skb_frag_t *frag = &skb_shinfo(skb)->frags[i];
		mapping[i + off] = ib_dma_map_page(sgmii_dev.ib_device,
						 skb_frag_page(frag),
						 frag->page_offset, skb_frag_size(frag),
						 DMA_TO_DEVICE);
		if (unlikely(ib_dma_mapping_error(sgmii_dev.ib_device, mapping[i + off])))
			goto partial_error;
	}

	return 0;

partial_error:
	for (; i > 0; --i) {
		const skb_frag_t *frag = &skb_shinfo(skb)->frags[i - 1];

		ib_dma_unmap_page(sgmii_dev.ib_device, mapping[i - !off], skb_frag_size(frag),
				DMA_TO_DEVICE);
	}

	if (off)
		ib_dma_unmap_single(sgmii_dev.ib_device, mapping[0], skb_headlen(skb),
				DMA_TO_DEVICE);

	return -EIO;
}

static void sgmii_dma_unmap_tx(struct sgmii_buf *tx_req)
{
	struct sk_buff *skb = tx_req->skb;
	u64 *mapping = tx_req->mapping;
	int i;
	int off;

	if (skb_headlen(skb)) {
		ib_dma_unmap_single(sgmii_dev.ib_device, mapping[0], skb_headlen(skb),
						DMA_TO_DEVICE);
		off = 1;
	} else
		off = 0;

	for (i = 0; i < skb_shinfo(skb)->nr_frags; ++i) {
		const skb_frag_t *frag = &skb_shinfo(skb)->frags[i];
		ib_dma_unmap_page(sgmii_dev.ib_device, mapping[i + off],
					skb_frag_size(frag), DMA_TO_DEVICE);
	}
}

static void sgmii_handle_tx_wc(struct ib_wc *wc)
{
	unsigned int wr_id = wc->wr_id;
	struct sk_buff *skb;
	unsigned long flags;

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "send completion: id %d, status: %d\n",
		       wr_id, wc->status);
#endif
	if (unlikely(wr_id >= SGMII_TX_RING_SIZE)) {
		printk(KERN_ERR PFX "send completion event with wrid %d (> %d)\n",
			   wr_id, SGMII_TX_RING_SIZE);
		return;
	}

	spin_lock_irqsave(&sgmii_dev.flow[0].tx_ring_lock, flags);
	skb = sgmii_dev.flow[0].tx_ring[wr_id].skb;
	if (!skb) {
		printk(KERN_ERR PFX "sgmii_handle_tx_wc: SKB in index %d is NULL\n", wr_id);
		spin_unlock_irqrestore(&sgmii_dev.flow[0].tx_ring_lock, flags);
		return;
	}

	sgmii_dma_unmap_tx(&sgmii_dev.flow[0].tx_ring[wr_id]);
	sgmii_dev.flow[0].tx_ring[wr_id].skb = NULL;
	spin_unlock_irqrestore(&sgmii_dev.flow[0].tx_ring_lock, flags);
	sx_skb_free(skb);
	if (wc->status != IB_WC_SUCCESS &&
	    wc->status != IB_WC_WR_FLUSH_ERR)
		printk(KERN_ERR PFX "failed send event "
				"(status=%d, wrid=%d vend_err 0x%x)\n",
				wc->status, wr_id, wc->vendor_err);
}

void sgmii_tx_completion(void)
{
	int n, i;
	struct ib_wc wc[SGMII_MAX_POLL_TX_WC];
	int ret;

repoll:
	n = ib_poll_cq(sgmii_dev.flow[0].send_cq, SGMII_MAX_POLL_TX_WC, wc);
	if (n == 0)
		return;

#ifdef SX_DEBUG	
	printk(KERN_DEBUG PFX "sgmii_tx_completion: polled %d completions\n", n);
#endif
	for (i = 0; i < n; ++i) {
		sgmii_handle_tx_wc(&wc[i]);
	}

	ret = ib_req_notify_cq(sgmii_dev.flow[0].send_cq, IB_CQ_NEXT_COMP | IB_CQ_REPORT_MISSED_EVENTS); 
	if (ret < 0) {
		printk(KERN_ERR PFX "sgmii_tx_completion: ib_req_notify_cq failed\n");
	} else if (ret > 0) { /* a completion might be waiting for us */
		goto repoll;
	}

	return;
}

static void sgmii_handle_rx_wc(struct ib_wc *wc)
{
	unsigned int wr_id = wc->wr_id & ~SGMII_OP_RECV;
	struct sk_buff *skb;
	struct sx_cqe *cqe;
	unsigned long flags;

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "sgmii_handle_rx_wc: recv completion: id %d, "
			"status: %d size %d bytes\n", wr_id, wc->status,  wc->byte_len);
#endif
	if (unlikely(wr_id >= SGMII_RX_RING_SIZE)) {
		printk(KERN_ERR PFX "recv completion event with wrid %d "
				"(> %d)\n", wr_id, SGMII_RX_RING_SIZE);
		return;
	}

	spin_lock_irqsave(&sgmii_dev.flow[0].rx_ring_lock, flags);
	skb = sgmii_dev.flow[0].rx_ring[wr_id].skb;
	sgmii_dev.flow[0].rx_ring[wr_id].skb = NULL;
	if (skb == NULL) {
		printk(KERN_ERR PFX "sgmii_handle_rx_wc: SKB is NULL. "
				"wr_id=%d, wc->wr_id=%llu\n", wr_id, wc->wr_id);
		spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
		return;
	}

	spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
	ib_dma_unmap_single(sgmii_dev.ib_device, sgmii_dev.flow[0].rx_ring[wr_id].mapping[0],
			SGMII_RX_BUFF_SIZE, DMA_FROM_DEVICE);
	if (unlikely(wc->status != IB_WC_SUCCESS)) {
		if (wc->status != IB_WC_WR_FLUSH_ERR) {
			printk(KERN_WARNING PFX "sgmii_handle_rx_wc: failed recv "
					"event (status=%d, wrid=%d vend_err %x)\n",
					wc->status, wr_id, wc->vendor_err);
			sgmii_post_recv(wr_id); /* In flush error we don't repost new buffers */
		}

		kfree_skb(skb);
		return;
	}

	if (unlikely(sgmii_post_recv(wr_id))) {
		printk(KERN_WARNING PFX "sgmii_handle_rx_wc: sgmii_post_recv failed\n");
	}

	if (rx_debug_sgmii && rx_dump_sgmii) {
		int i;
		u8 *buf = (void *)skb->data;
		int cnt = skb->len;

		if (cnt > 1280)
			cnt = 1280;

		printk(KERN_ERR PFX "sgmii_handle_rx_wc: Received a packet:\n");
		for (i = 0; i < cnt; i++) {
			if (i == 0 || (i%4 == 0))
				printk(KERN_INFO "\n0x%04x : ", i);
			printk(KERN_INFO " 0x%02x", buf[i]);
		}

		printk(KERN_INFO "\n");
	}

	cqe = (struct sx_cqe *)(skb->data + sizeof(struct sx_eth_hdr));
	skb->data += (sizeof(struct sx_eth_hdr) + sizeof(struct sx_cqe));
	skb->len -= (sizeof(struct sx_eth_hdr) + sizeof(struct sx_cqe));
	/* TODO: might need to uncomment the following line as the HW
	 * puts the entire packet size in the byte count of the CQe intead of
	 * the "original packet" size only. */ 
	/* cqe->dqn5_byte_count = cpu_to_be16(skb->len); */

	/* pkt_type 7 in the CQE means this is a command packet */
	if (((cqe->type_swid >> 5) & 0x7)== 7) {
		cmd_resp = skb;
		if (rx_debug_sgmii)
			printk(KERN_ERR PFX "sgmii_handle_rx_wc: Received an CMD_IFC packet through SGMII\n");
		return;
	} else {
		if (rx_debug_sgmii)
			printk(KERN_DEBUG PFX "sgmii_handle_rx_wc: Received an EMAD/MAD packet through SGMII\n");
	
		if (unlikely(rx_skb(sx_glb.tmp_dev_ptr, skb, cqe))) {
			printk(KERN_WARNING PFX "sgmii_handle_rx_wc: rx_skb failed\n");
		}
	}
}

void sgmii_rx_completion(void)
{
	int n, i;
	struct ib_wc wc[SGMII_MAX_POLL_RX_WC];
	int ret;
	int num_repolls = 0;

repoll:
	n = ib_poll_cq(sgmii_dev.flow[0].recv_cq, SGMII_MAX_POLL_RX_WC, wc);
	if (n == 0)
		return;

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "sgmii_rx_completion: polled %d completions\n", n);
#endif
	for (i = 0; i < n; ++i) {
		sgmii_handle_rx_wc(&wc[i]);
	}

	ret = ib_req_notify_cq(sgmii_dev.flow[0].recv_cq, IB_CQ_NEXT_COMP | IB_CQ_REPORT_MISSED_EVENTS); 
	if (ret < 0) {
		printk(KERN_ERR PFX "sgmii_rx_completion: ib_req_notify_cq failed\n");
	} else if (ret > 0) { /* a completion might be waiting for us */
		if (num_repolls >= SGMII_MAX_REPOLLS) {
			printk(KERN_ERR PFX "sgmii_rx_completion: num_repolls reached %d\n", SGMII_MAX_REPOLLS);
		} else {
			num_repolls++;
			goto repoll;
		}
	}

	return;
}

static void sx_sgmii_tasklet_handler(unsigned long data)
{
	/* Once we have more than 1 flow we should iterate all of them 
	 * in RR just like we do for DQs when using PCI */

	/* We don't know which CQ generated the event so we check both 
	 * for completions */
	sgmii_tx_completion();
	sgmii_rx_completion();

	return;
}

void sgmii_completion(struct ib_cq *cq, void *ctx_ptr)
{
	tasklet_schedule(&sx_sgmii_tasklet);
}

int sx_sgmii_tx(struct sk_buff *skb)
{
	int err = 0;
	struct ib_sge sg_list[3];
	struct ib_send_wr send_wr;
	struct ib_send_wr *bad_wr;
	int i, off, num_frags;
	struct sgmii_buf *tx_req = NULL;
	skb_frag_t *frags;
	unsigned long flags;

	if (skb == NULL) {
		printk(KERN_ERR PFX "%s: SKB is NULL\n", __func__);
		return -EFAULT;
	}
	
	if (!sx_glb.sx_sgmii.initialized || !sgmii_dev.ib_device) {
		printk(KERN_ERR PFX "%s: !sx_glb.sx_sgmii.initialized || "
				"!sgmii_dev.ib_device\n", __func__);
		sx_skb_free(skb);
		return -EINVAL;
	}

	num_frags = skb_shinfo(skb)->nr_frags;
/* after disable iCRC calculation for RAW QP we doesn't need to add 2 bytes */
#if 0	
	if (num_frags == 0) {
		/* TODO: do the same for packets with non-linear SKB */
		/* Increase the data size of the SKB by 2 for ETH FCS */
		skb_put(skb, 2);
	}
#endif	

	if (num_frags > 2) {
		printk(KERN_ERR PFX "%s: num_frags %d is not supported\n",
				__func__, num_frags);
		sx_skb_free(skb);
		return -EINVAL;
	}

	if (tx_debug_sgmii) {
		u8 *buf = (void *)skb->data;
		int cnt = skb->len;

		if (cnt > 256)
			cnt = 256;

		printk(KERN_INFO PFX "Going to send a  packet through SGMII, "
				"size = %d\n", cnt);
		if (tx_dump_sgmii) {
			for (i = 0; i < cnt; i++) {
				if (i == 0 || (i%4 == 0))
					printk(KERN_INFO "\n0x%04x : ", i);
					printk(KERN_INFO " 0x%02x", buf[i]);
			}
	
			printk(KERN_INFO "\n");
		}
	}

#ifndef NO_PCI
	spin_lock_irqsave(&sgmii_dev.flow[0].tx_ring_lock, flags);
	for (i = 0; i < SGMII_TX_RING_SIZE; i++, sgmii_dev.flow[0].tx_idx++) {
		if (sgmii_dev.flow[0].tx_ring[sgmii_dev.flow[0].tx_idx & (SGMII_TX_RING_SIZE - 1)].skb == NULL) {
			tx_req = &sgmii_dev.flow[0].tx_ring[sgmii_dev.flow[0].tx_idx & (SGMII_TX_RING_SIZE - 1)];
			tx_req->skb = skb;
			break;
		}
	}

	if (tx_req == NULL) {
		printk(KERN_ERR PFX "sx_sgmii_tx: TX ring is full, cannot send "
				"packet\n");
		spin_unlock_irqrestore(&sgmii_dev.flow[0].tx_ring_lock, flags);
		return -ENOMEM;
	}

	frags = skb_shinfo(skb)->frags;
	err = sgmii_dma_map_tx(tx_req);
	if (err) {
		printk(KERN_ERR PFX "sx_sgmii_tx: sgmii_dma_map_tx returned an error\n");
		spin_unlock_irqrestore(&sgmii_dev.flow[0].tx_ring_lock, flags);
		sx_skb_free(skb);
		return err;
	}

	memset(sg_list, 0, sizeof(sg_list));
	if (skb_headlen(skb)) {
		sg_list[0].addr = tx_req->mapping[0];
		sg_list[0].length = skb_headlen(skb);
		sg_list[0].lkey = sgmii_dev.flow[0].mr->lkey;
		off = 1;
	} else
		off = 0;

	for (i = 0; i < num_frags; ++i) {
		sg_list[i + off].addr = tx_req->mapping[i + off];
		sg_list[i + off].length = skb_frag_size(&frags[i]);
		sg_list[i + off].lkey = sgmii_dev.flow[0].mr->lkey;
	}

	memset(&send_wr, 0, sizeof(send_wr));
	send_wr.num_sge	 = num_frags + off;
	send_wr.wr_id = sgmii_dev.flow[0].tx_idx & (SGMII_TX_RING_SIZE - 1);
	sgmii_dev.flow[0].tx_idx++;
	spin_unlock_irqrestore(&sgmii_dev.flow[0].tx_ring_lock, flags);
	send_wr.sg_list = sg_list;
	send_wr.opcode = IB_WR_SEND;
	send_wr.next = NULL;
	send_wr.send_flags |= IB_SEND_SOLICITED;
#ifdef SX_DEBUG
	printk(KERN_INFO PFX "sx_sgmii_tx: About to send a packet: "
			"send_wr.num_sge = %d, send_wr.wr_id = %llu, send_wr.sg_list[0].length = %d",
			send_wr.num_sge, send_wr.wr_id, send_wr.sg_list[0].length);
#endif
	err = ib_post_send(sgmii_dev.flow[0].qp, &send_wr, &bad_wr);
	if (unlikely(err)) {
		printk(KERN_ERR PFX "sx_sgmii_tx: ib_post_send failed with err %d\n", err);
		goto out_err;
	}
#ifdef SX_DEBUG
	printk(KERN_INFO PFX "sx_sgmii_tx: ib_post_send finished successfully\n");
#endif
#endif

	if (tx_debug_sgmii)
		printk(KERN_INFO PFX "sx_sgmii_tx: Packet was sent successfully\n");

	return 0;

out_err:
	for (i = 0; i < 3; i++) {
		if (sg_list[i].addr) {
			ib_dma_unmap_single(sgmii_dev.ib_device, sg_list[i].addr,
					sg_list[i].length, DMA_TO_DEVICE);
		} else
			break;
	}

	sx_skb_free(skb);

	return err;
}

/* Once we have more than 1 flow the caller will have to 
 * say on which flow the recv buffer should be posted */
int sgmii_post_recv(int id)
{
	struct sk_buff *skb;
	int err;
	struct ib_sge sg_list;
	struct ib_recv_wr recv_wr;
	struct ib_recv_wr *bad_wr;
	struct sgmii_buf *rx_buf;
	unsigned long flags;

	if (id >= SGMII_RX_RING_SIZE) {
		printk(KERN_ERR PFX "sgmii_post_recv: id %d is bigger than "
				"ring size %d\n", id, SGMII_RX_RING_SIZE);
		return -ENOMEM;
	}

	spin_lock_irqsave(&sgmii_dev.flow[0].rx_ring_lock, flags);
	rx_buf = &sgmii_dev.flow[0].rx_ring[id];
	if (rx_buf->skb != NULL) {
		err = -EFAULT;
		spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
		printk(KERN_WARNING PFX "sgmii_post_recv: rx_ring[%d].skb is not "
				"NULL\n", id);
		goto out;
	}

	skb = alloc_skb(SGMII_RX_BUFF_SIZE, GFP_ATOMIC);
	if (!skb) {
		err = -ENOMEM;
		spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
		goto out;
	}

	if (skb_put(skb, SGMII_RX_BUFF_SIZE) == NULL) {
		err = -ENOMEM;
		spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
		goto out_free;
	}

	rx_buf->mapping[0] = ib_dma_map_single(sgmii_dev.ib_device, skb->data, 
			SGMII_RX_BUFF_SIZE, DMA_FROM_DEVICE);
	if (unlikely(ib_dma_mapping_error(sgmii_dev.ib_device, rx_buf->mapping[0]))) {
		err = -ENOMEM;
		spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
		goto out_free;
	}

	rx_buf->skb = skb;
	spin_unlock_irqrestore(&sgmii_dev.flow[0].rx_ring_lock, flags);
	sg_list.addr = rx_buf->mapping[0];
	sg_list.length = SGMII_RX_BUFF_SIZE;
	sg_list.lkey = sgmii_dev.flow[0].mr->lkey;
	recv_wr.wr_id = id | SGMII_OP_RECV;
	recv_wr.next = NULL;
	recv_wr.sg_list = &sg_list;
	recv_wr.num_sge = 1;
	err = ib_post_recv(sgmii_dev.flow[0].qp, &recv_wr, &bad_wr);
	if (unlikely(err)) {
		printk(KERN_DEBUG PFX "sgmii_post_recv: ib_post_recv failed\n");
		goto out_unmap;
	}

	return 0;

out_unmap:
	rx_buf->skb = NULL;
	ib_dma_unmap_single(sgmii_dev.ib_device, rx_buf->mapping[0],
			SGMII_RX_BUFF_SIZE, DMA_FROM_DEVICE);
out_free:
	kfree_skb(skb);
out:
	return err;
}

/* This function is looking for the first CA with ETH port 
 * It ignores switch devices and CAs with IB only ports.
 * Once a CA is found the function will ignore any other device */
static void sx_sgmii_add_one(struct ib_device *device)
{
	int s, e, p;
	int first_eth_port = 0;
	struct ib_qp_init_attr init_attr;
	int ret = 0;
	struct ib_qp_attr qp_attr;
	int attr_mask;
	int i;
	struct ib_flow_attr *flow_attr;
	union ib_flow_spec *ib_spec;
	u64 smac = sx_glb.sx_sgmii.base_smac;

	if (sx_glb.sx_sgmii.initialized == 1) {
		printk(KERN_DEBUG PFX "sx_sgmii_add_one: Skipping device %s since "
				"we already found a different device\n", device->name);
		return;
	}

	if (rdma_node_get_transport(device->node_type) != RDMA_TRANSPORT_IB)
		return;

	if (device->node_type == RDMA_NODE_IB_SWITCH ||
		!strcmp(device->name,sgmii_dev_name) ) {
		printk(KERN_DEBUG PFX "sx_sgmii_add_one: Skipping switch "
				"device %s\n", device->name);
		return;
	}

	if (sgmii_port_number != -1){
		if (rdma_port_get_link_layer(device, sgmii_port_number) == IB_LINK_LAYER_ETHERNET) {
			first_eth_port = sgmii_port_number;
		}
	}

	if (first_eth_port == 0) {
		s = 1;
		e = device->phys_port_cnt;
		for (p = s; p <= e; ++p) {
			if (rdma_port_get_link_layer(device, p) == IB_LINK_LAYER_ETHERNET) {
				first_eth_port = p;
				break; /* For now we will use the frist eth port */
			}
		}
	}

	if (first_eth_port == 0) {
		printk(KERN_DEBUG PFX "sx_sgmii_add_one: No ETH ports were found in "
				"device %s\n", device->name);
		return;
	}

	sgmii_dev.ib_device = device;
	sgmii_dev.port_number = first_eth_port;
	printk(KERN_INFO PFX "sx_sgmii_add_one: Found device %s port %d\n",
			sgmii_dev.ib_device->name, sgmii_dev.port_number);

	sgmii_dev.pd = ib_alloc_pd(sgmii_dev.ib_device);
	if (IS_ERR(sgmii_dev.pd)) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_alloc_pd failed\n");
		ret = PTR_ERR(sgmii_dev.pd);
		goto out_clean;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_alloc_pd finished successfully\n");

	sgmii_dev.flow[0].mr = ib_get_dma_mr(sgmii_dev.pd, IB_ACCESS_LOCAL_WRITE);
	if (IS_ERR(sgmii_dev.flow[0].mr)) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_get_dma_mr failed\n");
		ret = PTR_ERR(sgmii_dev.flow[0].mr);
		goto out_dealloc_pd;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_get_dma_mr finished successfully\n");

	sgmii_dev.flow[0].recv_cq = ib_create_cq(sgmii_dev.ib_device, sgmii_completion, NULL,
			  NULL, SGMII_RX_RING_SIZE, 1);
	if (IS_ERR(sgmii_dev.flow[0].recv_cq)) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_create_cq failed\n");
		ret = PTR_ERR(sgmii_dev.flow[0].recv_cq);
		goto out_dereg_mr;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_create_cq finished successfully\n");

	ret = ib_req_notify_cq(sgmii_dev.flow[0].recv_cq, IB_CQ_NEXT_COMP);
	if (ret) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_req_notify_cq failed\n");
		goto out_destroy_recv_cq;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_req_notify_cq finished successfully\n");

	sgmii_dev.flow[0].send_cq = ib_create_cq(sgmii_dev.ib_device, sgmii_completion, NULL,
			  NULL, SGMII_TX_RING_SIZE, 1);
	if (IS_ERR(sgmii_dev.flow[0].send_cq)) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_create_cq failed\n");
		ret = PTR_ERR(sgmii_dev.flow[0].send_cq);
		goto out_destroy_recv_cq;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_create_cq finished successfully\n");

	ret = ib_req_notify_cq(sgmii_dev.flow[0].send_cq, IB_CQ_NEXT_COMP);
	if (ret) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_req_notify_cq failed\n");
		goto out_destroy_send_cq;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_req_notify_cq finished successfully\n");

	memset(&init_attr, 0, sizeof (init_attr));
	init_attr.sq_sig_type		= IB_SIGNAL_ALL_WR;
	init_attr.qp_type			= IB_QPT_RAW_PACKET;
	init_attr.create_flags		= 0;
	init_attr.qpg_type			= IB_QPG_NONE;
	init_attr.cap.max_send_wr	= SGMII_TX_RING_SIZE;
	init_attr.cap.max_send_sge	= 3;
	init_attr.cap.max_recv_wr	= SGMII_RX_RING_SIZE;
	init_attr.cap.max_recv_sge	= 1;
	init_attr.send_cq			= sgmii_dev.flow[0].send_cq;
	init_attr.recv_cq			= sgmii_dev.flow[0].recv_cq;
	sgmii_dev.flow[0].qp = ib_create_qp(sgmii_dev.pd, &init_attr);
	if (IS_ERR(sgmii_dev.flow[0].qp)) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_create_qp failed\n");
		ret = PTR_ERR(sgmii_dev.flow[0].qp);
		goto out_destroy_send_cq;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_create_qp finished successfully\n");

	memset(&qp_attr, 0, sizeof (qp_attr));
	qp_attr.qkey = 0;
	qp_attr.port_num = sgmii_dev.port_number;
	qp_attr.qp_state = IB_QPS_INIT;
	attr_mask = IB_QP_PORT | IB_QP_STATE;
	ret = ib_modify_qp(sgmii_dev.flow[0].qp, &qp_attr, attr_mask);
	if (ret) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_modify_qp failed to "
				"modify QP state to IB_QPS_INIT\n");
		goto out_destroy_qp;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_modify_qp (INIT) finished successfully\n");

	qp_attr.qp_state = IB_QPS_RTR;
	attr_mask &= ~(IB_QP_PORT);
	ret = ib_modify_qp(sgmii_dev.flow[0].qp, &qp_attr, attr_mask);
	if (ret) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_modify_qp failed to "
				"modify QP state to IB_QPS_RTR\n");
		goto out_destroy_qp;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_modify_qp (RTR) finished successfully\n");

	qp_attr.qp_state = IB_QPS_RTS;
	ret = ib_modify_qp(sgmii_dev.flow[0].qp, &qp_attr, attr_mask);
	if (ret) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_modify_qp failed to "
				"modify QP state to IB_QPS_RTS\n");
		goto out_destroy_qp;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_modify_qp (RTS) finished successfully\n");

	for (i = 0; i < SGMII_RX_RING_SIZE; i++) {
		ret = sgmii_post_recv(i);
		if (ret) {
			printk(KERN_ERR PFX "sx_sgmii_add_one: sgmii_post_recv failed "
					"with index %d\n", i);
			goto out_destroy_qp;
		}
	}

	flow_attr = kzalloc(sizeof(*flow_attr) + sizeof(struct ib_flow_spec_eth),
			GFP_KERNEL);
	if (!flow_attr) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: failed to allocate flow_attr\n");
		ret = -ENOMEM;
		goto out_destroy_qp;
	}

	flow_attr->type = IB_FLOW_ATTR_NORMAL;
	flow_attr->priority = 0xFFF;
	flow_attr->num_of_specs = 1;
	flow_attr->port = sgmii_dev.port_number;
	flow_attr->flags = 0;
	flow_attr->size = sizeof(*flow_attr) + sizeof(struct ib_flow_spec_eth);
	ib_spec = (union ib_flow_spec *)(flow_attr + 1);
	ib_spec->eth.type = IB_FLOW_SPEC_ETH;
	ib_spec->eth.size = sizeof(struct ib_flow_spec_eth);
	for (i = ETH_ALEN - 1; i >= 0; i--) {
		ib_spec->eth.val.dst_mac[i] = (u8)(smac & 0xFF);
		smac >>= 8;
		ib_spec->eth.mask.dst_mac[i] = 0xFF;
	}

	sgmii_dev.flow[0].flow_id = ib_create_flow(sgmii_dev.flow[0].qp, flow_attr, IB_FLOW_DOMAIN_USER);
	if (IS_ERR(sgmii_dev.flow[0].flow_id)) {
		printk(KERN_ERR PFX "sx_sgmii_add_one: ib_create_flow failed\n");
		ret = PTR_ERR(sgmii_dev.flow[0].flow_id);
		kfree(flow_attr);
		goto out_destroy_qp;
	}
	printk(KERN_DEBUG PFX "sx_sgmii_add_one: ib_create_flow finished successfully\n");

	sgmii_dev.flow[0].flow_id->qp = sgmii_dev.flow[0].qp;
	kfree(flow_attr);
	printk(KERN_INFO PFX "sx_sgmii_add_one: Finished successfully\n");

	return;

out_destroy_qp:
	qp_attr.qp_state = IB_QPS_RESET;
	if (ib_modify_qp(sgmii_dev.flow[0].qp, &qp_attr, IB_QP_STATE)) {
		printk(KERN_WARNING PFX "sx_sgmii_add_one: ib_modify_qp failed "
				"to modify QP state to IB_QPS_RESET\n");
	}

	ib_destroy_qp(sgmii_dev.flow[0].qp);
	sgmii_dev.flow[0].qp = NULL;
out_destroy_send_cq:
	ib_destroy_cq(sgmii_dev.flow[0].send_cq);
	sgmii_dev.flow[0].send_cq = NULL;
out_destroy_recv_cq:
	ib_destroy_cq(sgmii_dev.flow[0].recv_cq);
	sgmii_dev.flow[0].recv_cq = NULL;
out_dereg_mr:
	ib_dereg_mr(sgmii_dev.flow[0].mr);
	sgmii_dev.flow[0].mr = NULL;
out_dealloc_pd:
	ib_dealloc_pd(sgmii_dev.pd);
	sgmii_dev.pd = NULL;
out_clean:
	sgmii_dev.ib_device = NULL;
	sgmii_dev.port_number = 0;
	sgmii_err = ret;
	printk(KERN_WARNING PFX "sx_sgmii_add_one: Finished with error %d\n", ret);

	return;
}

static void sx_sgmii_remove_one(struct ib_device *device)
{
	if (device != sgmii_dev.ib_device)
		return;

	if (sgmii_dev.flow[0].flow_id) {
		ib_destroy_flow(sgmii_dev.flow[0].flow_id);
		sgmii_dev.flow[0].flow_id = NULL;
	}

	if (sgmii_dev.flow[0].qp) {
		struct ib_qp_attr qp_attr;

		memset(&qp_attr, 0, sizeof (qp_attr));
		qp_attr.qp_state = IB_QPS_RESET;
		if (ib_modify_qp(sgmii_dev.flow[0].qp, &qp_attr, IB_QP_STATE))
			printk(KERN_WARNING PFX "sx_sgmii_remove_one: ib_modify_qp failed "
					"to modify QP state to IB_QPS_RESET\n");
		else
			printk(KERN_DEBUG PFX "sx_sgmii_remove_one: ib_modify_qp (RESET) finished successfully\n");

		if (ib_destroy_qp(sgmii_dev.flow[0].qp))
			printk(KERN_WARNING PFX "sx_sgmii_remove_one: ib_destroy_qp failed\n");
		else
			printk(KERN_DEBUG PFX "sx_sgmii_remove_one: ib_destroy_qp finished successfully\n");

		sgmii_dev.flow[0].qp = NULL;
	}

	if (sgmii_dev.flow[0].send_cq) {
		if (ib_destroy_cq(sgmii_dev.flow[0].send_cq))
			printk(KERN_WARNING PFX "sx_sgmii_remove_one: ib_destroy_cq failed\n");
		else
			printk(KERN_DEBUG PFX "sx_sgmii_remove_one: ib_destroy_cq finished successfully\n");

		sgmii_dev.flow[0].send_cq = NULL;
	}

	if (sgmii_dev.flow[0].recv_cq) {
		if (ib_destroy_cq(sgmii_dev.flow[0].recv_cq))
			printk(KERN_WARNING PFX "sx_sgmii_remove_one: ib_destroy_cq failed\n");
		else
			printk(KERN_DEBUG PFX "sx_sgmii_remove_one: ib_destroy_cq finished successfully\n");

		sgmii_dev.flow[0].recv_cq = NULL;
	}

	if (sgmii_dev.flow[0].mr) {
		if (ib_dereg_mr(sgmii_dev.flow[0].mr))
			printk(KERN_WARNING PFX "sx_sgmii_remove_one: ib_dereg_mr failed\n");
		else
			printk(KERN_DEBUG PFX "sx_sgmii_remove_one: ib_dereg_mr finished successfully\n");

		sgmii_dev.flow[0].mr = NULL;
	}

	if (sgmii_dev.pd) {
		if (ib_dealloc_pd(sgmii_dev.pd))
			printk(KERN_WARNING PFX "sx_sgmii_remove_one: ib_dealloc_pd failed\n");
		else
			printk(KERN_DEBUG PFX "sx_sgmii_remove_one: ib_dealloc_pd finished successfully\n");

		sgmii_dev.pd = NULL;
	}

	sgmii_dev.ib_device = NULL;
	sgmii_dev.port_number = 0;

	printk(KERN_INFO PFX "sx_sgmii_remove_one: Finished successfully\n");

	return;
}

static struct ib_client sgmii_client = {
	.name   = "sx_sgmii",
	.add    = sx_sgmii_add_one,
	.remove = sx_sgmii_remove_one
};

int sx_sgmii_init(void)
{
	int ret = 0;
	
	if (sx_glb.sx_sgmii.initialized == 1)
		return 0;

	if (sx_glb.sx_sgmii.base_smac == 0) {
		printk(KERN_WARNING PFX "sx_sgmii_init: SGMII base SMAC was not "
				"yet set. Cannot initialize SGMII\n");
		return -EFAULT;
	}

	memset(&sgmii_dev, 0, sizeof (sgmii_dev));
	tasklet_init(&sx_sgmii_tasklet, sx_sgmii_tasklet_handler, 0);
	ret = ib_register_client(&sgmii_client);
	if (ret) {
		printk(KERN_WARNING PFX "sx_sgmii_init: ib_register_client failed "
				"with err %d\n", ret);
		goto out_kill;
	}

	/* ib_register_client calls sx_sgmii_add_one for each IB device. 
	 * sgmii_err tells us if sx_sgmii_add_one had a fatal failure. */
	if (sgmii_err) {
		printk(KERN_WARNING PFX "sx_sgmii_init: sx_sgmii_init_one failed "
				"with err %d\n", sgmii_err);
		ret = sgmii_err;
		sgmii_err = 0;
		goto out_unregister;
	}

	spin_lock_init(&sgmii_dev.flow[0].tx_ring_lock);
	spin_lock_init(&sgmii_dev.flow[0].rx_ring_lock);
	sema_init(&sgmii_cmd_sem, 1);
	sx_glb.sx_sgmii.initialized = 1;
	printk(KERN_INFO PFX "SGMII initialization completed successfully\n");

	return ret;

out_unregister:
	ib_unregister_client(&sgmii_client);
out_kill:
	tasklet_kill(&sx_sgmii_tasklet);

	return ret;
}

void sx_sgmii_deinit(void)
{
	if (sx_glb.sx_sgmii.initialized == 0)
		return;

	sx_glb.sx_sgmii.initialized = 0;
	ib_unregister_client(&sgmii_client);
	tasklet_kill(&sx_sgmii_tasklet);

	return;
}

int sx_sgmii_build_encapsulation_header(struct sk_buff *skb, u64 dmac, u64 smac,
		u16 ethertype, u8 proto, u8 ver)
{
	struct sx_ethernet_header *p_hdr;

	p_hdr = (struct sx_ethernet_header *)skb_push(skb, sizeof (*p_hdr));
	if (p_hdr == NULL) {
		if (printk_ratelimit())
			printk(KERN_WARNING PFX "sx_build_eth_header: "
				"Error in skb_push\n");
		return -ENOMEM;
	}

	memset(p_hdr, 0, sizeof(*p_hdr));
	dmac = cpu_to_be64(dmac);
	smac = cpu_to_be64(smac);
	memcpy(p_hdr->dmac, ((void *)&dmac) + 2, 6);
	memcpy(p_hdr->smac, ((void *)&smac) + 2, 6);
	p_hdr->et = cpu_to_be16(ethertype);
	p_hdr->mlx_proto = proto;
	p_hdr->ver = (u8)(ver << 4);

	return 0;
}

int sx_sgmii_build_ctrl_segment(struct sk_buff *skb, u8 lp, u8 sdqn, enum sx_sgmii_pkt_type_t pkt_type)
{
	struct sx_sgmii_ctrl_segment *p_hdr;

	//WARNING: it's patch to overcome the ARCH bug:
	switch (lp){
	case 0:
		//This case is cr_space for control segment. Align it to WQE meaning (=FDB)
		lp = 2;
		break;
	case 2:
		//Set it as cr_space
		lp = 0;
		break;
	default:
		break;
	}
	//--------------------------------------------
	p_hdr = (struct sx_sgmii_ctrl_segment *)skb_push(skb, sizeof (*p_hdr));
	if (p_hdr == NULL) {
		if (printk_ratelimit())
			printk(KERN_WARNING PFX "sx_sgmii_build_ctrl_segment: "
				"Error in skb_push\n");
		return -ENOMEM;
	}

	memset(p_hdr, 0, sizeof(*p_hdr));
	p_hdr->one = 2; /* 1 in bit 17 */
	p_hdr->type_sdq_lp |= (u16)(pkt_type << 7);
	p_hdr->type_sdq_lp |= (u16)(sdqn << 2);
	p_hdr->type_sdq_lp |= (u16)lp;
	p_hdr->type_sdq_lp = cpu_to_be16(p_hdr->type_sdq_lp);

	return 0;
}

/* rw - 1 = read, 0 = write */
int sx_sgmii_build_cr_space_header_switchx(struct sk_buff *skb, u8 token, u8 rw, u32 address, u8 size)
{
	u32 *p_hdr;

	p_hdr = (u32 *)skb_push(skb, CR_SPACE_SEGMENT_SIZE);
	if (p_hdr == NULL) {
		if (printk_ratelimit())
			printk(KERN_WARNING PFX "sx_sgmii_build_cr_space_segment: "
				"Error in skb_push\n");
		return -ENOMEM;
	}

	*p_hdr = 0;
	*p_hdr |= (token << 24);

	/* The rw field in BAZ is located in bit 20: */
	*p_hdr |= ((rw << 20) & 0x100000);

	/* The address rage in BAZ is 19:2 */
	*p_hdr |= (address & 0xffffc);

	*p_hdr |= (size & 0x3);
	*p_hdr = cpu_to_be32(*p_hdr);

#ifdef SX_DEBUG
		printk(KERN_DEBUG PFX "sx_sgmii_build_cr_space_segment_switchx: "
				"rw = %u, address = 0x%x, size = %u, p_hdr = 0x%x\n",
				rw, address, size, *p_hdr);
#endif

	return 0;
}

/* rw - 1 = read, 0 = write */
int sx_sgmii_build_cr_space_header_spectrum(struct sk_buff *skb, u8 token, u8 rw, u32 address, u8 size)
{
	u32 *p_hdr;

	p_hdr = (u32 *)skb_push(skb, CR_SPACE_SEGMENT_SIZE);
	if (p_hdr == NULL) {
		if (printk_ratelimit())
			printk(KERN_WARNING PFX "sx_sgmii_build_cr_space_segment: "
				"Error in skb_push\n");
		return -ENOMEM;
	}

	*p_hdr = 0;
	*p_hdr |= (token << 24);

	/* In Pelican/Condor, the rw feild is located in bit 23: */
	*p_hdr |= ((rw << 23) & 0x800000);

	/* In Pelican/Condor, the address range is 22:2 */
	*p_hdr |= (address & 0x3ffffc);
	
	*p_hdr |= (size & 0x3);
	*p_hdr = cpu_to_be32(*p_hdr);

#ifdef SX_DEBUG
		printk(KERN_DEBUG PFX "sx_sgmii_build_cr_space_segment: "
				"rw = %u, address = 0x%x, size = %u, p_hdr = 0x%x\n",
				rw, address, size, *p_hdr);
#endif

	return 0;
}

/* rw - 1 = read, 0 = write */
static int sx_sgmii_build_cr_space_header(struct sk_buff *skb, u8 token, u8 rw, u32 address, u8 size)
{
	unsigned long   flags;
	struct sx_dev   *dev = NULL;

	dev = sx_glb.tmp_dev_ptr;
	if (!dev) {
		printk(KERN_WARNING PFX "sx_sgmii_build_cr_space_segment: "
			   "Device doesn't exist. Aborting\n");
		return -ENXIO;
	}

	spin_lock_irqsave(&sx_priv(dev)->db_lock, flags);

	if (dev && (sx_priv(dev)->dev_specific_cb.sx_sgmii_build_cr_space_header_cb != NULL)) {
		sx_priv(dev)->dev_specific_cb.sx_sgmii_build_cr_space_header_cb(skb, token, rw,
				address, size);
	} else {
		printk(KERN_ERR PFX "Error retrieving sx_sgmii_build_cr_space_header_cb callback\n");
		spin_unlock_irqrestore(&sx_priv(dev)->db_lock, flags);
		return -EINVAL;
	}

	spin_unlock_irqrestore(&sx_priv(dev)->db_lock, flags);
	return 0;
}

u32 sx_sgmii_cr_space_readl(int dev_id, u32 address, int *err)
{
	struct sk_buff *skb;
	unsigned long end, timeout = 10000;
	u32 val = 0;

	skb = alloc_skb(CR_SPACE_COMMAND_SIZE +
			sizeof(struct sx_sgmii_ctrl_segment) +
			sizeof(struct sx_ethernet_header), GFP_KERNEL);
	if (!skb)
		return -ENOMEM;

	skb_reserve(skb, CR_SPACE_SEGMENT_SIZE +
			sizeof(struct sx_sgmii_ctrl_segment) +
			sizeof(struct sx_ethernet_header));
	memset(skb_put(skb, CR_SPACE_DATA_SIZE), 0, CR_SPACE_DATA_SIZE);
	*err = sx_sgmii_build_cr_space_header(skb, cr_space_token, 1, address, 1);
	if (*err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_readl: Failed building the "
				"CR space segment of the header\n");
		goto out;
	}

	*err = sx_glb.sx_sgmii.build_ctrl_segment(skb, SX_SGMII_OOB_PKT_CTRL_HDR_LP_CR_SPACE
			/* 2, WARNING, patch. See notes in the function*/, 0, 0);
	if (*err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_readl: Failed building the "
				"control segment of the header\n");
		goto out;
	}

	*err = sx_glb.sx_sgmii.build_encapsulation_header(skb,
			sx_glb.sx_dpt.dpt_info[dev_id].sx_sgmii_info.dmac,
			sx_glb.sx_sgmii.base_smac,
			ETHTYPE_EMAD, 0, 0);
	if (*err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_readl: Failed building the "
				"encapsulation header\n");
		goto out;
	}

	down(&sgmii_cmd_sem); /* So others will not send CMDs */
	*err = sx_glb.sx_sgmii.send(skb);
	if (*err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_readl: Failed to transmit the packet\n");
		goto out;
	}

	end = msecs_to_jiffies(timeout) + jiffies;
	while (cmd_resp == NULL && time_before(jiffies, end))
		cond_resched();

	if (cmd_resp == NULL) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_readl: Timeout waiting for the response packet\n");
		*err = -ETIMEDOUT;
		goto out;
	}

	//val = be32_to_cpu(*(u32 *)cmd_resp->data);
	val = *(u32 *)cmd_resp->data;
	kfree_skb(cmd_resp);
	cmd_resp = NULL;

out:
	up(&sgmii_cmd_sem); /* Now others can send CMDs */
	return val;
}

int sx_sgmii_cr_space_writel(int dev_id, u32 address, u32 value)
{
	struct sk_buff *skb;
	unsigned long end, timeout = 10000;
	int err = 0;

	skb = alloc_skb(CR_SPACE_COMMAND_SIZE +
			sizeof(struct sx_sgmii_ctrl_segment) +
			sizeof(struct sx_ethernet_header), GFP_KERNEL);
	if (!skb)
		return -ENOMEM;

	skb_reserve(skb, CR_SPACE_SEGMENT_SIZE +
			sizeof(struct sx_sgmii_ctrl_segment) +
			sizeof(struct sx_ethernet_header));
	memset(skb_put(skb, CR_SPACE_DATA_SIZE), 0, CR_SPACE_DATA_SIZE);
	//*(u32 *)(skb->data) = cpu_to_be32(value);
	*(u32 *)(skb->data) = value;
	err = sx_sgmii_build_cr_space_header(skb, cr_space_token, 0, address, 1);
	if (err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_writel: Failed building the "
				"CR space segment of the header\n");
		goto out;
	}

	err = sx_glb.sx_sgmii.build_ctrl_segment(skb, SX_SGMII_OOB_PKT_CTRL_HDR_LP_CR_SPACE
			/* 2, WARNING, patch. See notes in the function*/, 0, 0);
	if (err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_writel: Failed building the "
				"control segment of the header\n");
		goto out;
	}

	err = sx_glb.sx_sgmii.build_encapsulation_header(skb,
			sx_glb.sx_dpt.dpt_info[dev_id].sx_sgmii_info.dmac,
			sx_glb.sx_sgmii.base_smac,
			ETHTYPE_EMAD, 0, 0);
	if (err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_writel: Failed building the "
				"encapsulation header\n");
		goto out;
	}

	down(&sgmii_cmd_sem); /* So others will not send CMDs */
	err = sx_glb.sx_sgmii.send(skb);
	if (err) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_writel: Failed to transmit the packet\n");
		goto out;
	}

	end = msecs_to_jiffies(timeout) + jiffies;
	while (cmd_resp == NULL && time_before(jiffies, end))
		cond_resched();

	if (cmd_resp == NULL) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_writel: Timeout waiting for the response packet\n");
		err = -ETIMEDOUT;
		goto out;
	}

	kfree_skb(cmd_resp);
	cmd_resp = NULL;

out:
	up(&sgmii_cmd_sem); /* Now others can send CMDs */
	return err;
}

/* We can only write up to 4 dwords in each transaction,
 * but for simplicity we will only write 1 dword at a time */
int sx_sgmii_cr_space_write_buf(int dev_id, u32 address,
				unsigned char *buf, int size)
{
	int err = 0;
	int i;

	if (size == 0 || size%4) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_write_buf: Cannot write a buffer"
				" of size %u since it's not a power of 4\n", size);
		return -EFAULT;
	}

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "sx_sgmii_cr_space_write_buf: Going to write buf of "
			"size %d to address 0x%x\n", size, address);
#endif
	for (i = 0; i < size; i+= 4) {
		u32 value = *(u32 *)(buf + i);

		err = sx_glb.sx_sgmii.cr_space_writel(dev_id, address + i, value);
		if (err) {
			printk(KERN_ERR PFX "Failed writing a dword to the CR space "
					"of device %d through SGMII. err %d\n", dev_id, err);
			return err;
		}

#ifdef SX_DEBUG
		printk(KERN_DEBUG PFX "sx_sgmii_cr_space_write_buf: wrote a dword to "
				"address 0x%x successfully\n", address + i);
#endif
	}

	return err;
}

/* We can only read up to 4 dwords in each transaction,
 * but for simplicity we will only read 1 dword at a time */
int sx_sgmii_cr_space_read_buf(int dev_id, u32 address,
				unsigned char *buf, int size)
{
	int err, i;

	if (size%4) {
		printk(KERN_ERR PFX "sx_sgmii_cr_space_write_buf: Cannot write a buffer"
				" of size %u since it's not a power of 4\n", size);
		return -EFAULT;
	}

#ifdef SX_DEBUG
	printk(KERN_DEBUG PFX "sx_sgmii_cr_space_read_buf: Going to read buf of "
			"size %d from address 0x%x\n", size, address);
#endif
	for (i = 0; i < size; i+= 4) {
		*(u32 *)(buf + i) = sx_glb.sx_sgmii.cr_space_readl(dev_id, address + i, &err);
		if (err) {
			printk(KERN_ERR PFX "Failed writing a dword to the CR space "
					"of device %d through SGMII. err %d\n", dev_id, err);
			return err;
		}

#ifdef SX_DEBUG
		printk(KERN_DEBUG PFX "sx_sgmii_cr_space_read_buf: read a dword from "
				"address 0x%x successfully\n", address + i);
#endif
	}

	return 0;
}

void sx_sgmii_init_cb(struct sx_sgmii_ifc *sgmii_ifc) {
	sgmii_ifc->init = sx_sgmii_init;
	sgmii_ifc->deinit = sx_sgmii_deinit;
	sgmii_ifc->send = sx_sgmii_tx;
	sgmii_ifc->build_encapsulation_header = sx_sgmii_build_encapsulation_header;
	sgmii_ifc->build_ctrl_segment = sx_sgmii_build_ctrl_segment;
	sgmii_ifc->cr_space_readl = sx_sgmii_cr_space_readl;
	sgmii_ifc->cr_space_writel = sx_sgmii_cr_space_writel;
	sgmii_ifc->cr_space_read_buf = sx_sgmii_cr_space_read_buf;
	sgmii_ifc->cr_space_write_buf = sx_sgmii_cr_space_write_buf;
}
