/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_ACL_RM_API_H__
#define __SX_ACL_RM_API_H__

#include <sx/acl_rm/sx_acl_rm_types.h>


/************************************************
 *  API functions prototypes
 ***********************************************/

/**
 * This function opens a RPC socket toward ACL RM.
 *
 * @param[in] handle - ACL RM handle
 * @param[in] client_id - the client_id
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if client_id >= MAX_ACL_RM_CLIENT.
 */
sx_acl_rm_status_t sx_acl_rm_api_open(sx_acl_rm_handle_t *handle,
                                      sx_acl_rm_client_t  client_id);

/**
 * This function close the RPC socket toward acl rm
 *
 * @param[in] handle - ACL RM handle
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 */
sx_acl_rm_status_t sx_acl_rm_api_close(sx_acl_rm_handle_t *handle);

/**
 * This function opens a RPC socket toward ACL RM.
 *
 * @param[in] handle - ACL RM handle
 * @param[in] params - ACL RM initialization parameters.
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if client_id >= MAX_ACL_RM_CLIENT.
 */
sx_acl_rm_status_t sx_acl_rm_api_init(sx_acl_rm_handle_t             handle,
                                      const sx_acl_rm_init_params_t *params);

/**
 * This function Create or destroy specific ACL
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd - CREATE / DESTROY
 * @param[in] acl_info a struct which describe the acl
 * @param[in,out] acl_id - the id of the acl given by sdk-api
 * @param[in] acl_type - the type of the acl
 * @param[in] acl_direction - the direction of the acl
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB, i.e the acl_id not found while trying to delete it.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if no ACL is available to create
 * @return SX_ACL_RM _STATUS_CMD_UNSUPPORTED if unsupported command is requested
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_set(sx_acl_rm_handle_t    handle,
                                         sx_acl_rm_cmd_t       cmd,
                                         sx_acl_rm_acl_info_t *acl_info);

/**
 * This function allows the client to resize (decrease / increase) the client ACL table.
 * It checks for the given size and will increase or decrease depends on the current size of the ACL table.
 *
 * @param[in] handle - ACL RM handle
 * @param[in] acl_id - the id of the acl to resize
 * @param[in,out] acl_size - the requested acl new size, returns the size allocated by HW
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB, i.e the acl_id not found while trying to resize it.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if resize fails due to not enough sw resources.
 * * @return SX_ACL_RM_STATUS_NO_HW_RESOURCES if resize fails due to not enough hw resources.
 * @return SX_ACL_RM_STATUS_NO_BUFFER_SPACE - memory allocation of the new acl_size fails.
 * @return SX_ACL_RM_STATUS_ERROR general error.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_resize(const sx_acl_rm_handle_t handle,
                                            const sx_acl_rm_acl_id_t acl_id,
                                            uint32_t                *acl_size);

/**
 * This function add / remove rules from specific ACL
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd - SET / DELETE / EDIT
 * @param[in] acl_id - the id of the acl given by sdk-api
 * @param[in] rule_info_arr - a struct which describe the the rule
 * @param[in] rule_info_num - number of rule in rule info array.
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range.
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB,
 *                                          i.e the acl_id or rule_unique_id not found while trying to delete/edit it.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if there is no more space for rules.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_rule_set(sx_acl_rm_handle_t     handle,
                                              sx_acl_rm_cmd_t        cmd,
                                              sx_acl_rm_acl_id_t     acl_id,
                                              sx_acl_rm_rule_info_t *rule_info_arr,
                                              uint32_t              *rule_info_num);

/**
 * This function retrieves rules of specific ACL.
 * When start_handle is NULL, rules handles are taken from rule_info_arr and their data is retrieved.
 * When start_handle isn't NULL, the API iterates over all rules within ACL,
 * and start_handle will be updated with the handle for subsequent call.
 *
 * @param[in] handle - ACL_RM handle
 * @param[in] acl_id - the id of the acl given by acl rm acl set api
 * @param[in,out] start_handle - Iteration start point.
 * @param[out] rule_info_arr - a struct which describe the
 *       rule content. should be in size of num_of_rules.
 * @param[in,out] rule_info_num - number of rule in rule info array.
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL or SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB, i.e the
 *                                                                              acl_id or rule_unique_id not found while trying to delete/edit it.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_rule_get(sx_acl_rm_handle_t       handle,
                                              sx_acl_rm_acl_id_t       acl_id,
                                              sx_acl_rm_rule_handle_t *start_handle,
                                              sx_acl_rm_rule_info_t   *rule_info_arr,
                                              uint32_t                *rule_info_num);

/**
 * This function binds / unbind ACL to ports
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd - BIND / UNBIND
 * @param[in] acl_id - the id of the acl which represents the acl.
 * @param[in] port_arr - the logical port that should be binded to the acl
 * @param[in] port_num - the number of logical ports that should be bind to the acl in logical_port_arr
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range.
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB,
 *                                          i.e the acl_if or port not found while trying to bind/unbind it.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if there is no more sw resource for bind ACL.
 * @return SX_ACL_RM_STATUS_NO_HW_RESOURCES if there is no more hw resource for bind ACL.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_bind_port_set(sx_acl_rm_handle_t handle,
                                                   sx_acl_rm_cmd_t    cmd,
                                                   sx_acl_rm_acl_id_t acl_id,
                                                   uint32_t          *port_arr,
                                                   uint32_t          *port_num);

/**
 *  This function is used for moving a block of rules within an
 *  ACL region. Moving is allowed before and after ACL bind.
 *  Moving a block does not affect search hits, but may override
 *  existing rules if such exist on the new block location.
 *  Non-valid rules within the block are moved as well.
 *
 * @param[in] handle - ACL_RM handle
 * @param[in] acl_id - the id of the acl given by acl rm acl set api
 * @param[in] block_start - Rules block start offset within the
 *       ACL block
 * @param[in] block_size - Number of rules to move within the
 *       block
 * @param[in] new_block_start - New offset of the first rule of
 *       the given rules block
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes
 *         successfully
 *  @return SX_ACL_RM_STATUS_PARAM_NULL or
 *          SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input
 *          parameter is invalid
 *  @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested
 *              element is not found in DB.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_rule_move_block(sx_acl_rm_handle_t      handle,
                                                     sx_acl_rm_acl_id_t      acl_id,
                                                     sx_acl_rm_rule_offset_t block_start,
                                                     uint32_t                block_size,
                                                     sx_acl_rm_rule_offset_t new_block_start);

/**
 * This function creates/deletes counter
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd - BIND / UNBIND
 * @param[in] counter_type_p - Counter type: Bytes, Packets.
 * @param[in,out] counter_id - Counter ID
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if any element is not found in DB.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if there is no more space for rules.
 */
sx_acl_rm_status_t sx_acl_rm_api_counter_set(sx_acl_rm_handle_t        handle,
                                             sx_acl_rm_cmd_t           cmd,
                                             sx_acl_rm_counter_type_t *counter_type_p,
                                             sx_acl_rm_counter_id_t   *counter_id_p);

/**
 * This function retrieves flow counter using Flow counter id
 * This function retrieves counter value.
 * Note: cmd Read and Clear is not supported in the current release.
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd - Read / Read and Clear / Clear
 * @param[in] counter_id - Counter ID
 * @param[out] counter_type_p - the type of the counter
 * @param[out] counter_value_p - the value of the counter
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if counter_value_p is NULL
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if counter_id was not allocated
 */
sx_acl_rm_status_t sx_acl_rm_api_counter_get(sx_acl_rm_handle_t         handle,
                                             sx_acl_rm_cmd_t            cmd,
                                             sx_acl_rm_counter_id_t     counter_id,
                                             sx_acl_rm_counter_type_t  *counter_type_p,
                                             sx_acl_rm_counter_value_t *counter_value_p);

/**
 * This function sets multicast groups to be used in forwarding
 * actions. setting a multicast group consumes a resource out of
 * the FDB. the multicast group is created with access cmd ADD
 * and afterwards ports can be added or deleted from the group
 * by using ADD_PORTS or DELETE_PORTS access cmd. in order to
 * delete the group use DELETE cmd when the multicast group is
 * not in use by any rule
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd - ADD / ADD_PORTS / DELETE_PORTS / DELETE
 * @param[in] port_num -  relevant only on ADD_PORTS &
 *       DELETE_PORTS cmd. represents the number of ports to add
 *       or delete (size of port_arr)
 * @param[in] port_arr  - array of logical ports
 * @param[in,out] mcg_id - multicast group ID. given when ADD
 *       command is used, and used as index for all other
 *       commands
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range.
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB,
 *                                          i.e the acl_name or logical_port not found while trying to bind/unbind it.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if there is no more space for rules.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_mc_group_set(sx_acl_rm_handle_t  handle,
                                                  sx_acl_rm_cmd_t     cmd,
                                                  uint32_t            port_num,
                                                  sx_acl_rm_port_t   *port_arr,
                                                  sx_acl_rm_mcg_id_t *mcg_id);

/**
 * This function gets a multicast group
 *
 * @param[in] handle - ACL RM handle
 * @param[in] mcg_id -  multicast group ID
 * @param[in,out] port_num - indicates the size of the ports
 *       array and returns the actual number of ports found
 * @param[in,out] port_arr - array for getting the ports, its
 *       size is allocated by the user
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range.
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB,
 *                                          i.e the acl_name or logical_port not found while trying to bind/unbind it.
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if there is no more space for rules.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_mc_group_get(sx_acl_rm_handle_t handle,
                                                  sx_acl_rm_mcg_id_t mcg_id,
                                                  uint32_t          *port_num,
                                                  sx_acl_rm_port_t  *port_arr);

/**
 * This function binds or unbinds an ACL to/from the system
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd -  BIND/UNBIND
 * @param[in] acl_id - ACL ID to be bound or unbound to/from system
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds
 *                 range.
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 * @return SX_ACL_RM_STATUS_ENTRY_NOT_FOUND if requested element is not found in
 *                 DB, i.e the acl_id not found while trying to bind/unbind it.
 */
sx_acl_rm_status_t sx_acl_rm_api_acl_bind_system_set(sx_acl_rm_handle_t handle,
                                                     sx_acl_rm_cmd_t    cmd,
                                                     sx_acl_rm_acl_id_t acl_id);

/**
 * This function adds or deletes a port to/from the system ACLs - in other words,
 * when a port is added, all system ACLs will be bound to it, and when a port is
 * deleted, all system ACLs will be unbound from it.
 *
 * @param[in] handle - ACL RM handle
 * @param[in] cmd -  ADD_PORTS/DELETE_PORTS
 * @param[in] logical_port_arr - logical ports being added/deleted
 * @param[in] num_ports - number of ports in logical_port_arr
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if any input parameter is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds
 *                 range.
 * @return SX_ACL_RM_ STATUS_CMD_UNSUPPORTED if unsupported command is requested
 */
sx_acl_rm_status_t sx_acl_rm_api_port_set(sx_acl_rm_handle_t handle,
                                          sx_acl_rm_cmd_t    cmd,
                                          sx_acl_rm_port_t  *logical_port_arr,
                                          uint32_t           port_num);

/**
 * This function writes ACL-RM data bases to the given path file.
 * In case path is NULL, it will write to log file.
 *
 * @param[in] handle - ACL RM handle
 * @param[in] file_path -  file path for writing ACL-RM DB (may be NULL)
 *
 * @return SX_ACL_RM_STATUS_SUCCESS if operation completes successfully
 * @return SX_ACL_RM_STATUS_PARAM_NULL if handle parameter is invalid
 * @return SX_ACL_RM_STATUS_NO_RESOURCES if cannot allocate sw resources.
 * @return SX_ACL_RM_STATUS_NO_BUFFER_SPACE if write to file fails.
 */
sx_acl_rm_status_t sx_acl_rm_api_generate_dump(sx_acl_rm_handle_t handle,
                                               const char        *file_path);

#endif /* __SX_ACL_RM_API_H__ */
