/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_ACL_H__
#define __SX_ACL_H__

#include <stdlib.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_policer.h>
#include <sx/sdk/sx_fcf.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_ip.h>

/************************************************
 *  Type definitions
 ***********************************************/

typedef uint16_t sx_acl_vlan_group_t;
typedef uint16_t sx_acl_lookup_priority_t;
typedef uint16_t sx_acl_rule_offset_t;
typedef uint32_t sx_acl_size_t;


/**
 * describes ACL group or ACL table
 */
typedef uint32_t sx_acl_region_id_t;
typedef uint32_t sx_acl_id_t;
typedef uint8_t sx_acl_port_range_id_t;
typedef uint32_t sx_acl_pbs_id_t;

#define SX_ACL_PBS_ID_INVALID (0xFFFFFFFF)

/******************************
 *   DEFINITIONS
 *******************************/

typedef enum {
    SX_API_ACL_SEARCH_TYPE_SERIAL,
    SX_API_ACL_SEARCH_TYPE_PARALLEL,
    SX_API_ACL_SEARCH_TYPE_LAST,
} sx_acl_search_type_t;

/**
 * sx_acl_params_t type is used to note ACL library
 * init parameters
 */
typedef struct {
    uint8_t              max_swid_id;
    uint8_t              max_acl_ingress_groups;
    uint8_t              max_acl_egress_groups;
    uint32_t             min_acl_rules;
    uint32_t             max_acl_rules;
    uint16_t             max_vlan_groups; /**< max_vlan_groups - Maximum number VLAN Groups for VLAN binding */
    uint16_t             max_rifs;
    sx_acl_search_type_t acl_search_type;
} sx_acl_params_t;

/**
 * sx_acl_dmac_type_t enumerated type is used to note
 * Destination MAC type used in ACL keys
 */
typedef enum {
    SX_ACL_DMAC_TYPE_UNICAST = 0,           /**< Unicast destination MAC  */
    SX_ACL_DMAC_TYPE_MULTICAST = 1,         /**< Multicast destination MAC  */
    SX_ACL_DMAC_TYPE_BROADCAST = 2          /**< Broadcast destination MAC  */
} sx_acl_dmac_type_t;

/**
 * sx_acl_action_learning_mode_t enumerated type is used
 * to change learn mode for a specific packet
 */
typedef enum {
    SX_ACL_ACTION_FDB_LEARNING_ENABLED = 0,       /**< Treat this packet as a regular packet */
    SX_ACL_ACTION_FDB_LEARNING_DISABLED = 1       /**< disable FDB learning for the packet */
} sx_acl_action_learning_mode_t;

/**
 * sx_acl_action_routing_mode_t enumerated type is used
 * to let a packet bypass the router module.
 */
typedef enum {
    SX_ACL_ACTION_ROUTING_ENABLED = 0,            /**< Treat this packet as a regular packet */
    SX_ACL_ACTION_ROUTING_DISABLED = 1            /**< disable IP routing for the packet */
} sx_acl_action_routing_mode_t;

/**
 * sx_acl_dmac_type_t enumerated type is used to note
 * Vlan type used in ACL keys
 */
typedef enum {
    SX_ACL_VLAN_TYPE_UNTAGGED = 0,          /**< Packet is untagged  */
    SX_ACL_VLAN_TYPE_TAGGED = 2             /**< Packet has 802.1Q vlan tag  */
} sx_acl_vlan_type_t;


/**
 * sx_acl_key_type_t enumerated type is used to note key type
 * used in ACL region block
 */
typedef enum {
    SX_ACL_KEY_TYPE_IPV4_FULL = 0,          /**< Key with IPv4 fields  */
    SX_ACL_KEY_TYPE_IPV6_FULL = 1,          /**< Key with IPv6 fields  */
    SX_ACL_KEY_TYPE_MAC_FULL = 2,           /**< Key with MAC fields   */
    SX_ACL_KEY_TYPE_MAC_IPV4_FULL = 3,      /**< Key with IPv4 and MAC fields */
    SX_ACL_KEY_TYPE_FCOE_FULL = 4,          /**< Key with FCoE fields */
    SX_ACL_KEY_TYPE_MAC_SHORT = 5,          /**< Key with short MAC fields   */
    SX_ACL_KEY_TYPE_MAX = SX_ACL_KEY_TYPE_MAC_SHORT,
    SX_ACL_KEY_TYPE_LAST
} sx_acl_key_type_t;


/**
 * sx_acl_acl_type_t enumerated type is used to note ACL types
 * used for ACL creation
 */
typedef enum sx_acl_type {
    SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC = 0,          /**< ACL type for all packet types */
    SX_ACL_TYPE_PACKET_TYPES_SENSITIVE = 1,         /**< ACL type with bound ACL regions per packet type */
    SX_ACL_TYPE_MAX = SX_ACL_TYPE_PACKET_TYPES_SENSITIVE,
    SX_ACL_TYPE_LAST
} sx_acl_type_t;

/**
 * sx_acl_region_packet_type_t enumerated type is used to note
 * ACL region packet types for packet type sensitive ACLs.
 */
typedef enum {
    SX_ACL_REGION_PKT_TYPE_IPV4 = 0,                /**< ACL region packet type IPv4  */
    SX_ACL_REGION_PKT_TYPE_IPV6 = 1,                /**< ACL region packet type IPv6  */
    SX_ACL_REGION_PKT_TYPE_NON_IP = 2,              /**< ACL region packet type reserved  */
    SX_ACL_REGION_PKT_TYPE_MAX = SX_ACL_REGION_PKT_TYPE_NON_IP,
    SX_ACL_REGION_PKT_TYPE_LAST
} sx_acl_region_packet_type_t;

typedef struct sx_acl_packet_agnostic_regions {
    sx_acl_region_id_t region;
} sx_acl_packet_agnostic_regions_t;

typedef struct sx_acl_packet_sensitive_regions {
    sx_acl_region_id_t non_ip_region;
    sx_acl_region_id_t ipv4_region;
    sx_acl_region_id_t ipv6_region;
} sx_acl_packet_sensitive_regions_t;

/**
 * sx_acl_region_group_t structure is used to note
 * ACL region group for all ACL types.
 */
typedef struct sx_acl_region_group {
    sx_acl_type_t acl_type;
    union {
        sx_acl_packet_agnostic_regions_t  acl_packet_agnostic;
        sx_acl_packet_sensitive_regions_t acl_packet_sensitive;
    } regions;
} sx_acl_region_group_t;

/**
 * sx_acl_action_type_t enumerated type is used to note Action
 * type used in ACL block
 */
typedef enum sx_acl_action_type {
    SX_ACL_ACTION_TYPE_BASIC = 0,           /**< Basic action set  */
    SX_ACL_ACTION_TYPE_EXTENDED = 1,        /**< Extended action set  */
    SX_ACL_ACTION_TYPE_MAX = SX_ACL_ACTION_TYPE_EXTENDED,
    SX_ACL_ACTION_TYPE_LAST
} sx_acl_action_type_t;

/**
 * sx_acl_direction_t enumerated type is used to note ACL bind
 * direction
 */
typedef enum {
    SX_ACL_DIRECTION_INGRESS = 0,        /**< bind to ingress direction  */
    SX_ACL_DIRECTION_EGRESS = 1,         /**< bind to egress direction  */
    SX_ACL_DIRECTION_RIF_INGRESS = 2,    /**< SPC only */
    SX_ACL_DIRECTION_RIF_EGRESS = 3,     /**< SPC only */
    SX_ACL_DIRECTION_MAX = SX_ACL_DIRECTION_RIF_EGRESS,
    SX_ACL_DIRECTION_LAST
} sx_acl_direction_t;

/**
 * sx_acl_port_range_apply_flags_t enumerated type is used to
 * note sx_acl_port_range_entry_t apply_flags field possible
 * values
 */

/**
 * sx_acl_trap_action_t enumerated type is used to note
 * action trap action type
 */
typedef enum {
    SX_ACL_TRAP_ACTION_PERMIT = 0,           /**< Permit packets action  */
    SX_ACL_TRAP_ACTION_SOFT_DROP = 0x1,        /**< Soft-drop packets action  */
    SX_ACL_TRAP_ACTION_TRAP = 0x2,             /**< Trap packets action, trap group and trap ID should be stated  */
    SX_ACL_TRAP_ACTION_DROP_TRAP = 0x3,        /**< Trap & soft drop packets action  */
    SX_ACL_TRAP_ACTION_DENY = 0x4,              /**< Deny packets action  */
    SX_ACL_TRAP_ACTION_LAST
} sx_acl_trap_action_t;

typedef struct sx_acl_trap_info {
    uint8_t  trap_group;                  /**< trap group to use when trapping to CPU  */
    uint16_t trap_id;                     /**< trap ID to be reported to CPU: 0x1c0 - 0x1ef */
} sx_acl_trap_info_t;

/**
 * sx_acl_vlan_prio_action_t enumerated type is used to note
 * action vlan and priority action type
 */
typedef enum {
    SX_ACL_VLAN_PRIO_ACTION_NOP = 0,                                    /**< No action is done per VID and priority */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_ETCLASS_KEEP_RPRIO = 0x01,          /**< egress tclass will be replaced  (egress only) */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_RPRIO_KEEP_ETCLASS = 0x02,          /**< regenerated priority value will be replaced (egress only) */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_ETCLASS_RPRIO = 0x03,               /**< egress tclass and regenerated priority value will be replaced (egress only) */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_PRIO = 0x04,                        /**< priority value will be replaced */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_STCLASS = 0x06,                     /**< replace the stacking tclass with stclass */
    SX_ACL_VLAN_PRIO_ACTION_PUSH_VID_KEEP_PRIO = 0x08,                  /**< VID is pushed, priority is kept */
    SX_ACL_VLAN_PRIO_ACTION_PUSH_VID_PRIO = 0x0c,                       /**< VID and priority are pushed to packet*/
    SX_ACL_VLAN_PRIO_ACTION_POP_VID_PRIO = 0x10,                        /**< VID and priority popped */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_VID_KEEP_PRIO = 0x18,               /**< VID is replaced, priority is kept */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_VID_PRIO = 0x1c,                    /**< VID and priority are replaced */
    SX_ACL_VLAN_PRIO_ACTION_FWD_BY_VID = 0x20,                          /**< Forward by vid (packet not modified, ingress ACL only) */
} sx_acl_vlan_prio_action_t;

/**
 * sx_acl_port_range_direction_t enumerated type is used to note
 * port range direction type
 */
typedef enum {
    SX_ACL_PORT_DIRECTION_SOURCE = 0,   /**< Apply port range to source L4 ports  */
    SX_ACL_PORT_DIRECTION_DESTINATION,  /**< Apply port range to destination L4 ports  */
    SX_ACL_PORT_DIRECTION_BOTH,         /**< Apply port range to source and destination L4 ports  */
    SX_ACL_PORT_DIRECTION_MAX = SX_ACL_PORT_DIRECTION_BOTH,
} sx_acl_port_range_direction_t;

/**
 * sx_acl_port_range_ip_header_t
 */

typedef enum {
    SX_ACL_PORT_RANGE_IP_HEADER_OUTER = 0,    /**< Apply port range to outer IP header */
    SX_ACL_PORT_RANGE_IP_HEADER_INNER,        /**< Apply port range to inner IP header  */
    SX_ACL_PORT_RANGE_IP_HEADER_BOTH,         /**< Apply port range both outer and inner IP headers */
    SX_ACL_PORT_RANGE_IP_HEADER_MAX = SX_ACL_PORT_RANGE_IP_HEADER_BOTH,
} sx_acl_port_range_ip_header_t;

/**
 * sx_acl_port_range_entry_t struct is used when setting
 * ACL layer 4 port range entry. Match is defined when
 * port_range_min <= port <= port_range_max
 */
typedef struct {
    uint16_t                      port_range_min;   /**< Minimum port range for comparison  */
    uint16_t                      port_range_max;   /**< Maximum port range for comparison  */
    sx_acl_port_range_direction_t port_range_direction;      /**< Source/Destination/Both  */
    sx_acl_port_range_ip_header_t port_range_ip_header;      /**< outer/inner/both. Device supported : Spectrum. */
    boolean_t                     port_range_ip_length;      /* Device supported : Spectrum. When set the range_min and range_max applies to ip length field and not to l4 port */
} sx_acl_port_range_entry_t;

/**
 * sx_acl_pbs_entry_type_t enumerated type is used to note PBS
 * entry type
 */
typedef enum {
    SX_ACL_PBS_ENTRY_TYPE_UNICAST = 0,      /**< Unicast entry  */
    SX_ACL_PBS_ENTRY_TYPE_ROUTING,          /**< Forward to router */
    SX_ACL_PBS_ENTRY_TYPE_MULTICAST,        /**< Multicast entry */
    SX_ACL_PBS_ENTRY_TYPE_FCF,              /**< Forward to FCF block */
    SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST,   /**< Output Unicast entry - Spectrum */
    SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST, /**< Output Multicast entry - Spectrum */
    SX_ACL_PBS_ENTRY_TYPE_MAX = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST
} sx_acl_pbs_entry_type_t;


/**
 * sx_acl_pbs_entry_t struct type is used to note PBS entry
 * fields
 */
typedef struct {
    sx_acl_pbs_entry_type_t entry_type;         /**< entry type  */
    uint32_t                port_num;           /**< Port number, user is required to allocate enough memory for log_ports  */
    sx_port_id_t          * log_ports;          /**< Variable-length ports list, it's size according to port_num */
} sx_acl_pbs_entry_t;

/**
 * sx_acl_rule_ipv4_ipv6_full_key_t struct type is used to
 * note ipv4 and ipv6 full key fields
 */
typedef struct {
    uint32_t         dst_ip[4];      /**< Destination IP, IPv6 or IPv4. For ARP, Target protocol address */
    uint32_t         src_ip[4];      /**< Source IP, IPv6 or IPv4. For ARP, Sender protocol address */
    uint16_t         src_l4_port;    /**< source L4 port - for ICMP contains type[7:0], code{7:0] */
    uint16_t         dst_l4_port;    /**< Destination L4 port  */
    uint8_t          ttl;            /**< TTL field  */
    uint8_t          tcp_flags;      /**< TCP flags  */
    uint8_t          ip_proto;       /**< IP next protocol  */
    uint8_t          ip_tos;         /**< IP Type of Service  */
    uint8_t          ip_ok;          /**< IP Header is OK bit flag  */
    uint8_t          l4_ok;          /**< Layer 4 header is OK bit flag  */
    uint8_t          is_ipv4;        /**< Packet is IPv4 bit flag */
    uint8_t          is_ipv6;        /**< Packet is IPv6 bit flag */
    uint8_t          ip_opt;         /**< Packet contains IPv4 options bit flag  */
    uint8_t          ip_frg;         /**< IP non-first fragment bit flag  */
    uint8_t          tcp;            /**< Packet is TCP bit flag  */
    uint8_t          udp;            /**< Packet is UDP bit flag  */
    uint8_t          arp;            /**< Packet is ARP/Neighbor discovery packet bit flag  */
    uint8_t          ipv6_ext;       /**< IPv6 extended headers present  */
    sx_port_log_id_t dst_port;       /**< Destination port. MUST be 0 for Ingress ACL */
    sx_port_log_id_t src_port;       /**< Source port / LAG ID  */
    boolean_t        port_range_apply_arr[RM_API_ACL_PORT_RANGES_MAX]; /**< Which port ranges to use - logical AND between them  */
    uint32_t         flow_label;     /**< IPv6 flow label  */
} sx_acl_rule_ipv4_ipv6_full_key_t;

/**
 * sx_acl_rule_mac_full_key_t struct type is used to note
 * mac full key fields
 */
typedef struct {
    sx_mac_addr_t      dmac;            /**< Destination MAC address */
    sx_mac_addr_t      smac;            /**< Source MAC address */
    uint16_t           ethertype;       /**< L2 Ethertype */
    uint8_t            priority;        /**< Packet priority from tag or default priority */
    uint8_t            cfi;             /**< 802.1Q tag CFI field */
    uint16_t           vid;             /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_dmac_type_t dmac_type;       /**< Destination MAC address type */
    uint8_t            vlan_tagged;     /**< Packet was received with Vlan tag (Prio-tagged are considered untagged) */
    uint8_t            vlan_valid;      /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    sx_port_log_id_t   dst_port;        /**< Destination port. MUST be 0 for Ingress ACL */
    sx_port_log_id_t   src_port;        /**< Source port / LAG ID  */
} sx_acl_rule_mac_full_key_t;

/**
 * sx_acl_rule_mac_short_key_t struct type is used to note
 * mac short key fields (18 bytes)
 */
typedef struct {
    sx_mac_addr_t      dmac;            /**< Destination MAC address */
    sx_mac_addr_t      smac;            /**< Source MAC address */
    uint8_t            priority;        /**< Packet priority from tag or default priority */
    uint8_t            cfi;             /**< 802.1Q tag CFI field */
    uint16_t           vid;             /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_dmac_type_t dmac_type;       /**< Destination MAC address type */
    uint8_t            vlan_tagged;     /**< Packet was received with Vlan tag (Prio-tagged are considered untagged) */
    uint8_t            vlan_valid;      /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    sx_port_log_id_t   src_port;        /**< Source port / LAG ID  */
} sx_acl_rule_mac_short_key_t;

/**
 * sx_acl_rule_mac_ipv4_full_key_t struct type is used to
 * note mac IPv4 full key fields
 */
typedef struct {
    sx_mac_addr_t      dmac;            /**< Destination MAC address */
    sx_mac_addr_t      smac;            /**< Source MAC address */
    uint16_t           ethertype;       /**< L2 Ethertype */
    uint8_t            priority;        /**< Packet priority from tag or default priority */
    uint16_t           vid;             /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_vlan_type_t vlan_type;       /**< Vlan type */
    uint8_t            vlan_valid;      /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    uint32_t           dst_ip;          /**< Destination IPv4  */
    uint32_t           src_ip;          /**< Source IPv4  */
    uint16_t           src_l4_port;     /**< source L4 port - for ICMP contains type[7:0], code{7:0] */
    uint16_t           dst_l4_port;     /**< Destination L4 port  */
    uint8_t            ip_proto;        /**< IP next protocol  */
    uint8_t            ip_tos;          /**< IP Type of Service  */
    uint8_t            ip_ok;           /**< IP Header is OK bit flag  */
    uint8_t            l4_ok;           /**< Layer 4 header is OK bit flag  */
    uint8_t            is_ipv4;         /**< Packet is IPv4 bit flag */
    uint8_t            ip_opt;          /**< Packet contains IPv4 options bit flag  */
    uint8_t            ip_frg;          /**< IP non-first fragment bit flag  */
    sx_port_log_id_t   src_port;        /**< Source port / LAG ID  */
} sx_acl_rule_mac_ipv4_full_key_t;


/**
 * sx_acl_rule_fcoe_full_key_t struct type is used to
 * note FCoE full key fields
 */
typedef struct {
    sx_mac_addr_t      dmac;          /**< Destination MAC address */
    sx_mac_addr_t      smac;          /**< Source MAC address */
    uint8_t            priority;      /**< Packet priority from tag or default priority */
    uint16_t           vid;           /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_vlan_type_t vlan_type;     /**< Vlan type */
    uint8_t            vlan_valid;    /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    sx_fc_addr_t       d_id;          /**< Destination ID  */
    sx_fc_addr_t       s_id;          /**< Source ID  */
    uint16_t           ox_id;         /**< Originator eXchange ID  */
    uint16_t           rx_id;         /**< Responder eXchange ID  */
    uint8_t            is_fc;         /**< The packet is a fibre channel packet */
    uint8_t            r_ctl;         /**< Routing control flags  */
    uint8_t            type;          /**< TYPE of FC-4 upper layer protocol  */
    sx_port_log_id_t   src_port;      /**< Source port / LAG ID  */
} sx_acl_rule_fcoe_full_key_t;

/**
 * sx_acl_keys_t union contains set of possible keys to be used
 * within the rule
 */
typedef union {
    sx_acl_rule_ipv4_ipv6_full_key_t ipv4_ipv6_full;    /**< Use when IPv4 or IPv6 is the ACL key type  */
    sx_acl_rule_mac_full_key_t       mac_full;          /**< Use when MAC full is the ACL key type  */
    sx_acl_rule_mac_ipv4_full_key_t  mac_ipv4_full;     /**< Use when MAC and IPv4 full is the ACL key type */
    sx_acl_rule_mac_short_key_t      mac_short;         /**< Use for 18 byte key, (no Ethernet type or dest system port) */
    sx_acl_rule_fcoe_full_key_t      fcoe_full;         /**< Use when FCoE full is the ACL key type */
} sx_acl_keys_t;


/**
 * sx_acl_rule_key_t struct type is used to note mac IPv4 full
 * key fields
 */
typedef struct {
    sx_acl_key_type_t type;          /**< Key type used  */
    sx_acl_keys_t     fields;        /**< Key Fields  */
} sx_acl_rule_key_t;

/**
 * sx_acl_basic_action_set_t structure is used to note
 * basic action fields
 */
typedef struct sx_acl_basic_action_set {
    sx_acl_trap_action_t          trap_action;          /**< trap action  */
    uint8_t                       trap_group;           /**< trap group to use when trapping to CPU  */
    uint16_t                      trap_id;              /**< trap ID to be reported to CPU  */
    sx_acl_vlan_prio_action_t     vlan_prio_action;     /**< Operation to perform on VLAN, priority and TClass  */
    uint16_t                      vid;                  /**< VLAN to be used in accordance with vlan_prio_action  */
    uint8_t                       priority;             /**< priority to be used in accordance with vlan_prio_action  */
    uint8_t                       etclass;              /**< Egress TClass to be used in accordance with vlan_prio_action  */
    uint8_t                       stclass;              /**< Stacking TClass to be used in accordance with vlan_prio_action  */
    uint8_t                       terminate_lookup;     /**< When set to true, terminate lookup on this action  */
    sx_flow_counter_id_t          flow_counter_id;      /**< Counter ID or SX_FLOW_COUNTER_ID_INVALID */
    sx_policer_id_t               policer_id;           /**< Policer ID or SX_POLICER_ID_INVALID */
    sx_acl_action_routing_mode_t  no_ip_routing;        /**< disable IP routing for the packet */
    sx_acl_action_learning_mode_t dont_learn;           /**< disable FDB learning for the packet */
} sx_acl_basic_action_set_t;

/**
 * sx_acl_extended_action_set_t structure is used to note
 * extended action fields
 */
typedef struct sx_acl_extended_action_set {
    sx_acl_pbs_id_t pbs_id;                             /**< Policy Based Switching ID or SX_ACL_PBS_ID_INVALID */
} sx_acl_extended_action_set_t;

/**
 * sx_acl_action_set_t structure is used to note ACL action fields
 */
typedef struct sx_acl_action_set {
    sx_acl_action_type_t         action_type;           /**< Action type  */
    sx_acl_basic_action_set_t    basic_action;          /**< Basic action fields  */
    sx_acl_extended_action_set_t extended_action;       /**< Extended action fields  */
} sx_acl_action_set_t;

/**
 * sx_acl_rule_t struct type is used to note an ACL rule
 * combined of the triplet {key,mask,action}
 * CLR_SX_ACL_RULE_ACTION must be used before setting an ACL rule
 */
typedef struct {
    sx_acl_rule_offset_t offset;        /**<  rule's offset within ACL table */
    uint8_t              valid;         /**<  rule activated in HW  */
    sx_acl_rule_key_t    key;           /**<  Key type and fields used for this rule  */
    sx_acl_rule_key_t    mask;          /**<  Masking of fields in the key for this rule  */
    sx_acl_action_set_t  action;        /**<  Action set used for this rule  */
} sx_acl_rule_t;

/**
 * This Macro clears sx_acl_rule_t action to be a NOP
 */
#define CLR_SX_ACL_RULE_ACTION(rule)                                          \
    memset(&rule.action, 0, sizeof(rule.action));                             \
    rule.action.action_type = SX_ACL_ACTION_TYPE_BASIC;                       \
    rule.action.basic_action.terminate_lookup = FALSE;                        \
    rule.action.basic_action.priority = 0;                                    \
    rule.action.basic_action.trap_action = SX_ACL_TRAP_ACTION_PERMIT;         \
    rule.action.basic_action.vlan_prio_action = SX_ACL_VLAN_PRIO_ACTION_NOP;  \
    rule.action.basic_action.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;    \
    rule.action.basic_action.policer_id = SX_POLICER_ID_INVALID;              \
    rule.action.basic_action.no_ip_routing = SX_ACL_ACTION_ROUTING_ENABLED;   \
    rule.action.basic_action.dont_learn = SX_ACL_ACTION_FDB_LEARNING_ENABLED; \
    rule.action.extended_action.pbs_id = SX_ACL_PBS_ID_INVALID;

#define CLR_SX_ACL_RULE_KEY(key_type, rule) \
    rule.key.type = key_type;               \
    memset(&rule.key.fields, 0, sizeof(rule.key.fields));

#define CLR_SX_ACL_RULE_MASK(key_type, rule) \
    rule.mask.type = key_type;               \
    memset(&rule.mask.fields, 0, sizeof(rule.mask.fields));


/**
 * sx_acl_boulnd_info_t struct type is used to note an ACL rule
 *
 */
typedef struct sx_acl_bound_info {
    sx_acl_region_id_t   acl_region_id;
    sx_acl_rule_offset_t acl_rule_offset;
} sx_acl_bound_info_t;


#endif /* __SX_ACL_H__ */
