/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_TOPO_H__
#define __SX_TOPO_H__

#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_swid.h>
#include <sx/sdk/sx_mac.h>


/************************************************
 *  Type definitions
 ***********************************************/
typedef uint16_t sx_topo_qos_t;
typedef uint16_t sx_tree_hndl_t;
typedef uint16_t sx_mc_tree_group_hndl_t;

typedef struct sx_topo_params {
    uint16_t max_num_of_tree_per_chip;
} sx_topo_params_t;

typedef struct sx_topolib_params {
    uint8_t max_swid_id; /* load balance CB */
} sx_topolib_params_t;

typedef struct sx_topo_lib_dump_db_info {
    sx_dev_id_t    dev_id;
    uint32_t       disp_level;
    sx_tree_hndl_t tree_handle;
} sx_topo_lib_dump_db_info_t;

typedef struct sx_api_topo_dump_db_info {
    sx_access_cmd_t            cmd;
    sx_topo_lib_dump_db_info_t dump_info;
} sx_api_topo_dump_db_info_t;

typedef struct sx_topolib_dev_info {
    sx_dev_id_t        dev_id;
    sx_dev_node_type_t node_type;
    uint16_t           unicast_arr_len;
    sx_tree_hndl_t     unicast_tree_hndl_arr[1];
    sx_mac_addr_t      switch_mac_addr;
/*
 *   sx_tree_hndl_t	*muticast_tree_hndl_arr;
 *   length_t		*multicast_arr_len;
 *   sx_tree_hndl_t		*flood_tree_hndl_arr;
 *   length_t		*flood_arr_len;
 */
} sx_topolib_dev_info_t;

typedef struct sx_api_topo_device_set_params {
    sx_access_cmd_t       cmd;
    sx_topolib_dev_info_t dev_info[0];
} sx_api_topo_device_set_params_t;

typedef struct sx_tree_node {
    sx_dev_id_t peer_dev_id;
    /* port channel that connect the device */
    sx_port_phy_id_t *local_port;
    sx_port_phy_id_t *peer_local_port;
    uint16_t          len;
} sx_tree_node_t;

typedef struct sx_tree_neigh {
    sx_dev_id_t     dev_id;
    uint16_t        dirty;
    sx_tree_node_t *neigh;
    uint16_t        len;
} sx_tree_neigh_t;

typedef struct sx_topo_lib_tree {
    sx_topo_qos_t    tree_qos;
    sx_tree_hndl_t   tree_hndl;
    sx_dev_id_t      mc_root_device;
    sx_tree_neigh_t *tree_dev;
    uint16_t         tree_len;
} sx_topo_lib_tree_t;

typedef struct sx_mc_tree_group_id {
    sx_mc_tree_group_hndl_t tree_hndl;
} sx_mc_tree_group_id_t;

/* mattyk temperary fix size struct */
#define MAX_NUM_OF_TOPO_TREE   126
#define MAX_NUM_OF_TOPO_DEV    54
#define MAX_NUM_OF_NEIGH       36
#define MAX_SIZE_OF_PORT_GROUP 4

typedef struct sx_tree_node_fix {
    sx_dev_id_t peer_dev_id;
    /* port channel that connect the device */
    sx_port_phy_id_t local_port[MAX_SIZE_OF_PORT_GROUP];
    sx_port_phy_id_t peer_local_port[MAX_SIZE_OF_PORT_GROUP];
    uint16_t         len;
} sx_tree_node_fix_t;

typedef struct sx_tree_neigh_fix {
    sx_dev_id_t        dev_id;
    uint16_t           dirty;
    sx_tree_node_fix_t neigh[MAX_NUM_OF_NEIGH];
    uint16_t           len;
} sx_tree_neigh_fix_t;

typedef struct sx_topo_lib_tree_fix {
    sx_topo_qos_t       tree_qos;
    sx_tree_hndl_t      tree_hndl;
    sx_dev_id_t         mc_root_device;
    sx_tree_neigh_fix_t tree_dev[MAX_NUM_OF_TOPO_DEV];
    uint16_t            tree_len;
} sx_topo_lib_tree_fix_t;

typedef sx_status_t (*topo_mc_load_balance_pfn_t)(sx_swid_id_t swid_id, sx_mac_addr_t dmac, sx_port_id_t port_list[],
                                                  uint32_t *port_num_p);

typedef struct sx_api_topo_tree_set_params {
    sx_topo_lib_tree_fix_t tree_info;
    sx_access_cmd_t        cmd;
} sx_api_topo_tree_set_params_t;

#endif /* __SX_TOPO_H__ */
