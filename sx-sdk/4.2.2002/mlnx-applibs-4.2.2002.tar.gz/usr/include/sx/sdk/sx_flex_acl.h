/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef SX_FLEX_ACL_H_
#define SX_FLEX_ACL_H_

#include <stdlib.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_policer.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_span.h>
#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_fcf.h>
#include <sx/sdk/sx_acl.h>
#include <sx/sdk/sx_router.h>
#include <resource_manager/resource_manager.h>

typedef uint16_t sx_flex_acl_rule_offset_t;

typedef uint32_t sx_rif_id_t;

typedef uint16_t sx_user_token_t;

typedef uint32_t sx_acl_port_list_id_t;

/***********************************************
 *  Defines
 **********************************************/
#define KEY_HANDLE_MASK_OFFSET       16
#define FLEX_ACL_KEY_HANDLE_BIT_MASK (0xFF << KEY_HANDLE_MASK_OFFSET)
#define GET_NUM_OF_KEYS(key_handle) ((key_handle & FLEX_ACL_KEY_HANDLE_BIT_MASK) >> KEY_HANDLE_MASK_OFFSET)

typedef enum {
    SX_API_FLEX_ACL_SEARCH_TYPE_SERIAL,
    SX_API_FLEX_ACL_SEARCH_TYPE_PARALLEL,
    SX_API_FLEX_ACL_SEARCH_TYPE_LAST,
} sx_flex_acl_search_type_t;

typedef enum {
    SX_ACL_L2_DMAC_TYPE_MULTICAST = 0,
    SX_ACL_L2_DMAC_TYPE_BROADCAST = 1,
    SX_ACL_L2_DMAC_TYPE_UNICAST = 2,
    SX_ACL_L2_DMAC_TYPE_MIN = SX_ACL_L2_DMAC_TYPE_MULTICAST,
    SX_ACL_L2_DMAC_TYPE_MAX = SX_ACL_L2_DMAC_TYPE_UNICAST,
    SX_ACL_L2_DMAC_TYPE_LAST,
} sx_flex_acl_l2_dmac_type_t;

typedef enum {
    SX_ACL_L3_TYPE_IPV4 = 0,
    SX_ACL_L3_TYPE_IPV6 = 1,
    SX_ACL_L3_TYPE_ARP = 2,
    SX_ACL_L3_TYPE_OTHER = 3,
    SX_ACL_L3_TYPE_MIN = SX_ACL_L3_TYPE_IPV4,
    SX_ACL_L3_TYPE_MAX = SX_ACL_L3_TYPE_OTHER,
    SX_ACL_L3_TYPE_LAST,
} sx_flex_acl_l3_type_t;

typedef enum {
    SX_ACL_L4_TYPE_INVALID = 0,
    SX_ACL_L4_TYPE_TCP = 0x1 << 0,
        SX_ACL_L4_TYPE_UDP = 0x1 << 1,
        SX_ACL_L4_TYPE_OTHER = 0x1 << 2,
        SX_ACL_L4_TYPE_MIN = SX_ACL_L4_TYPE_TCP,
        SX_ACL_L4_TYPE_MAX = SX_ACL_L4_TYPE_TCP | SX_ACL_L4_TYPE_UDP | SX_ACL_L4_TYPE_OTHER,
        SX_ACL_L4_TYPE_LAST,
} sx_flex_acl_l4_type_t;

typedef enum {
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH = 0,
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_POP,
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_LAST,
} sx_flex_acl_flex_action_set_vlan_type_t;

typedef enum {
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_UNIFORM = 0,
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_PIPE = 1,
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_LAST,
} sx_flex_acl_flex_action_qinq_tunnel_qos_t;

typedef enum {
    SX_ACL_FLEX_COLOR_GREEN = 0,
    SX_ACL_FLEX_COLOR_YELLOW = 1,
    SX_ACL_FLEX_COLOR_RED = 2,
    SX_ACL_FLEX_COLOR_LAST,
} sx_flex_acl_flex_action_color_type_t;

typedef struct sx_flex_acl_qinq_tunnel_qos_pipe {
    sx_cos_pcp_t pcp;
    sx_cos_dei_t dei;
} sx_flex_acl_qinq_tunnel_qos_pipe_t;

/**
 * sx_flex_acl_flex_action_set_vlan_t is used to set vlan;
 */
typedef struct sx_flex_acl_flex_action_set_vlan {
    sx_flex_acl_flex_action_set_vlan_type_t   cmd;
    sx_vlan_id_t                              vlan_id;
    sx_flex_acl_flex_action_qinq_tunnel_qos_t qinq_tunnel_qos;
    union {
        sx_flex_acl_qinq_tunnel_qos_pipe_t pipe;
    } qinq_tunnel_qos_fields;
} sx_flex_acl_flex_action_set_vlan_t;

/**
 * sx_flex_acl_flex_action_set_vlan_t is used to set inner vlan id;
 */
typedef struct sx_flex_acl_flex_action_set_vlan_id {
    sx_vlan_id_t vlan_id;
} sx_flex_acl_flex_action_set_vlan_id_t;

/**
 *  sx_flex_acl_flex_action_set_vlan_prio_t is used to set inner vlan priority;
 */
typedef struct sx_flex_acl_flex_action_set_vlan_prio {
    sx_cos_pcp_t pcp;
    sx_cos_dei_t dei;
} sx_flex_acl_flex_action_set_vlan_prio_t;

/**
 * sx_flex_acl_trap_action_t enum  type is used to note an trap ACL flexible action
 */
typedef enum {
    SX_ACL_TRAP_ACTION_TYPE_TRAP = 0,
    SX_ACL_TRAP_ACTION_TYPE_DISCARD,
    SX_ACL_TRAP_ACTION_TYPE_SOFT_DISCARD,
    SX_ACL_TRAP_ACTION_TYPE_LAST,
} sx_flex_acl_trap_action_t;

typedef enum {
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD = 0,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST,
} sx_flex_acl_forward_action_t;

typedef enum {
    SX_ACL_PORT_LIST_MATCH_NEGATIVE = 0,     /* Match if packet is not received from this port */
    SX_ACL_PORT_LIST_MATCH_POSITIVE = 1,     /* Match if packet is received from this port */
    SX_ACL_PORT_LIST_MATCH_LAST,
} sx_acl_port_list_match_t;

/**
 *
 */
typedef struct sx_acl_port_list_entry {
    sx_port_log_id_t         log_port;
    sx_acl_port_list_match_t port_match;
} sx_acl_port_list_entry_t;


/**
 * sx_flex_acl_action_trap_t use to Control the packet CPU  copy
 */
typedef struct sx_flex_acl_action_trap {
    sx_flex_acl_trap_action_t action;
    sx_trap_id_t              trap_id;
} sx_flex_acl_action_trap_t;


/**
 * sx_flex_acl_flex_action_forward_t enum  type is used to note an Forward ACL flexible action
 */
typedef struct sx_acl_flex_action_forward {
    sx_flex_acl_forward_action_t action;
} sx_flex_acl_flex_action_forward_t;

/**
 * sx_flex_acl_flex_action_policer_t is used to note an policing ACL flexible action;
 */
typedef struct sx_acl_flex_action_policing {
    sx_policer_id_t policer_id;
} sx_flex_acl_flex_action_policer_t;

/**
 * sx_flex_acl_flex_action_counter_t is used to note an counting ACL flexible action;
 */
typedef struct sx_acl_flex_action_counting {
    sx_flow_counter_id_t counter_id;
} sx_flex_acl_flex_action_counter_t;


/**
 * sx_flex_acl_flex_action_mirror_t is used to note an mirror ACL flexible action;
 */
typedef struct sx_acl_flex_action_mirror {
    sx_span_session_id_t session_id;
} sx_flex_acl_flex_action_mirror_t;

/**
 * sx_flex_acl_flex_action_set_mac_t is used to set source mac;
 */
typedef struct sx_flex_acl_flex_action_set_mac {
    sx_mac_addr_t mac;
} sx_flex_acl_flex_action_set_mac_t;

/**
 * sx_flex_acl_flex_action_set_dscp_t is used to set dscp;
 */
typedef struct sx_flex_acl_flex_action_set_dscp {
    sx_cos_dscp_t dscp_val;
} sx_flex_acl_flex_action_set_dscp_t;

/**
 * sx_flex_acl_flex_action_set_color_t is used to set color;
 */
typedef struct sx_flex_acl_flex_action_set_color {
    sx_flex_acl_flex_action_color_type_t color_val;
} sx_flex_acl_flex_action_set_color_t;

/**
 * sx_flex_acl_flex_action_set_ecn_t is used to set ecn;
 */
typedef struct sx_flex_acl_flex_action_set_ecn {
    uint8_t ecn_val;
} sx_flex_acl_flex_action_set_ecn_t;

/**
 * sx_flex_acl_flex_action_set_user_token_t is used to set user token;
 */
typedef struct sx_flex_acl_flex_action_set_user_token {
    uint16_t user_token;
    uint16_t mask;
} sx_flex_acl_flex_action_set_user_token_t;
/**
 * sx_flex_acl_flex_action_set_tc_t is used to set tc;
 */
typedef struct sx_flex_acl_flex_action_set_tc {
    uint8_t tc_val;
} sx_flex_acl_flex_action_set_tc_t;

/**
 * sx_flex_acl_flex_action_dec_ttl_t is used to decrement ttl;
 */
typedef struct sx_flex_acl_flex_action_dec_ttl {
    uint8_t ttl_val;
} sx_flex_acl_flex_action_dec_ttl_t;

/**
 * sx_flex_acl_flex_action_set_ttl_t is used to set ttl;
 */
typedef struct sx_flex_acl_flex_action_set_ttl {
    uint8_t ttl_val;
} sx_flex_acl_flex_action_set_ttl_t;

/**
 * sx_flex_acl_flex_action_set_prio_t is used to set prio;
 */
typedef struct sx_flex_acl_flex_action_set_prio {
    sx_cos_priority_t prio_val;
} sx_flex_acl_flex_action_set_prio_t;

/**
 * sx_flex_acl_flex_action_set_bridge_t is used to set bridge;
 */
typedef struct sx_flex_acl_flex_action_set_bridge {
    sx_bridge_id_t bridge_id;
} sx_flex_acl_flex_action_set_bridge_t;

/**
 * sx_flex_acl_flex_action_set_vrid_t is used to set virtual router;
 */
typedef struct sx_flex_acl_flex_action_set_vrid {
    sx_router_id_t virtual_router;
} sx_flex_acl_flex_action_set_vrid_t;

/**
 * sx_flex_acl_flex_action_set_pbs_t is used to set pbs;
 */
typedef struct sx_flex_acl_flex_action_set_pbs {
    sx_acl_pbs_id_t pbs_id;
} sx_flex_acl_flex_action_set_pbs_t;

typedef enum sx_flex_acl_rpf_action {
    SX_ACL_RPF_ACTION_TYPE_DISABLED = 0,  /**< No RPF check */
    SX_ACL_RPF_ACTION_TYPE_DROP, /**< Drop if RPF check fails*/
    SX_ACL_RPF_ACTION_TYPE_TRAP, /**< Trap with RPF trap ID if RPF check fails */
    SX_ACL_RPF_ACTION_TYPE_LAST,
} sx_flex_acl_rpf_action_t;

typedef enum sx_flex_acl_flex_rpf_param_type {
    SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF = 0,
    SX_ACL_FLEX_RPF_PARAM_TYPE_RPF_GROUP,
    SX_ACL_FLEX_RPF_PARAM_TYPE_LAST,
} sx_flex_acl_flex_rpf_param_type_t;

typedef struct sx_flex_acl_rpf_param {
    sx_flex_acl_flex_rpf_param_type_t rpf_param_type;
    union {
        sx_router_interface_t rpf_rif;
        sx_rpf_group_id_t     rpf_group;
    } rpf_param_value;
} sx_flex_acl_rpf_param_t;

/**
 * sx_flex_acl_flex_action_mc_route_t;
 */
typedef struct sx_flex_acl_flex_action_mc_route {
    sx_mc_container_id_t egress_mc_container;
} sx_flex_acl_flex_action_mc_route_t;

/**
 * sx_flex_acl_flex_action_rpf_t;
 */
typedef struct sx_flex_acl_flex_action_rpf {
    sx_flex_acl_rpf_action_t rpf_action;
    sx_flex_acl_rpf_param_t  rpf_param;  /**< Not applicable for SX_ACL_RPF_ACTION_TYPE_DISABLED */
} sx_flex_acl_flex_action_rpf_t;

/**
 * sx_flex_acl_flex_action_uc_route_ip_remote_t;
 */
typedef struct sx_flex_acl_flex_action_uc_route_ip_remote {
    sx_ecmp_id_t ecmp_id;
} sx_flex_acl_flex_action_uc_route_ip_remote_t;

/**
 * sx_flex_acl_flex_action_uc_route_ip_local_t;
 */
typedef struct sx_flex_acl_flex_action_uc_route_ip_local {
    sx_router_interface_t erif;
} sx_flex_acl_flex_action_uc_route_ip_local_t;

/**+
 * sx_flex_acl_flex_action_tunnel_decap_t;
 */
typedef struct sx_flex_acl_flex_action_uc_tunnel_decap {
    sx_tunnel_id_t tunnel_id;
} sx_flex_acl_flex_action_tunnel_decap_t;

/**
 * sx_flex_acl_flex_action_goto_cmd_t;
 */
typedef enum sx_flex_acl_flex_action_goto_cmd {
    SX_ACL_ACTION_GOTO_TERMINATE = 3,
    SX_ACL_ACTION_GOTO_LAST,
} sx_flex_acl_flex_action_goto_cmd_t;

/**
 * sx_flex_acl_flex_action_goto_t;
 */
typedef struct sx_flex_acl_flex_action_goto {
    sx_flex_acl_flex_action_goto_cmd_t goto_action_cmd;
    sx_acl_id_t                        acl_group_id;
} sx_flex_acl_flex_action_goto_t;

/**
 * sx_flex_acl_flex_action_fields_t struct type is used to note an ACL flexible action fields
 */
typedef union sx_flex_acl_flex_action_fields {
    sx_flex_acl_flex_action_forward_t        action_forward;
    sx_flex_acl_action_trap_t                action_trap;
    sx_flex_acl_flex_action_counter_t        action_counter;
    sx_flex_acl_flex_action_policer_t        action_policer;
    sx_flex_acl_flex_action_mirror_t         action_mirror;
    sx_flex_acl_flex_action_set_vlan_t       action_set_vlan;
    sx_flex_acl_flex_action_set_vlan_prio_t  action_set_inner_vlan_prio;
    sx_flex_acl_flex_action_set_vlan_prio_t  action_set_outer_vlan_prio;
    sx_flex_acl_flex_action_set_vlan_id_t    action_set_inner_vlan_id;
    sx_flex_acl_flex_action_set_vlan_id_t    action_set_outer_vlan_id;
    sx_flex_acl_flex_action_set_mac_t        action_set_src_mac;
    sx_flex_acl_flex_action_set_mac_t        action_set_dst_mac;
    sx_flex_acl_flex_action_set_dscp_t       action_set_dscp;
    sx_flex_acl_flex_action_set_prio_t       action_set_prio;
    sx_flex_acl_flex_action_set_bridge_t     action_set_bridge;
    sx_flex_acl_flex_action_set_pbs_t        action_pbs;
    sx_flex_acl_flex_action_set_tc_t         action_set_tc;
    sx_flex_acl_flex_action_set_ttl_t        action_set_ttl;
    sx_flex_acl_flex_action_dec_ttl_t        action_dec_ttl;
    sx_flex_acl_flex_action_set_color_t      action_set_color;
    sx_flex_acl_flex_action_set_ecn_t        action_set_ecn;
    sx_flex_acl_flex_action_set_user_token_t action_set_user_token;
    sx_flex_acl_flex_action_rpf_t            action_rpf;
    sx_flex_acl_flex_action_mc_route_t       action_mc_route;
    sx_flex_acl_flex_action_tunnel_decap_t   action_tunnel_decap;
    sx_flex_acl_flex_action_goto_t           action_goto;
} sx_flex_acl_flex_action_fields_t;

typedef enum {
    SX_FLEX_ACL_ACTION_FORWARD,
    SX_FLEX_ACL_ACTION_TRAP,
    SX_FLEX_ACL_ACTION_COUNTER,
    SX_FLEX_ACL_ACTION_MIRROR,
    SX_FLEX_ACL_ACTION_POLICER,
    SX_FLEX_ACL_ACTION_SET_PRIO,
    SX_FLEX_ACL_ACTION_SET_VLAN,
    SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI,
    SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI,
    SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID,
    SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID,
    SX_FLEX_ACL_ACTION_SET_SRC_MAC,
    SX_FLEX_ACL_ACTION_SET_DST_MAC,
    SX_FLEX_ACL_ACTION_SET_DSCP,
    SX_FLEX_ACL_ACTION_SET_BRIDGE,
    SX_FLEX_ACL_ACTION_PBS,
    SX_FLEX_ACL_ACTION_SET_TC,
    SX_FLEX_ACL_ACTION_SET_TTL,
    SX_FLEX_ACL_ACTION_DEC_TTL,
    SX_FLEX_ACL_ACTION_SET_COLOR,
    SX_FLEX_ACL_ACTION_SET_ECN,
    SX_FLEX_ACL_ACTION_SET_USER_TOKEN,
    SX_FLEX_ACL_ACTION_DONT_LEARN,
    SX_FLEX_ACL_ACTION_RPF,
    SX_FLEX_ACL_ACTION_MC_ROUTE,
    SX_FLEX_ACL_ACTION_TUNNEL_DECAP,
    SX_FLEX_ACL_ACTION_GOTO,
    SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST,
    SX_FLEX_ACL_FLEX_ACTION_TYPE_MIN = SX_FLEX_ACL_ACTION_FORWARD,
    SX_FLEX_ACL_FLEX_ACTION_TYPE_MAX = SX_FLEX_ACL_ACTION_GOTO,
} sx_flex_acl_flex_action_type_t;

/**
 * sx_flex_acl_flex_action_t struct type is used to note an ACL flexible action
 */
typedef struct sx_flex_acl_flex_action {
    sx_flex_acl_flex_action_type_t   type;
    sx_flex_acl_flex_action_fields_t fields;
} sx_flex_acl_flex_action_t;

typedef enum sx_flex_acl_ipv6_extension_header {
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_NONE = 0,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MIN = SX_FLEX_ACL_IPV6_EXTENSION_HEADER_NONE,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MAX = SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH,
} sx_flex_acl_ipv6_extension_header_t;

typedef struct sx_flex_acl_extension_headrs_list {
    sx_flex_acl_ipv6_extension_header_t extension_headers_list[SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST];
    uint32_t                            extension_headers_cnt;
} sx_flex_acl_extension_headrs_list_t;

typedef struct sx_flex_acl_port_range {
    sx_acl_port_range_id_t port_range_list[RM_API_ACL_PORT_RANGES_MAX];
    uint32_t               port_range_cnt;
} sx_flex_acl_port_range_t;


/* sx_flex_acl_l4_type_extended_t
 * */
typedef enum {
    SX_ACL_L4_TYPE_EXTENDED_TCP = 0,
    SX_ACL_L4_TYPE_EXTENDED_UDP = 1,
    SX_ACL_L4_TYPE_EXTENDED_BTH = 2,
    SX_ACL_L4_TYPE_EXTENDED_BTHOUDP = 3,
    SX_ACL_L4_TYPE_EXTENDED_ICMP = 4, /* Both V4 and V6 */
    SX_ACL_L4_TYPE_EXTENDED_IGMP = 5,
    SX_ACL_L4_TYPE_EXTENDED_AH = 6,
    SX_ACL_L4_TYPE_EXTENDED_ESP = 7,
    SX_ACL_L4_TYPE_EXTENDED_OTHERS = 8, /* None of the above */
    SX_ACL_L4_TYPE_EXTENDED_LAST,
} sx_flex_acl_l4_type_extended_t;

typedef union {
    sx_mac_addr_t                       dmac;
    sx_mac_addr_t                       smac;
    uint16_t                            ethertype;
    sx_cos_dei_t                        dei;
    sx_cos_pcp_t                        pcp;
    sx_vlan_id_t                        vlan_id;
    sx_cos_dei_t                        inner_dei;
    sx_cos_pcp_t                        inner_pcp;
    sx_mac_addr_t                       inner_dmac;
    sx_mac_addr_t                       inner_smac;
    uint16_t                            inner_ethertype;
    sx_ip_addr_t                        dip;
    sx_ip_addr_t                        sip;
    sx_ip_addr_t                        dipv6;
    sx_ip_addr_t                        sipv6;
    sx_cos_dscp_t                       dscp;
    uint8_t                             ecn;
    uint16_t                            ip_packet_length;
    uint8_t                             ip_proto;
    uint8_t                             ttl;
    sx_ip_addr_t                        inner_dip;
    sx_ip_addr_t                        inner_sip;
    sx_cos_dscp_t                       inner_dscp;
    uint8_t                             inner_ecn;
    uint16_t                            l4_destination_port;
    uint16_t                            l4_source_port;
    uint8_t                             tcp_control;
    uint8_t                             tcp_ecn;
    uint16_t                            inner_l4_destination_port;
    uint16_t                            inner_l4_source_port;
    sx_tunnel_type_e                    tunnel_type;
    sx_tunnel_gre_key_t                 gre_key;
    sx_tunnel_vni_t                     vni_key;
    uint16_t                            gre_protocol;
    boolean_t                           gre_key_exists;
    sx_tunnel_type_e                    tunnel_nve_type;
    boolean_t                           rw_pcp;
    sx_flex_acl_l2_dmac_type_t          l2_dmac_type;
    boolean_t                           dmac_is_uc;
    boolean_t                           vlan_tagged;
    boolean_t                           vlan_valid;
    sx_port_log_id_t                    dst_port;
    sx_port_log_id_t                    src_port;
    boolean_t                           rw_dscp;
    boolean_t                           ip_fragmented;
    boolean_t                           ip_dont_fragment;
    boolean_t                           ip_fragment_not_first;
    boolean_t                           ip_ok;
    boolean_t                           is_arp;
    boolean_t                           ip_opt;
    boolean_t                           is_ip_v4;
    sx_flex_acl_l3_type_t               l3_type;
    boolean_t                           ttl_ok;
    boolean_t                           l4_ok;
    sx_flex_acl_l4_type_t               l4_type;
    sx_flex_acl_l4_type_extended_t      l4_type_extended;
    sx_cos_color_t                      color;
    sx_cos_priority_t                   switch_prio;
    uint8_t                             buff;
    sx_flex_acl_port_range_t            l4_port_range;
    sx_flex_acl_forward_action_t        discard_state;
    boolean_t                           is_trapped;
    sx_acl_port_list_id_t               rx_list;
    sx_router_interface_t               irif;
    sx_router_interface_t               erif;
    sx_router_id_t                      virtual_router;
    sx_flex_acl_extension_headrs_list_t ipv6_extension_headers;
    boolean_t                           ipv6_extension_header_exists;
    sx_user_token_t                     user_token;
    boolean_t                           inner_vlan_valid;
    boolean_t                           inner_ip_ok;
    sx_flex_acl_l3_type_t               inner_l3_type;
    boolean_t                           inner_l4_ok;
    boolean_t                           inner_ttl_ok;
    uint8_t                             inner_ip_proto;
} sx_acl_key_fields_t;

typedef union {
    sx_mac_addr_t       dmac;
    sx_mac_addr_t       smac;
    uint16_t            ethertype;
    sx_cos_dei_t        dei;
    sx_cos_pcp_t        pcp;
    sx_vlan_id_t        vlan_id;
    sx_cos_dei_t        inner_dei;
    sx_cos_pcp_t        inner_pcp;
    sx_mac_addr_t       inner_dmac;
    sx_mac_addr_t       inner_smac;
    uint16_t            inner_ethertype;
    sx_ip_addr_t        dip;
    sx_ip_addr_t        sip;
    sx_ip_addr_t        dipv6;
    sx_ip_addr_t        sipv6;
    sx_cos_dscp_t       dscp;
    uint8_t             ecn;
    uint16_t            ip_packet_length;
    uint8_t             ip_proto;
    uint8_t             ttl;
    sx_ip_addr_t        inner_dip;
    sx_ip_addr_t        inner_sip;
    sx_cos_dscp_t       inner_dscp;
    uint8_t             inner_ecn;
    uint16_t            l4_destination_port;
    uint16_t            l4_source_port;
    uint8_t             tcp_control;
    uint8_t             tcp_ecn;
    uint16_t            inner_l4_destination_port;
    uint16_t            inner_l4_source_port;
    boolean_t           tunnel_type;
    sx_tunnel_gre_key_t gre_key;
    sx_tunnel_vni_t     vni_key;
    uint16_t            gre_protocol;
    boolean_t           gre_key_exists;
    boolean_t           tunnel_nve_type;
    boolean_t           rw_pcp;
    boolean_t           l2_dmac_type;
    boolean_t           dmac_is_uc;
    boolean_t           vlan_tagged;
    boolean_t           vlan_valid;
    boolean_t           dst_port;
    boolean_t           src_port;
    boolean_t           rw_dscp;
    boolean_t           ip_fragmented;
    boolean_t           ip_dont_fragment;
    boolean_t           ip_fragment_not_first;
    boolean_t           ip_ok;
    boolean_t           is_arp;
    boolean_t           ip_opt;
    boolean_t           is_ip_v4;
    boolean_t           l3_type;
    boolean_t           ttl_ok;
    boolean_t           l4_ok;
    boolean_t           l4_type;
    boolean_t           l4_type_extended;
    boolean_t           color;
    boolean_t           switch_prio;
    boolean_t           buff;
    boolean_t           l4_port_range;
    boolean_t           discard_state;
    boolean_t           is_trapped;
    boolean_t           rx_list;
    boolean_t           irif;
    boolean_t           erif;
    boolean_t           virtual_router;
    boolean_t           ipv6_extension_headers;
    boolean_t           ipv6_extension_header_exists;
    sx_user_token_t     user_token;
    boolean_t           inner_vlan_valid;
    boolean_t           inner_ip_ok;
    boolean_t           inner_l3_type;
    boolean_t           inner_l4_ok;
    boolean_t           inner_ttl_ok;
    uint8_t             inner_ip_proto;
} sx_acl_mask_fields_t;

typedef enum {
    FLEX_ACL_KEY_INVALID = 0,

    /* L2 keys */
    FLEX_ACL_KEY_DMAC = 1, /**< size:48, Destination MAC address */
    FLEX_ACL_KEY_SMAC = 2, /**< size:48, Source MAC address. Not relevant for egress RIF.  */
    FLEX_ACL_KEY_ETHERTYPE = 3, /**< size:16  */
    FLEX_ACL_KEY_DEI = 4, /**< size:1  */
    FLEX_ACL_KEY_PCP = 5, /**< size:3,  */
    FLEX_ACL_KEY_VLAN_ID = 6, /**< size:12. Relevant only for ingress binding. */
    FLEX_ACL_KEY_INNER_DMAC = 7, /**< size:48, Destination MAC address */
    FLEX_ACL_KEY_INNER_SMAC = 9, /**< size:48, Destination MAC address */
    FLEX_ACL_KEY_INNER_DEI = 10, /**< size:1  */
    FLEX_ACL_KEY_INNER_PCP = 11, /**< size:3,  */
    FLEX_ACL_KEY_INNER_ETHERTYPE = 12, /**< size:16  */

    /* L3 Keys */
    FLEX_ACL_KEY_DIP = 500, /**< size:32, IPV4 destination IP address*/
    FLEX_ACL_KEY_SIP = 501, /**< size:32, IPV4 source IP address*/
    FLEX_ACL_KEY_DSCP = 502, /**< size:6, DSCP */
    FLEX_ACL_KEY_ECN = 503, /**< size:2, ECN bits from IP header */
    FLEX_ACL_KEY_IP_PACKET_LENGTH = 504, /**< size:16, IPV4/6 packet length field. */
    FLEX_ACL_KEY_IP_PROTO = 505, /**< size:8, IPV4 - Next protocol, IPV6 - Next header */
    FLEX_ACL_KEY_TTL = 506, /**< size:8,  */
    FLEX_ACL_KEY_DIPV6 = 507, /**< size:128, IPV6 destination IP address */
    FLEX_ACL_KEY_SIPV6 = 508, /**< size:128, IPV6 source IP address */
    FLEX_ACL_KEY_INNER_SIP = 509, /**< size:32, IPV4 source IP address*/
    FLEX_ACL_KEY_INNER_DIP = 510, /**< size:32, IPV4 source IP address*/
    FLEX_ACL_KEY_INNER_DSCP = 511, /**< size:6, DSCP */
    FLEX_ACL_KEY_INNER_ECN = 512, /**< size:2, ECN bits from IP header */
    FLEX_ACL_KEY_INNER_IP_PROTO = 513, /**< size:8, IPV4 - Next protocol, IPV6 - Next header */

    /* L4 keys */
    FLEX_ACL_KEY_L4_DESTINATION_PORT = 1000, /**< size:16  */
    FLEX_ACL_KEY_L4_SOURCE_PORT = 1001, /**< size:16 */
    FLEX_ACL_KEY_TCP_CONTROL = 1002, /**< size:6 TCP control bits from header without the ECN bits */
    FLEX_ACL_KEY_TCP_ECN = 1003, /**< size:3 TCP ECN bits from TCP header */
    FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT = 1004, /**< size:16  */
    FLEX_ACL_KEY_INNER_L4_SOURCE_PORT = 1005, /**< size:16  */

    /* Tunnel keys */
    FLEX_ACL_KEY_GRE_KEY = 1301,
    FLEX_ACL_KEY_VNI_KEY = 1302,
    FLEX_ACL_KEY_GRE_PROTOCOL = 1303,

    /* Control keys */
    FLEX_ACL_KEY_RW_PCP = 1500, /**<  0 - The packet gets transmitted with VLAN.PCP and VALN.DEI, 1 - Rewrite PCP and DEI based on switch prio and color. */
    FLEX_ACL_KEY_L2_DMAC_TYPE = 1501, /**< 0 - Multicast, 1 - Broadcast, 2 - Unicast. Relevant only for Ingress.*/
    FLEX_ACL_KEY_DMAC_IS_UC = 1502, /**<  0 - Non unicast ,  1 - Unicast */
    FLEX_ACL_KEY_VLAN_TAGGED = 1503, /**< Indicates whether the packet enter the chip with or without VLAN tag */
    FLEX_ACL_KEY_VLAN_VALID = 1504, /**<  Packet has valid VLAN at this point (assigned or come with a vlan and the vlan was not popped) */
    FLEX_ACL_KEY_DST_PORT = 1505, /**< Destination logical port. Relevant only for egress. */
    FLEX_ACL_KEY_SRC_PORT = 1506, /**< Source logical port or LAG. */
    FLEX_ACL_KEY_RW_DSCP = 1507, /**< 0 packet is transmitted with the original DSCP, 1 - Rewrite DSCP based on switch prio and color. */
    FLEX_ACL_KEY_IP_FRAGMENTED = 1508, /**< When set means that the packet is segment of a fragmented packets. */
    FLEX_ACL_KEY_IP_DONT_FRAGMENT = 1509, /**< Dont fragment flag of IP packet. */
    FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST = 1510, /**< When set means that the segment is not first segment of fragmented packets.    */
    FLEX_ACL_KEY_IP_OK = 1511, /**< IP checksum id OK. */
    FLEX_ACL_KEY_IS_ARP = 1512, /**< According to Ether type - does not include RARP.    */
    FLEX_ACL_KEY_IP_OPT = 1513, /**< Indicates for IPV4 if the header contains options.*/
    FLEX_ACL_KEY_IS_IP_V4 = 1514, /**<  Packet is IPV4 */
    FLEX_ACL_KEY_L3_TYPE = 1515, /**< 0 - IPV4, 1 - IPV6, 2 - ARP, 3 - OTHER */
    FLEX_ACL_KEY_TTL_OK = 1516, /**<  TTL != 0 && TTL != 1  */
    FLEX_ACL_KEY_L4_OK = 1517, /**< TCP/UDP entire header is present, checksum is not verified.*/
    FLEX_ACL_KEY_L4_TYPE = 1518, /**< Bit 0 - TCP, Bit 1 - UDP, Bit3 - reserved. */
    FLEX_ACL_KEY_SWITCH_PRIO = 1519, /**< Key of QOS indicator */
    FLEX_ACL_KEY_COLOR = 1520, /**< 0 - Green, 1 - Yellow, 2 - Red. */
    FLEX_ACL_KEY_BUFF = 1521, /**< The priority group of the packet as classified when entered/enqueued the chip */
    FLEX_ACL_KEY_L4_PORT_RANGE = 1522, /**< array of sx_acl_port_range_id_t, see sx_api_acl_l4_port_range_set */
    FLEX_ACL_KEY_DISCARD_STATE = 1523, /**< Soft discard/hard discard */
    FLEX_ACL_KEY_IS_TRAPPED = 1524, /**< */
    FLEX_ACL_KEY_RX_LIST = 1525, /**< List of logical ports/LAGs */
    FLEX_ACL_KEY_IRIF = 1526, /**< Ingress RIF*/
    FLEX_ACL_KEY_ERIF = 1527, /**< Egress RIF */
    FLEX_ACL_KEY_VIRTUAL_ROUTER = 1528, /**< virtual router */
    FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS = 1529, /**< IPV6 extension headers.*/
    FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS = 1530, /**< IPV6 extension header exists.*/
    FLEX_ACL_KEY_USER_TOKEN = 1531, /**< */
    FLEX_ACL_KEY_INNER_VLAN_VALID = 1532, /**< Packet has valid VLAN at this point (assigned or come with a vlan and the vlan was not popped) */
    FLEX_ACL_KEY_INNER_IP_OK = 1533, /**< IP checksum id OK. */
    FLEX_ACL_KEY_INNER_L3_TYPE = 1534, /**< 0 - IPV4, 1 - IPV6, 2 - ARP, 3 - OTHER */
    FLEX_ACL_KEY_INNER_L4_OK = 1535, /**< TCP/UDP entire header is present, checksum is not verified.*/
    FLEX_ACL_KEY_INNER_TTL_OK = 1536, /**<  TTL != 0 && TTL != 1  */
    FLEX_ACL_KEY_TUNNEL_TYPE = 1537,
    FLEX_ACL_KEY_GRE_KEY_EXISTS = 1538,
    FLEX_ACL_KEY_TUNNEL_NVE_TYPE = 1539, /* VXLAN, GENEVE, GRE or NVGRE */
    FLEX_ACL_KEY_L4_TYPE_EXTENDED = 1540,
    FLEX_ACL_KEY_LAST = 2000,
} sx_acl_key_t;

/**
 * sx_flex_acl_key_desc_t struct type is used to note an ACL flexible key
 */
typedef struct sx_flex_acl_key_desc {
    sx_acl_key_t         key_id;
    sx_acl_key_fields_t  key;
    sx_acl_mask_fields_t mask;
} sx_flex_acl_key_desc_t;

/**
 * sx_flex_acl_flex_rule_t struct type is used to note an ACL rule
 * combined of the triplet {key_desc(key value and mask value),action }
 */
typedef struct sx_flex_acl_flexible_rule {
    uint8_t                    valid;                  /**<Rules validity flag*/
    sx_flex_acl_key_desc_t    *key_desc_list_p;        /**<Array of structures describing a set of basic keys in the rule*/
    uint32_t                   key_desc_count;         /**<Number of elements in array of basic keys descriptors*/
    sx_flex_acl_flex_action_t *action_list_p;          /**<Array of rule actions*/
    uint32_t                   action_count;           /**<Number of elements in array of actions*/
} sx_flex_acl_flex_rule_t;

#endif /* SX_FLEX_ACL_H_ */
