/*
 *  Copyright (C) 2014-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_TUNNEL_H__
#define __SX_TUNNEL_H__

/************************************************
 *  Type definitions
 ***********************************************/

#include <sx/sdk/sx_tunnel_id.h>
#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_span.h>

static __attribute__((__used__)) const char* sx_tunnel_type_str[] = {
    "SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4",
    "SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE",
    "SX_TUNNEL_TYPE_NVE_VXLAN",
    "SX_TUNNEL_TYPE_NVE_VXLAN_GPE",
    "SX_TUNNEL_TYPE_NVE_GENEVE",
    "SX_TUNNEL_TYPE_NVE_NVGRE",
};

#define SX_TUNNEL_TYPE_STR_LEN (sizeof(sx_tunnel_type_str) / sizeof(char*))

#define SX_TUNNEL_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_TUNNEL_TYPE_STR_LEN - 1) ? \
     sx_tunnel_type_str[index] : "UNKNOWN")


static __attribute__((__used__)) const char* sx_tunnel_direction_str[] = {
    "SX_TUNNEL_DIRECTION_NONE",
    "SX_TUNNEL_DIRECTION_ENCAP",
    "SX_TUNNEL_DIRECTION_DECAP",
    "SX_TUNNEL_DIRECTION_SYMMETRIC"
};

#define SX_TUNNEL_DIRECTION_STR_LEN (sizeof(sx_tunnel_direction_str) / sizeof(char*))

#define SX_TUNNEL_DIRECTION_STR(index)                      \
    (SX_CHECK_MAX(index, SX_TUNNEL_DIRECTION_STR_LEN - 1) ? \
     sx_tunnel_direction_str[index] : "UNKNOWN")

/**
 * Decap table fields types
 */
typedef enum sx_tunnel_decap_key_fields_type {
    SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP = 0, /**< Key contains packet destination ip */
    SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP, /**< Key contains packet destination ip and source ip */
    SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MIN = SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP,
    SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MAX = SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP,
} sx_tunnel_decap_key_fields_type_e;

static __attribute__((__used__)) const char* sx_tunnel_decap_key_fields_type_str[] = {
    "DIP",
    "DIP_SIP",
};

#define SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_STR_LEN (sizeof(sx_tunnel_decap_key_fields_type_str) / sizeof(char*))

#define SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_STR(index)     \
    (SX_CHECK_MAX(index, BSORT_PRIORITY_STR_LEN - 1) ? \
     sx_tunnel_decap_key_fields_type_str[index] : "UNKNOWN")

#define SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MAX)

/**
 * Decap table entry key
 */
typedef struct sx_tunnel_decap_entry_key {
    sx_tunnel_type_e                  tunnel_type; /**< Tunnel Type */
    sx_tunnel_decap_key_fields_type_e type; /**< Key fields */
    sx_router_id_t                    underlay_vrid;  /**< Router ID the key associated with */
    sx_ip_addr_t                      underlay_dip;   /**< Destination ip in underlay packet */
    sx_ip_addr_t                      underlay_sip;   /**< Source ip in underlay packet */
} sx_tunnel_decap_entry_key_t;

/**
 * Decap table entry data
 */
typedef struct sx_tunnel_decap_entry_data {
    sx_tunnel_id_t       tunnel_id;     /**< Tunnel ID */
    sx_router_action_t   action;        /**< Which action when decap */
    sx_flow_counter_id_t counter_id;    /**< Flow counter to attach */
    sx_trap_attributes_t trap_attr;     /**< Trap attributes */
    sx_span_session_id_t span_session_id; /**< Span session ID */
} sx_tunnel_decap_entry_data_t;

/**
 * IPinIP General paramaters
 */
typedef struct sx_tunnel_ipinip_general_params {
    uint16_t encap_flowlabel; /**< 12msb of Flow Label value for underlay packet in encap operation, if set, the 8 lsb will be calculated from ecmp hash, set to 0 to disable */
    uint32_t encap_gre_hash; /**< 24msb of GRE hash value for underlay packet in encap operation */
} sx_tunnel_ipinip_general_params_t;

/**
 * IPinIP Tunnel GRE Mode
 */
typedef enum sx_tunnel_ipinip_gre_mode {
    SX_TUNNEL_IPINIP_GRE_MODE_ENABLED = 0, /**< GRE Enabled */
    SX_TUNNEL_IPINIP_GRE_MODE_ENABLED_WITH_KEY, /**< GRE Enabled with key support */
    SX_TUNNEL_IPINIP_GRE_MODE_ENABLED_WITH_KEY_HASH, /**< GRE Enabled with both key and hash support */
    SX_TUNNEL_IPINIP_GRE_MODE_MIN = SX_TUNNEL_IPINIP_GRE_MODE_ENABLED,
    SX_TUNNEL_IPINIP_GRE_MODE_MAX = SX_TUNNEL_IPINIP_GRE_MODE_ENABLED_WITH_KEY_HASH,
} sx_tunnel_ipinip_gre_mode_e;

/**
 * IPinIP encap attributes
 */
typedef struct sx_tunnel_ipinip_p2p_encap_attributes {
    sx_router_id_t              underlay_vrid;    /**< Router ID which the encapsulated packets will be sent from. */
    sx_ip_addr_t                underlay_sip;    /**< Source IP on encapsulated packets */
    sx_tunnel_ipinip_gre_mode_e gre_mode; /**< GRE Mode (Enabled or Enabled with options) */
    sx_tunnel_gre_key_t         gre_key;  /**< GRE Key used incase tunnel enabled GRE Key */
} sx_tunnel_ipinip_p2p_encap_attributes_t;

/**
 * IPinIP decap attributes
 */
typedef struct sx_tunnel_ipinip_p2p_decap_attributes {
    boolean_t           gre_check_key;     /**< Check GRE Key with expected_gre_key when doing decapsulation operation */
    sx_tunnel_gre_key_t gre_expected_key;  /**< Expected GRE Key */
} sx_tunnel_ipinip_p2p_decap_attributes_t;

/**
 * IPinIP Peer 2 Peer Tunnel attributes
 */
typedef struct sx_tunnel_ipinip_p2p_attribute {
    sx_router_interface_t                   overlay_rif;  /**< Tunnel interface to connect the tunnel to overlay router */
    sx_router_interface_t                   underlay_rif; /**< Tunnel interface to connect the tunnel to underlay router - Not supported */
    sx_tunnel_ipinip_p2p_encap_attributes_t encap;        /**< IPinIP Encap attributes */
    sx_tunnel_ipinip_p2p_decap_attributes_t decap;        /**< IPinIP Decap attributes */
} sx_tunnel_ipinip_p2p_attribute_t;

/**
 * NVE General parameters
 */
typedef struct sx_tunnel_nve_general_params {
    uint8_t  encap_sport;  /**< Source UDP port on the packet, 8 bits filled by LAG hash. won't be used for NVGRE packets */
    uint16_t encap_flowlabel; /**< 12msb of Flow Label value for underlay packet in encap operation, if set, the 8 lsb will be calculated from ecmp hash, set to 0 to disable */
} sx_tunnel_nve_general_params_t;

/**
 * NVE tunnel counter
 */
typedef struct sx_tunnel_nve_counter {
    uint64_t encapsulated_pkts;
    uint64_t decapsulated_pkts;
    uint64_t decapsulated_errors;
    uint64_t decapsulated_discards;
} sx_tunnel_nve_counter_t;

/**
 * Tunnel counters
 */
typedef struct sx_tunnel_counter {
    sx_tunnel_type_e type;
    union {
        sx_tunnel_nve_counter_t nve;
    } counter;
} sx_tunnel_counter_t;

/**
 * NVE encap attributes
 */
typedef struct sx_tunnel_nve_encap_attributes {
    sx_router_id_t underlay_vrid;   /**< Router ID which the encapsulated packets will be sent from */
    uint8_t        underlay_ttl;    /**< TTL Value for Underlay packet in encap operation, set to 0 to copy from Overlay packet */
    sx_ip_addr_t   underlay_sip;    /**< Source IP on encapsulated packets */
} sx_tunnel_nve_encap_attributes_t;

/**
 * NVE decap attributes
 */
typedef struct sx_tunnel_nve_decap_attributes {
    uint8_t reserved;
} sx_tunnel_nve_decap_attributes_t;

/**
 * NVE tunnel specific attributes
 */
typedef struct sx_tunnel_nve_attribute {
    sx_tunnel_nve_encap_attributes_t encap; /**< NVE Encap Attributes */
    sx_tunnel_nve_decap_attributes_t decap; /**< NVE Decap Attributes */
} sx_tunnel_nve_attribute_t;

typedef struct sx_tunnel_nve_map_entry {
    sx_bridge_id_t  bridge_id;             /* Bridge ID */
    sx_tunnel_vni_t vni;                   /* VNI - VxLan/Genve, VSID - NVGRE */
} sx_tunnel_nve_map_entry_t;

/**
 * Tunnel mapping entry
 */
typedef struct sx_tunnel_map_entry {
    sx_tunnel_type_e type;
    union {
        sx_tunnel_nve_map_entry_t nve; /* NVE Params */
    } params;
} sx_tunnel_map_entry_t;

/**
 * Tunneling general paramaters
 */
typedef struct sx_tunnel_general_params {
    sx_tunnel_nve_general_params_t    nve;    /* NVE General Params */
    sx_tunnel_ipinip_general_params_t ipinip; /* IPinIP General Params */
} sx_tunnel_general_params_t;

/**
 * Tunnel attributes
 */
typedef struct sx_tunnel_attribute {
    sx_tunnel_type_e      type;              /**< Tunnel Type */
    sx_tunnel_direction_e direction;         /**< Tunnel Direction */
    union {
        sx_tunnel_ipinip_p2p_attribute_t ipinip_p2p;     /* IPinIP P2P */
        sx_tunnel_ipinip_p2p_attribute_t ipinip_p2p_gre; /* IPinIP P2P GRE */
        sx_tunnel_nve_attribute_t        vxlan;          /* VxLan */
        sx_tunnel_nve_attribute_t        vxlan_gpe;      /* VxLan-GPE */
        sx_tunnel_nve_attribute_t        geneve;         /* Geneve */
        sx_tunnel_nve_attribute_t        nvgre;          /* nvgre */
    } attributes;
} sx_tunnel_attribute_t;

#endif /* __SX_TUNNEL_H__ */
