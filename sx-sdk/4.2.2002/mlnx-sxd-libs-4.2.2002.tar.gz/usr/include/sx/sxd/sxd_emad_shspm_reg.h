/*
 * Copyright (C) Mellanox Technologies, Ltd. 2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SHSPM_REG_H__
#define __SXD_EMAD_SHSPM_REG_H__

#include <sx/sxd/sxd_types.h>
#include <complib/cl_packon.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_ralta_reg_t structure is used to store RALTA register layout.
 */
typedef struct sxd_emad_ralta_reg {
    uint8_t operation_protocol;
    uint8_t reserved1[2];
    uint8_t tree_id;
} PACK_SUFFIX sxd_emad_ralta_reg_t;

/**
 * sxd_emad_ralst_children_t structure is used to store RALST children layout.
 */
typedef struct sxd_emad_ralst_children {
    uint8_t left_child;
    uint8_t right_child;
} PACK_SUFFIX sxd_emad_ralst_children_t;

/**
 * sxd_emad_ralst_reg_t structure is used to store RALST register layout.
 */
typedef struct sxd_emad_ralst_reg {
    uint8_t                   reserved1;
    uint8_t                   root_bin;
    uint8_t                   reserved2;
    uint8_t                   tree_id;
    sxd_emad_ralst_children_t structure[128];
} PACK_SUFFIX sxd_emad_ralst_reg_t;

/**
 * sxd_emad_raltb_reg_t structure is used to store RALTB register layout.
 */
typedef struct sxd_emad_raltb_reg {
    uint16_t virtual_router;
    uint8_t  protocol;
    uint8_t  tree_id;
} PACK_SUFFIX sxd_emad_raltb_reg_t;

/**
 * sxd_emad_ralue_action_remote_t structure is used to store RALUE action remote layout.
 */
typedef struct sxd_emad_ralue_action_remote {
    uint8_t  trap_action;
    uint8_t  reserved;
    uint16_t trap_id;
    uint32_t adjacency_index;
    uint8_t  reserved2[2];
    uint16_t ecmp_size;
    uint8_t  reserved3[8];
} PACK_SUFFIX sxd_emad_ralue_action_remote_t;

/**
 * sxd_emad_ralue_action_local_t structure is used to store RALUE action local layout.
 */
typedef struct sxd_emad_ralue_action_local {
    uint8_t  trap_action;
    uint8_t  reserved;
    uint16_t trap_id;
    uint8_t  reserved2[2];
    uint16_t local_egress_rif;
    uint8_t  reserved3[12];
} PACK_SUFFIX sxd_emad_ralue_action_local_t;

/**
 * sxd_emad_ralue_action_remote_t structure is used to store RALUE action ip2me layout.
 */
typedef struct sxd_emad_ralue_action_ip2me {
    uint8_t  reserved[4];
    uint32_t valid_tunnel_ptr;
    uint8_t  reserved3[12];
} PACK_SUFFIX sxd_emad_ralue_action_ip2me_t;

/**
 * sxd_emad_ralue_action_t structure is used to store RALUE action field layout.
 */
typedef union sxd_emad_ralue_action {
    sxd_emad_ralue_action_remote_t remote;
    sxd_emad_ralue_action_local_t  local;
    sxd_emad_ralue_action_ip2me_t  ip2me;
} PACK_SUFFIX sxd_emad_ralue_action_t;

/**
 * sxd_emad_ralue_reg_t structure is used to store RALUE register layout.
 */
typedef struct sxd_emad_ralue_reg {
    uint8_t                 protocol;
    uint8_t                 operation_activity;
    uint8_t                 reserved1[2];
    uint16_t                virtual_router;
    uint8_t                 update_mask;
    uint8_t                 reserved2[4];
    uint8_t                 prefix_length;
    net32_t                 destination_ip[4];
    uint8_t                 entry_type;
    uint8_t                 bmp_len;
    uint8_t                 reserved3;
    uint8_t                 action_type;
    sxd_emad_ralue_action_t action;
    uint32_t                counter_set;
} PACK_SUFFIX sxd_emad_ralue_reg_t;

/**
 * sxd_emad_raleu_reg_t structure is used to store RALEU register layout.
 */
typedef struct sxd_emad_raleu_reg {
    uint8_t  protocol;
    uint8_t  reserved1;
    uint16_t virtual_router;
    uint32_t reserved2[3];
    uint32_t old_adjacency_index;
    uint8_t  reserved3[2];
    uint16_t old_ecmp_size;
    uint32_t reserved4[2];
    uint32_t new_adjacency_index;
    uint8_t  reserved5[2];
    uint16_t new_ecmp_size;
    uint32_t reserved6;
} PACK_SUFFIX sxd_emad_raleu_reg_t;

/**
 * sxd_emad_ralbu_reg_t structure is used to store RALBU register layout.
 */
typedef struct sxd_emad_ralbu_reg {
    uint8_t  protocol;
    uint8_t  reserved1;
    uint16_t virtual_router;
    uint8_t  reserved2;
    uint8_t  old_bmp_len;
    uint8_t  reserved3;
    uint8_t  bin;
    uint8_t  reserved4;
    uint8_t  new_bmp_len;
    uint8_t  reserved5;
    uint8_t  prefix_len;
    uint8_t  reserved6[4];
    net32_t  destination_ip[4];
    uint32_t reserved7[4];
} PACK_SUFFIX sxd_emad_ralbu_reg_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_SHSPM_REG_H__ */
