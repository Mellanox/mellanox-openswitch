/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_DPT_H__
#define __SXD_DPT_H__

#include <complib/cl_passivelock.h>
#include <complib/cl_shared_memory.h>
#include <sx/sxd/sxd_dev.h>
#include <complib/sx_log.h>
#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_command_ifc.h>
#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#endif

/**
 * MAX_DR_PATHS_FOR_DEVICE defines the maximum
 * number of directed route paths for a single device.
 */
#define MAX_DR_PATHS_FOR_DEVICE 38

/**
 * MAX_DR_PATH_LEN defines the maximum length of a directed route path.
 */
#define MAX_DR_PATH_LEN 3

/**
 * sys_type_t enumerated type is used to note the possible
 * system types.
 */
typedef enum sys_type {
    SYS_TYPE_IB,
    SYS_TYPE_EN,
    SYS_TYPE_VPI,
    SYS_TYPE_MIN = SYS_TYPE_IB,
    SYS_TYPE_MAX = SYS_TYPE_VPI,
} sys_type_t;

/**
 * dpt_path_type_t enumerated type is used to note the possible
 * path types.
 */
typedef enum {
    DR_PATH,
    SYS_PORT_ROUTE_PATH
} dpt_path_type_t;

/**
 * dpt_encapsulation_t enumerated type is used to note the possible
 * encapsulation types.
 */
typedef enum {
    NO_ACCESS = 0,
    READ_ONLY,
    READ_WRITE
} dpt_access_control_t;

typedef enum {
    INVALID_PATH = -1,
    EMAD_PATH,
    MAD_PATH,
    CMD_IFC_PATH
} dpt_encapsulation_t;

/**
 * sxd_dpt_group_t enumerated type is used to note the different
 * register groups.
 */
typedef enum {
    FIRST_GROUP = 0, /* cmd + emad */
    SECOND_GROUP, /* cmd + mad */
    THIRD_GROUP, /* emad only */
    NUM_OF_GROUPS
} sxd_dpt_group_t;

/**
 * dr_path_t structure is used to store directed route data.
 */
typedef struct dr_path {
    uint16_t  path_len;
    uint16_t *path_ports;
    uint16_t *path_device_id;
} dr_path_t;

/**
 * dr_path_params_t structure is used to store directed route parameters data.
 */
typedef struct dr_path_params {
    uint16_t   num_of_paths;
    dr_path_t *dr_path;
} dr_path_params_t;

/**
 * ib_dr_path_params_t structure is used to store IB directed route parameters data.
 */
typedef struct ib_dr_path_params {
#ifdef IB_PRESENT_FLAG
    ib_dr_path_t drpath;
#endif
    dr_path_params_t local_ports_dr;
    int              is_valid;
} ib_dr_path_params_t;

/**
 * sys_port_path_params_t structure is used to store system port path parameters data.
 */
typedef struct sys_port_path_params {
    uint16_t sys_port;
    int      is_valid;
} sys_port_path_params_t;

/**
 * local_to_ib_map_t structure is used to store the mapping
 * betweeb local ports to IB ports data.
 */
typedef struct local_to_ib_map {
    uint8_t local_port;
    uint8_t ib_port;
    uint8_t port_module;
} local_to_ib_map_t;

/**
 * dpt_path_params_t structure is used to store the DPT paths parameters data.
 */
typedef union dpt_path_params {
    dr_path_params_t       dr_params;
    sys_port_path_params_t sys_port_params;
} dpt_path_params_t;

typedef enum ref_count_direction {
    REF_COUNT_INCREMENT,
    REF_COUNT_DECREMENT,
    REF_COUNT_MIN = REF_COUNT_INCREMENT,
    REF_COUNT_MAX = REF_COUNT_DECREMENT,
} ref_count_direction_t;


/**
 * This function sets the log verbosity level of the DPT MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *         SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_dpt_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                         IN sx_verbosity_level_t *verbosity_level_p);

/**
 * This function initializes the DPT memory
 * Please note that no other DPT API or access register call
 * can be performed before this function returns.
 * @param[in] sys_type   - system type
 * @param[in] logging_cb - callback function for the log
 * @param[in] verbosity_level - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *         SXD_STATUS_NO_MEMORY  error in allocating the needed memory
 */
sxd_status_t sxd_dpt_init(sys_type_t                 sys_type,
                          sx_log_cb_t                logging_cb,
                          const sx_verbosity_level_t verbosity_level);

/**
 *  This function frees the DPT shared memory. Further
 *  use of the reg_access library should not be performed after it is called.
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NO_RESOURCES - de-initialization failed
 */
sxd_status_t sxd_dpt_deinit(void);

/**
 *  This function sets the access control for dev_id.
 * @param[in] dev_id   - the device ID
 * @param[in] access_control - NO_ACCESS/READ/READ_WRITE
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - set access control had failed
 */
sxd_status_t sxd_dpt_set_access_control(sxd_dev_id_t         dev_id,
                                        dpt_access_control_t access_control);

/**
 *  This function adds a new device to the DPT. It is used for devices
 *  which are accessed through Infiniband.
 *  On Ethernet only system it shouldn't be called.
 * @param[in] dev_id   - the device ID
 * @param[in] ports_map - A mapping netween local ports to IB ports
 * @param[in] num_of_ports - Number of ports in the mapping
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - device add has failed
 */
sxd_status_t sxd_dpt_add_ports_map(sxd_dev_id_t       dev_id,
                                   local_to_ib_map_t *ports_map,
                                   uint8_t            num_of_ports);

/**
 *  This function adds a new path to a device to the DPT.
 * @param[in] dev_id   - the device ID
 * @param[in] swid   - the switch ID through which the path passes
 * @param[in] path - the path type
 * @param[in] path_params - the path parameters
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 * @return SXD_STATUS_ERROR - device add has failed
 */
sxd_status_t sxd_dpt_path_add(sxd_dev_id_t      dev_id,
                              sxd_swid_t        swid,
                              dpt_path_type_t   path,
                              dpt_path_params_t path_params);

/**
 *  This function removes an existing path to a device from the DPT.
 * @param[in] dev_id   - the device ID
 * @param[in] swid   - the switch ID through which the path passes
 * @param[in] path - the path type
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - device add has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_path_remove(sxd_dev_id_t    dev_id,
                                 sxd_swid_t      swid,
                                 dpt_path_type_t path);

/**
 *  This function set the system port (uc_route) to local port
 *  mapping.
 *
 * @param[in] system_port - system device ID
 * @param[in] dev_id      - the device ID
 * @param[in] local_port  - the physical port
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_set_uc_route(uint16_t     system_port,
                                  sxd_dev_id_t dev_id,
                                  uint8_t      local_port);

/**
 *  This function get the local port and device by
 *  system port (uc_route).
 *
 * @param[in] system_port  - system device ID
 * @param[OUT] dev_id      - the device ID
 * @param[OUT] local_port  - the physical port
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_get_local_port_by_uc_route(uint16_t      system_port,
                                                sxd_dev_id_t *dev_id,
                                                uint8_t      *local_port);

/**
 *  This function get the system port (uc_route) by
 *  local port and device.
 *
 * @param[IN]  dev_id      - the device ID
 * @param[IN]  local_port  - the physical port
 * @param[OUT] system_port - system device ID
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_get_uc_route_by_local_port(sxd_dev_id_t dev_id,
                                                uint8_t      local_port,
                                                uint16_t    *system_port);

/**
 *  This function set the port to module mapping.
 * @param[in] cmd       - ADD/REMOVE
 * @param[in] device_id    - the device ID
 * @param[in] module    - the module ID
 * @param[in] port      - the physical port
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_port_module_map_set(const sxd_access_cmd_t  cmd,
                                         const sxd_dev_id_t      device_id,
                                         const sxd_port_mod_id_t module_id,
                                         const sxd_port_phy_id_t port);

/**
 *  This function returns the ports that are mapped to the given module.
 * @param[in] device_id - the device ID
 * @param[in] module_id - the module ID
 * @param[out] list_size_p     - size of the returned port list
 * @param[out] port_list_p     - mapped ports list
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_port_module_map_port_get(const sxd_dev_id_t      device_id,
                                              const sxd_port_mod_id_t module_id,
                                              uint8_t                *list_size_p,
                                              sxd_port_phy_id_t      *port_list_p);

/**
 *  This function returns the module that the given port is mapped to.
 * @param[in] device_id - the device ID
 * @param[in] port      - the physical port
 * @param[out] module_id     - module ID
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_port_module_map_module_get(const sxd_dev_id_t      device_id,
                                                const sxd_port_phy_id_t port,
                                                sxd_port_mod_id_t      *module_id);

/**
 *  This function set virtual trap to trap mapping.
 *
 * @param[in] vtrap - virtual trap
 * @param[in] trap  - hw trap
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_vtrap_mapping_set(uint32_t vtrap, uint32_t trap);

/**
 *  This function get hw trap by virtual traps.
 *
 * @param[in] vtrap  - virtual trap
 * @param[OUT] trap  - hw trap
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_vtrap_virt_to_hw_mapping_get(uint32_t vtrap, uint32_t *trap);

/**
 *  This function get virt trap by hw trap.
 *
 * @param[in]  trap   - hw trap
 * @param[OUT] vtrap  - virtual trap
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - operation has failed
 * @return SXD_STATUS_PARAM_ERROR - received a bad parameter
 */
sxd_status_t sxd_dpt_vtrap_hw_to_virt_mapping_get(uint32_t trap, uint32_t *vtrap);

sxd_status_t sxd_dpt_get_ref_count(uint8_t* ref_count);

sxd_status_t sxd_dpt_set_ref_count(ref_count_direction_t direction);

#endif /* __SXD_DPT_H__ */
