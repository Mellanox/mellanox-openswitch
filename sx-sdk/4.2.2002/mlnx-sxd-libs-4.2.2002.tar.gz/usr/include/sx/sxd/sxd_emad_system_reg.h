/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SYSTEM_REG_H__
#define __SXD_EMAD_SYSTEM_REG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_system_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/**
 * MAX_TRANSACTIONS_NUM define the max number of mjtag register
 * stransactions.
 */
#define MAX_TRANSACTIONS_NUM 40

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_sgcr_reg_t structure is used to store SGCR register
 * layout.
 */
typedef struct sxd_emad_sgcr_reg {
    uint8_t  reserved1[7];
    uint8_t  llb;
    uint32_t reserved2[18];
} PACK_SUFFIX sxd_emad_sgcr_reg_t;


/**
 * sxd_emad_scar_reg_t structure is used to store SCAR register
 * layout.
 */
typedef struct sxd_emad_scar_reg {
    net32_t reserved1[12];
    uint8_t reserved[3];
    uint8_t cap_log2_fdb_sz;
    net32_t reserved3[7];
} PACK_SUFFIX sxd_emad_scar_reg_t;


/**
 * This function sets the log verbosity level of SYSTEM PARSER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t emad_parser_system_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p);


/**
 * sxd_emad_sspr_reg_t structure is used to store SSPR register
 * layout.
 */
typedef struct sxd_emad_sspr_reg {
    uint8_t           m;
    sxd_port_phy_id_t local_port;
    sxd_port_sub_id_t sub_port;
    uint8_t           reserved1;
    net16_t           reserved2;
    sxd_port_sys_id_t system_port;
} PACK_SUFFIX sxd_emad_sspr_reg_t;

/**
 * sxd_emad_spad_reg_t structure is used to store SPAD register
 * layout.
 */
typedef struct sxd_emad_spad_reg {
    net64_t base_mac;
    net32_t reserved1[2];
} PACK_SUFFIX sxd_emad_spad_reg_t;

/* sxd_emad_mfba_reg_t structure is used to store MFBA register
 * layout.
 */
typedef struct sxd_emad_mfba_reg {
    net16_t reserved1;
    uint8_t p;
    uint8_t fs;
    net16_t reserved2;
    net16_t size;
    net32_t address;
    uint8_t data[192];
} PACK_SUFFIX sxd_emad_mfba_reg_t;

/**
 * sxd_emad_msci_reg_t structure is used to store MSCI register
 * layout.
 */
typedef struct sxd_emad_msci_reg {
    uint8_t reserved[3];
    uint8_t index;
    net32_t version;
    net32_t reserved2;
    net32_t reserved3;
} PACK_SUFFIX sxd_emad_msci_reg_t;

/**
 * sxd_emad_mtmp_reg_t structure is used to store MTMP register
 * layout.
 */
typedef struct sxd_emad_mtmp_reg {
    uint8_t reserved[3];
    uint8_t sensor_index;
    net16_t reserved2;
    net16_t temperature;
    uint8_t mte_mtr;
    uint8_t reserved3;
    net16_t max_temperature;
    uint8_t tee;
    uint8_t reserved4;
    net16_t temperature_threshold;
    net32_t reserved5;
} PACK_SUFFIX sxd_emad_mtmp_reg_t;

/**
 * sxd_emad_mfbe_reg_t structure is used to store MFBE register
 * layout.
 */
typedef struct sxd_emad_mfbe_reg {
    net16_t reserved1;
    uint8_t p;
    uint8_t fs;
    net32_t reserved2;
    net32_t address;
} PACK_SUFFIX sxd_emad_mfbe_reg_t;

/**
 * sxd_emad_mfpa_reg_t structure is used to store MFPA register
 * layout.
 */
typedef struct sxd_emad_mfpa_reg {
    net16_t reserved1;
    uint8_t p;
    uint8_t fs;
    net32_t boot_address;
    net64_t reserved2;
    net16_t reserved3;
    uint8_t reserved4;
    uint8_t flash_num;
    net32_t jedec_id;
    uint8_t reserved5;
    uint8_t block_allignment;
    net16_t sector_size;
    uint8_t capability_mask;
    uint8_t reserved6[175];
} PACK_SUFFIX sxd_emad_mfpa_reg_t;

/**
 * sxd_emad_ppsc_reg_t structure is used to store PPSC register
 * layout.
 */
typedef struct sxd_emad_ppsc_reg {
    uint8_t  reserved0;
    uint8_t  local_port; /**< local_port - local port number */
    uint8_t  reserved1[2];
    uint32_t reserved2[3];
    uint8_t  reserved3[3];
    uint8_t  wrps_admin; /**< wrps_admin - Width Reduction Power Save Admin state */
    uint8_t  reserved4[3];
    uint8_t  wrps_status; /**< wrps_status - link actual width */
    uint8_t  reserved5;
    uint8_t  up_threshold; /**< up_threshold - Link Width Up Threshold - the amount of data queued on the link before the link goes back to full width */
    uint8_t  reserved6;
    uint8_t  down_threshold; /**< down_threshold - Link Width Down Threshold - the amount of quiet time on the link before the link width is moved to single lane */
    uint32_t reserved7;
    uint8_t  reserved8[3];
    uint8_t  srps_admin; /**< srps_admin - Speed Reduction Power Save Admin state */
    uint8_t  reserved9[3];
    uint8_t  srps_status; /**< srps_status - link actual speed */
} PACK_SUFFIX sxd_emad_ppsc_reg_t;

/**
 * sxd_emad_jtag_transaction_set_t structure is used to store
 * mjtag transaction sets
 */
typedef struct sxd_emad_jtag_transaction_set {
    uint8_t tdo_tdi_tms;
} PACK_SUFFIX sxd_emad_jtag_transaction_set_t;

/**
 * sxd_emad_mjtag_reg_t structure is used to store MJTAG
 * register layout.
 */
typedef struct sxd_emad_mjtag_reg {
    uint8_t                         cmd_seq_num; /**< Command & Command Sequest Number  */
    uint8_t                         reserved[2];
    uint8_t                         size; /**< Size of operation */
    sxd_emad_jtag_transaction_set_t jtag_transaction_sets[MAX_TRANSACTIONS_NUM];
} PACK_SUFFIX sxd_emad_mjtag_reg_t;

/**
 * sxd_emad_raw_reg_t structure is used to store RAW
 * register layout.
 */
typedef struct sxd_emad_raw_reg {
    uint8_t buff[0]; /**< RAW buffer  */
} PACK_SUFFIX sxd_emad_raw_reg_t;

/**
 * sxd_emad_mrsr_reg_t structure is used to store MRSR register
 * layout.
 */
typedef struct sxd_emad_mrsr_reg {
    net16_t reserved1;
    uint8_t reserved2;
    uint8_t command;
} PACK_SUFFIX sxd_emad_mrsr_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_SYSTEM_REG_H__ */
