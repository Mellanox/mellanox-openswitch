/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_POLICER_H__
#define __SXD_POLICER_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define SXD_POLICER_CBS_MIN (0x00000000)
#define SXD_POLICER_CBS_MAX (0x0000001E)
#define SXD_POLICER_EBS_MIN (0x00000000)
#define SXD_POLICER_EBS_MAX (0x0000001E)
#define SXD_POLICER_CIR_MIN (0x00000000)
#define SXD_POLICER_CIR_MAX (0x00FFFFFF)

#define SXD_POLICER_MAX_POLICERS_PER_PORT (5)
#define SXD_POLICER_MAX_POLICERS_GLOBAL   (9)

/************************************************
 *  Macros
 ***********************************************/

#define SXD_POLICER_CBS_CHECK_RANGE(CBS) \
    SXD_CHECK_RANGE(SXD_POLICER_CBS_MIN, \
                    CBS,                 \
                    SXD_POLICER_CBS_MAX)

#define SXD_POLICER_EBS_CHECK_RANGE(EBS) \
    SXD_CHECK_RANGE(SXD_COS_EBS_MIN,     \
                    EBS,                 \
                    SXD_POLICER_EBS_MAX)

#define SXD_POLICER_CIR_CHECK_RANGE(CIR) \
    SXD_CHECK_RANGE(SXD_COS_CIR_MIN,     \
                    CIR,                 \
                    SXD_POLICER_CIR_MAX)

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Policer ID.
 */
typedef uint8_t sxd_policer_id_t;

/**
 * sxd_policer_bind_type_t enumarated type is used to store
 * policer bind type.
 */
typedef enum sxd_policer_bind_type {
    SXD_POLICER_BIND_TYPE_UNICAST = (1 << 0),
    SXD_POLICER_BIND_TYPE_MULTICAST = (1 << 1),
    SXD_POLICER_BIND_TYPE_BROADCAST = (1 << 2),
    SXD_POLICER_BIND_TYPE_UNKNOWN_UNICAST = (1 << 3),
    SXD_POLICER_BIND_TYPE_UNKNOWN_MULTICAST = (1 << 4),
} sxd_policer_bind_type_t;

/**
 * sxd_policer_operation_t enumarated type is used to store
 * policer operation.
 */
typedef enum sxd_policer_operation {
    SXD_POLICER_OPERATION_BIND = 0,
    SXD_POLICER_OPERATION_UPDATE = 1,
    SXD_POLICER_OPERATION_UNBIND = 2
} sxd_policer_operation_t;

/**
 * sxd_policer_operation_t enumarated type is used to store
 * policer operation.
 */
typedef enum sxd_policer_meter {
    SXD_POLICER_METER_BYTES_SEC = 1,
    SXD_POLICER_METER_PACKETS_SEC = 0,
} sxd_policer_meter_t;

/**
 * sxd_policer_action_t enumarated type is used to store policer
 * action.
 */
typedef enum sxd_policer_action {
    SXD_POLICER_ACTION_FORWARD = 0,
    SXD_POLICER_ACTION_DISCARD = 1,
    SXD_POLICER_ACTION_FORWARD_SET_RED_COLOR = 2,
    SXD_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR = 2,
} sxd_policer_action_t;

/**
 * sxd_policer_yellow_action_t enumarated type is used to store
 * policer yellow action.
 */
typedef enum sxd_policer_yellow_action {
    SXD_POLICER_YELLOW_ACTION_FORWARD = 0,
    SXD_POLICER_YELLOW_ACTION_DISCARD = 1,
    SXD_POLICER_YELLOW_ACTION_FORWARD_SET_YELLOW_COLOR = 2,
} sxd_policer_yellow_action_t;

/**
 * sxd_policer_red_action_t enumarated type is used to store
 * policer red action.
 */
typedef enum sxd_policer_red_action {
    SXD_POLICER_RED_ACTION_FORWARD = 0,
    SXD_POLICER_RED_ACTION_DISCARD = 1,
    SXD_POLICER_RED_ACTION_FORWARD_SET_RED_COLOR = 2,
} sxd_policer_red_action_t;

/**
 * sxd_policer_type_t enumarated type is used to
 * store policer types
 */
typedef enum sxd_policer_type {
    SXD_POLICER_TYPE_PER_PORT = 0,
    SXD_POLICER_TYPE_GLOBAL = 2,
    SXD_POLICER_TYPE_STORM_CONTROL = 3,
    SXD_POLICER_TYPE_MIN = SXD_POLICER_TYPE_PER_PORT,
    SXD_POLICER_TYPE_MAX = SXD_POLICER_TYPE_STORM_CONTROL
} sxd_policer_type_t;

/**
 * sxd_policer_mode_t enumarated type is used to
 * store policer modes
 */
typedef enum sxd_policer_mode {
    SXD_POLICER_MODE_POLICER = 0,      /**< policer mode */
    SXD_POLICER_MODE_PACKET_SAMPLING = 1,      /**< packet sampling mode */

    SXD_POLICER_MODE_MIN = SXD_POLICER_MODE_POLICER,
    SXD_POLICER_MODE_MAX = SXD_POLICER_MODE_PACKET_SAMPLING,
} sxd_policer_mode_t;

/**
 * sx_policer_type_t enumerated type is used to
 * note a policer type.
 */
typedef enum sxd_policer_bind_state {
    SXD_POLICER_STATE_DISABLE = 0,  /**< Policer bind state  */
    SXD_POLICER_STATE_ENABLE = 1,  /**< Policer bind state  */
} sxd_policer_bind_state_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_POLICER_H__ */
