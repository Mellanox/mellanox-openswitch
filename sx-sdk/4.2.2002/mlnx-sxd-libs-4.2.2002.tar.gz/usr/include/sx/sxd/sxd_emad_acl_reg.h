/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_ACL_REG_H__
#define __SXD_EMAD_ACL_REG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/kernel_user.h>
#include <complib/cl_packon.h>


#ifdef SXD_EMAD_ACL_REG_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * emad_ptar_reg_t structure is used to store PTAR register
 * layout.
 */
typedef struct sxd_emad_ptar_reg {
    uint8_t op_dir;
    uint8_t action_set_type;
    uint8_t reserved1;
    uint8_t key_type;
    uint8_t reserved2[2];
    net16_t region_size;
    uint8_t reserved3[2];
    net16_t region_id;
    uint8_t reserved4[2];
    uint8_t op_type;
    uint8_t packet_rate;
    uint8_t tcam_region_info[16];
    uint8_t flexible_key_id[16];
} PACK_SUFFIX sxd_emad_ptar_reg_t;


/**
 * emad_pacl_reg_t structure is used to store PACL register
 * layout.
 */
typedef struct sxd_emad_pacl_reg {
    uint8_t e_v;
    uint8_t reserved1[2];
    uint8_t acl_type;
    uint8_t reserved2[6];
    net16_t acl_id;
    uint8_t reserved3[36];
    uint8_t tcam_region_info0[16];
    uint8_t tcam_region_info1[16];
    uint8_t tcam_region_info2[16];
    uint8_t tcam_region_info3[16];
} PACK_SUFFIX sxd_emad_pacl_reg_t;


/**
 * sxd_emad_ptce_key_ipv4_full_t structure is used to store PTCE
 * register IPv4 Full key layout.
 */
typedef struct sxd_emad_ptce_key_ipv4_full {
    net32_t dst_ip_127_96;
    net32_t dst_ip_95_64;
    net32_t dst_ip_63_32;
    net32_t dst_ip_31_0;
    net32_t src_ip_127_96;
    net32_t src_ip_95_64;
    net32_t src_ip_63_32;
    net32_t src_ip_31_0;
    net16_t src_l4_port;
    net16_t dst_l4_port;
    uint8_t ttl;
    uint8_t tcp_flags;
    uint8_t ip_proto;
    uint8_t ip_tos;
    net16_t flags;
    uint8_t reserved1;
    uint8_t ipv6_ext;
    net16_t reserved2;
    net16_t dst_sys_port;
    net16_t reserved3;
    net16_t src_sys_port;
    net16_t reserved4;
    net16_t l4_port_range;
    net32_t flow_label;
    net32_t reserved5;
} PACK_SUFFIX sxd_emad_ptce_key_ipv4_full_t;


/**
 * sxd_emad_ptce_key_ipv4_full_t structure is used to store PTCE
 * register IPv4 Full key layout.
 */
typedef struct sxd_emad_ptce_key_mac_full {
    uint8_t dmac[6];
    uint8_t smac[6];
    net16_t ethertype;
    net16_t vlan_prio;
    uint8_t reserved1[3];
    uint8_t vlan_flags;
    net32_t slag_dmac_type;
    net16_t src_sys_port;
    net16_t dst_sys_port;
    net32_t reserved2[9];
} PACK_SUFFIX sxd_emad_ptce_key_mac_full_t;

typedef struct sxd_emad_ptce_key_mac_short {
    uint8_t dmac[6];
    uint8_t smac[6];
    net16_t reserved3;
    net16_t vlan_prio;
    uint8_t reserved1[3];
    uint8_t vlan_flags;
    net32_t slag_dmac_type;
    net16_t src_sys_port;
    net16_t reserved4;
    net32_t reserved2[9];
} PACK_SUFFIX sxd_emad_ptce_key_mac_short_t;

typedef struct sxd_emad_ptce_key_mac_ipv4_full {
    uint8_t dmac[6];
    uint8_t smac[6];
    net16_t ethertype;
    net16_t vlan_prio;
    uint8_t vlan_type_slag;
    uint8_t reserved1[2];
    uint8_t vlan_valid;
    net16_t src_sys_port;
    uint8_t reserved2[10];
    net32_t dst_ipv4;
    net32_t src_ipv4;
    net16_t src_l4_port;
    net16_t dst_l4_port;
    uint8_t ip_flags;
    uint8_t reserved3;
    uint8_t ip_proto;
    uint8_t ip_tos;
    net32_t reserved4[4];
} PACK_SUFFIX sxd_emad_ptce_key_mac_ipv4_full_t;

/**
 * sxd_emad_ptce_key_fcoe_full_t structure is used to store PTCE
 * register FCoE Full key layout.
 */
typedef struct sxd_emad_ptce_key_fcoe_full {
    uint8_t dmac[6];
    uint8_t smac[6];
    uint8_t reserved0[2];
    net16_t prio_vid;
    uint8_t vlan_type_slag;
    uint8_t reserved1[2];
    uint8_t vlan_valid;
    net16_t src_sys_port;
    uint8_t reserved2[11];
    uint8_t d_id[3];
    uint8_t reserved3;
    uint8_t s_id[3];
    net16_t ox_id;
    net16_t rx_id;
    uint8_t is_fc;
    uint8_t reserved4;
    uint8_t r_ctl;
    uint8_t type;
    net32_t reserved5[4];
} PACK_SUFFIX sxd_emad_ptce_key_fcoe_full_t;

/**
 * sxd_emad_ptce_key_reg_t structure is used to store PTCE
 * register keys layout.
 */
typedef union sxd_emad_ptce_key_reg {
    sxd_emad_ptce_key_ipv4_full_t     ipv4;     /* Also for IPv6 */
    sxd_emad_ptce_key_mac_full_t      mac_full;
    sxd_emad_ptce_key_mac_short_t     mac_short;
    sxd_emad_ptce_key_mac_ipv4_full_t mac_ipv4;
    sxd_emad_ptce_key_fcoe_full_t     fcoe;
    uint8_t                           raw[64];
} PACK_SUFFIX sxd_emad_ptce_key_reg_t;

typedef struct sxd_emad_ptce_action_default {
    net32_t reserved1;
    uint8_t trap;
    uint8_t trap_grp;
    net16_t trap_id;
    uint8_t m_dst;
    uint8_t reserved2[3];
    uint8_t vlan_prio_tcls_op;
    net16_t vid_prio;
    uint8_t et_st_class;
    net32_t reserved3;
    net32_t flow_counter;
    uint8_t reserved4;
    uint8_t policer_port;
    uint8_t g_policer;
    uint8_t pid;
    uint8_t reserved5[3];
    uint8_t nr_nl;
} PACK_SUFFIX sxd_emad_ptce_action_default_t;

typedef struct sxd_emad_ptce_action_extended {
    net32_t reserved1;
    uint8_t trap;
    uint8_t trap_grp;
    net16_t trap_id;
    uint8_t m_dst;
    uint8_t reserved2[3];
    uint8_t vlan_prio_tcls_op;
    net16_t vid_prio;
    uint8_t et_st_class;
    net32_t reserved3;
    net32_t flow_counter;
    uint8_t reserved4;
    uint8_t policer_port;
    uint8_t g_policer;
    uint8_t pid;
    net32_t reserved5[2];
    uint8_t pbse;
    uint8_t reserved6;
    net16_t pbs_table_index;
} PACK_SUFFIX sxd_emad_ptce_action_extended_t;

/**
 * sxd_emad_ptce_action_reg_t structure is used to store PTCE
 * register actions layout.
 */
typedef union sxd_emad_ptce_action_reg {
    sxd_emad_ptce_action_default_t  dflt_action;
    sxd_emad_ptce_action_extended_t extended_action;
    uint8_t                         raw[64];
} PACK_SUFFIX sxd_emad_ptce_action_reg_t;

/**
 * sxd_emad_ptce_reg_t structure is used to store PTCE register
 * layout.
 */
typedef struct sxd_emad_ptce_reg {
    uint8_t                    v_a;
    uint8_t                    op;
    net16_t                    offset;
    net32_t                    reserved2[3];
    uint8_t                    tcam_region_info[16];
    sxd_emad_ptce_key_reg_t    key;
    sxd_emad_ptce_key_reg_t    mask;
    sxd_emad_ptce_action_reg_t action;
    uint8_t                    term_asbind;
    uint8_t                    reserved3[3];
    uint8_t                    g_e;
    uint8_t                    reserved4;
    net16_t                    acl_id_grp_id;
    net32_t                    reserved5[6];
} PACK_SUFFIX sxd_emad_ptce_reg_t;


/**
 * sxd_mac_flex_action_reg_t structure is used to store
 * mac flex action
 */
typedef struct sxd_mac_flex_action_reg {
    uint8_t ttl_cmd;
    uint8_t ttl;
    uint8_t reserved0;
    uint8_t defer;
    uint8_t mac_cmd;
    uint8_t reserved1[5];
    uint8_t mac[6];
} PACK_SUFFIX sxd_mac_flex_action_reg_t;

/**
 * sxd_vlan_flex_action_reg_t structure is used to store
 * sxd vlan flex action_reg_t
 */
typedef struct sxd_vlan_flex_action_reg {
    uint8_t v_tag_cmd;
    uint8_t reserved0[2];
    uint8_t defer;
    uint8_t vid_cmd;
    uint8_t reserved1;
    net16_t vid;
    uint8_t ethertype_cmd_ethertype;
    uint8_t reserved2;
    uint8_t pcp_cmd_pcp;
    uint8_t reserved3;
    uint8_t dei_cmd_dei;
    uint8_t reserved4[3];
} PACK_SUFFIX sxd_vlan_flex_action_reg_t;

/**
 * sxd_trap_flex_action_reg_t structure is used to store
 * trap flex action
 */
typedef struct sxd_trap_flex_action_reg {
    uint8_t trap_action;
    uint8_t reserved0[2];
    uint8_t forward_action;
    uint8_t reserved1[2];
    net16_t trap_id;
    uint8_t mirror_agent_enable;
    uint8_t reserved2[3];
    uint8_t defer;
    uint8_t reserved3[3];
} PACK_SUFFIX sxd_trap_flex_action_reg_t;

/**
 * sxd_trap_w_user_defined_flex_action_reg structure is used to store
 * trap with user defined flex action
 */
typedef struct sxd_trap_w_user_defined_flex_action_reg {
    uint8_t trap_action;
    uint8_t reserved0[2];
    uint8_t forward_action;
    uint8_t reserved1[2];
    net16_t trap_id;
    uint8_t mirror_agent_enable;
    uint8_t reserved2[3];
    net32_t defer_user_def;
} PACK_SUFFIX sxd_trap_w_user_defined_flex_action_reg_t;

/**
 * sxd_port_filter_flex_action_reg structure is used to store
 * port filter flex action
 */
typedef struct sxd_port_filter_flex_action_reg {
    uint8_t reserved0[8];
    net32_t egress_port_list_63_32;
    net32_t egress_port_list_31_0;
} PACK_SUFFIX sxd_port_filter_flex_action_reg_t;

/**
 * sxd_qos_flex_action_reg structure is used to store
 * qos flex action
 */
typedef struct sxd_qos_flex_action_reg {
    uint8_t reserved0[3];
    uint8_t defer;
    uint8_t ecn_cmd_ecn;
    uint8_t color_cmd_color;
    uint8_t dscp_cmd;
    uint8_t dscp;
    uint8_t reserved1[2];
    uint8_t switch_prio_cmd;
    uint8_t switch_prio;
    uint8_t dscp_rw_pcp_rw;
    uint8_t reserved2[2];
    uint8_t tc_cmd_tc_val;
} PACK_SUFFIX sxd_qos_flex_action_reg_t;

/**
 * sxd_forward_flex_action_reg_t  structure is used to store
 * forward flex action
 */
typedef struct sxd_forward_flex_action_reg {
    uint8_t type;
    uint8_t reserved0[6];
    uint8_t defer;
    net32_t pbs_ptr;
    uint8_t reserved1[3];
    uint8_t port;
} PACK_SUFFIX sxd_forward_flex_action_reg_t;

/**
 * sxd_policing_monitoring_flex_action_reg_t structure is used to store
 * policing monitoring flex action
 */
typedef struct sxd_policing_monitoring_flex_action_reg {
    uint8_t c_p;
    uint8_t reserved0[3];
    net32_t counter_set;
    uint8_t reserved1[2];
    net16_t pid;
    uint8_t reserved[4];
} PACK_SUFFIX sxd_policing_monitoring_flex_action_reg_t;

/**
 * sxd_metadata_flex_action_reg_t structure is used to store
 * metadata flex action
 */
typedef struct sxd_metadata_flex_action_reg {
    uint8_t reserved0[10];
    net16_t meta_data;
    uint8_t reserved1[2];
    net16_t mask;
} PACK_SUFFIX sxd_metadata_flex_action_reg_t;


/**
 * sxd_uc_router_flex_action_ip_remote_reg_t structure is used to store
 * uc router flex action ip remote
 */
typedef struct sxd_uc_router_flex_action_ip_remote_reg {
    net32_t adjacency_index;
    uint8_t reserved0[2];
    net16_t ecmp_size;
    uint8_t reserved1[4];
} PACK_SUFFIX sxd_uc_router_flex_action_ip_remote_reg_t;


/**
 * sxd_uc_router_flex_action_ip_local_reg_t structure is used to store
 * uc router flex action ip local
 */
typedef struct sxd_uc_router_flex_action_ip_local_reg {
    uint8_t reserved0[10];
    net16_t local_erif;
} PACK_SUFFIX sxd_uc_router_flex_action_ip_local_reg_t;

/**
 * sxd_uc_router_flex_action_tunnel_termination_reg_t structure is used to store
 * uc router flex action tunnel termination
 */
typedef struct sxd_uc_router_flex_action_tunnel_termination_reg {
    uint8_t reserved0[4];
    net32_t tunnel_ptr;
    uint8_t reserved1[4];
} PACK_SUFFIX sxd_uc_router_flex_action_tunnel_termination_reg_t;


/**
 * sxd_uc_router_flex_action_mpls_ilm_reg_t structure is used to store
 * uc router flex action mpls ilm
 */
typedef struct sxd_uc_router_flex_action_mpls_ilm_reg {
    uint8_t reserved0[4];
    net32_t ilm_ptr;
    uint8_t reserved1[4];
} PACK_SUFFIX sxd_uc_router_flex_action_mpls_ilm_reg_t;

/**
 * sxd_uc_router_flex_action_mpls_nhlfe_reg_t structure is used to store
 * uc router flex action mpls_nhlfe
 */
typedef struct sxd_uc_router_flex_action_mpls_nhlfe_reg {
    net32_t nhlfe_ptr;
    uint8_t reserved1[2];
    net16_t ecmp_size;
    uint8_t reserved2[4];
} PACK_SUFFIX sxd_uc_router_flex_action_mpls_nhlfe_reg_t;

/**
 * sxd_uc_router_flex_action_reg_t structure is used to store
 * uc router flex action
 */
typedef struct sxd_uc_router_flex_action_reg {
    uint8_t type;
    uint8_t reserved0[3];
    union {
        sxd_uc_router_flex_action_ip_remote_reg_t          ip_remote;
        sxd_uc_router_flex_action_ip_local_reg_t           ip_local;
        sxd_uc_router_flex_action_tunnel_termination_reg_t tunnel_termination;
        sxd_uc_router_flex_action_mpls_ilm_reg_t           mpls_ilm;
        sxd_uc_router_flex_action_mpls_nhlfe_reg_t         mpls_nhlfe;
        uint8_t                                            raw[12];
    };
} PACK_SUFFIX sxd_uc_router_flex_action_reg_t;

/**
 * sxd_vni_flex_action_reg_t structure is used to store
 * vni flex action
 */
typedef struct sxd_vni_flex_action_reg {
    uint8_t reserved0[8];
    net32_t set_vni_vni;
    uint8_t reserved1[4];
} PACK_SUFFIX sxd_vni_flex_action_reg_t;

/**
 * sxd_mpls_action_reg_t structure is used to store
 * mpls flex action
 */
typedef struct sxd_mpls_flex_action_reg_ {
    uint8_t ttl_cmd;
    uint8_t ttl;
    uint8_t reserved0[2];
    uint8_t exp_cmd;
    uint8_t reserved1[2];
    uint8_t exp;
    uint8_t exp_rw;
    uint8_t reserved3[3];
} PACK_SUFFIX sxd_mpls_flex_action_reg_t;

/**
 * sxd_hash_flex_action_reg_t structure is used to store
 * hash flex action
 */
typedef struct sxd_hash_flex_action_reg {
    uint8_t type;
    uint8_t reserved0[2];
    uint8_t hash_cmd;
    net16_t hash_value;
    uint8_t reserved1;
    uint8_t hash_fields;
    net32_t hash_mask;
    net32_t reserved2;
} PACK_SUFFIX sxd_hash_flex_action_reg_t;

/**
 * sxd_virtual_forward_flax_action_reg_t structure is used to store
 * virtual forward flex action
 */
typedef struct sxd_virtual_forward_flax_action_reg {
    uint8_t vr_cmd;
    uint8_t reserved0;
    net16_t virtual_router;
    uint8_t reserved1[4];
    uint8_t fid_cmd;
    uint8_t reserved2;
    net16_t fid;
    uint8_t reserved3[4];
} PACK_SUFFIX sxd_virtual_forward_flax_action_reg_t;

/**
 * sxd_ignore_flex_action_reg_t structure is used to store
 * ignore flex action
 */
typedef struct sxd_ignore_flex_action_reg {
    uint8_t is_iv_dl;
    uint8_t reserved0[7];
    uint8_t disable_ovl_learning;
    uint8_t reserved1[7];
} PACK_SUFFIX sxd_ignore_flex_action_reg_t;

typedef struct sxd_mc_flex_action_reg {
    uint8_t rpf_action_eir_type;
    uint8_t reserved0[1];
    net16_t expected_irif;
    net32_t expected_irif_list_index;
    uint8_t reserved2[2];
    net16_t min_mtu;
    net32_t vrmid_rigr_rmid_index;
} PACK_SUFFIX sxd_mc_flex_action_reg_t;

/**
 * sxd_emad_goto_set_action_reg structure is used to store
 * goto set action
 */
typedef struct sxd_emad_flex_action_reg_t {
    uint8_t type;
    uint8_t reserved0[3];
    union {
        sxd_mac_flex_action_reg_t                 action_mac;
        sxd_vlan_flex_action_reg_t                action_vlan;
        sxd_trap_flex_action_reg_t                action_trap;
        sxd_trap_w_user_defined_flex_action_reg_t action_trap_w_user_defined;
        sxd_port_filter_flex_action_reg_t         action_port_filter;
        sxd_qos_flex_action_reg_t                 action_qos;
        sxd_forward_flex_action_reg_t             action_forward;
        sxd_policing_monitoring_flex_action_reg_t action_policing_monitoring;
        sxd_metadata_flex_action_reg_t            action_metadata;
        sxd_uc_router_flex_action_reg_t           action_uc_router;
        sxd_vni_flex_action_reg_t                 action_vni;
        sxd_mpls_flex_action_reg_t                action_mpls;
        sxd_hash_flex_action_reg_t                action_hash;
        sxd_virtual_forward_flax_action_reg_t     action_virtual_forward;
        sxd_ignore_flex_action_reg_t              action_ignore;
        sxd_mc_flex_action_reg_t                  action_mc;
        net32_t                                   raw[7];
    } fields_reg_t;
} PACK_SUFFIX sxd_emad_flex_action_reg_t;

/**
 * sxd_emad_goto_set_action_reg_t structure is used to store
 * flex_action
 */
typedef struct sxd_emad_goto_set_action_reg {
    uint8_t commit__clear_g_binding_cmd;
    uint8_t reserved0;
    net16_t next_binding;
} PACK_SUFFIX sxd_emad_goto_set_action_reg_t;


/**
 * sxd_emad_flex_action_set_next_goto_record_reg_t structure is used to store
 * next_goto_record types
 */
typedef union sxd_emad_flex_action_set_next_goto_record_reg {
    net32_t                        next_action_set_ptr;
    sxd_emad_goto_set_action_reg_t goto_set_action;
    net32_t                        raw;
} PACK_SUFFIX sxd_emad_flex_action_set_next_goto_record_reg_t;

/**
 * sxd_emad_flex_action_set_reg_t structure is used to store flex_action_set.
 */
typedef struct sxd_emad_flex_action_set_reg {
    sxd_emad_flex_action_reg_t                      action_set[SXD_ACL_NUM_OF_ACTION_SLOTS];
    uint8_t                                         type;
    uint8_t                                         reserved0[3];
    sxd_emad_flex_action_set_next_goto_record_reg_t next_goto_record;
} PACK_SUFFIX sxd_emad_flex_action_set_reg_t;

/**
 * sxd_emad_ptce2_reg_t structure is used to store PTCE2 register
 * layout.
 */
typedef struct sxd_emad_ptce2_reg {
    uint8_t                        v_a;
    uint8_t                        op;
    net16_t                        offset;
    uint8_t                        reserved0[12];
    uint8_t                        tcam_region_info[SXD_ACL_INFO_SIZE_BYTES];
    uint8_t                        flex_key_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES];
    uint8_t                        mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES];
    sxd_emad_flex_action_set_reg_t flex_action_set;
    uint8_t                        reserved1[8];
} PACK_SUFFIX sxd_emad_ptce2_reg_t;

/**
 * sxd_emad_pefa_reg_t structure is used to store PEFA register
 * layout.
 */
typedef struct sxd_emad_pefa_reg {
    net32_t                        index;
    uint32_t                       reserved;
    sxd_emad_flex_action_set_reg_t flex_action_set;
} PACK_SUFFIX sxd_emad_pefa_reg_t;

typedef struct sxd_flex_extraction_point_reg {
    uint8_t enable;
    uint8_t offset;
} PACK_SUFFIX sxd_flex_extraction_point_reg_t;


/**
 * sxd_emad_pefa_reg_t structure is used to store PEFA register
 * layout.
 */
typedef struct sxd_emad_pecb_reg {
    uint8_t reserved[7];
    uint8_t cbset;
    uint8_t reserved1[8];
    union {
        sxd_flex_extraction_point_reg_t extraction_points[SXD_ACL_NUM_OF_EXTRACTION_POINT];
        net16_t                         raw[SXD_ACL_NUM_OF_EXTRACTION_POINT];
    } field;
} PACK_SUFFIX sxd_emad_pecb_reg_t;

typedef struct sxd_pemb_recorde_multicast_egress_reg {
    uint8_t group_id;
    uint8_t reserved[2];
    uint8_t valid;
    uint8_t reserved1[4];
    net32_t egress_port_list_63_32;
    net32_t egress_port_list_31_0;
} PACK_SUFFIX sxd_pemb_recorde_multicast_egress_reg_t;

typedef struct sxd_emad_pemb_reg {
    uint8_t reserved;
    uint8_t type;
    uint8_t reserved1[2];
    union {
        sxd_pemb_recorde_multicast_egress_reg_t multicast_egress;
        net32_t                                 raw[4];
    } record;
} PACK_SUFFIX sxd_emad_pemb_reg_t;


/**
 * sxd_emad_prbt_reg_t structure is used to store PRBT register
 * layout.
 */
typedef struct sxd_emad_prbt_reg {
    uint8_t e_op;
    uint8_t reserved0;
    net16_t rif;
    net32_t reserved1[3];
    uint8_t g;
    uint8_t reserved3;
    net16_t acl_id_grp_id;
} PACK_SUFFIX sxd_emad_prbt_reg_t;

/**
 * sxd_emad_prcr_reg_t structure is used to store PRCR register
 * layout.
 */
typedef struct sxd_emad_prcr_reg {
    uint8_t op;
    uint8_t reserved0;
    net16_t offset;
    net16_t reserved1;
    net16_t size;
    net32_t reserved2[2];
    uint8_t tcam_region_info[16];
    net16_t reserved3;
    net16_t dest_offset;
    net32_t reserved4[3];
    uint8_t dest_tcam_region_info[16];
} PACK_SUFFIX sxd_emad_prcr_reg_t;

/**
 * sxd_emad_ppbt_reg_t structure is used to store PPBT register
 * layout.
 */
typedef struct sxd_emad_ppbt_reg {
    uint8_t e_op;
    uint8_t port;
    uint8_t sub_port;
    uint8_t reserved1[13];
    uint8_t g;
    uint8_t reserved2;
    net16_t acl_id_grp_id;
} PACK_SUFFIX sxd_emad_ppbt_reg_t;


/**
 * sxd_emad_pvbt_reg_t structure is used to store PVBT register
 * layout.
 */
typedef struct sxd_emad_pvbt_reg {
    uint8_t swid;
    uint8_t e_op;
    net16_t vid;
    uint8_t reserved1[12];
    uint8_t g;
    uint8_t reserved2;
    net16_t acl_id_grp_id;
} PACK_SUFFIX sxd_emad_pvbt_reg_t;


/**
 * sxd_emad_pagt_reg_t structure is used to store PAGT register
 * layout.
 */
typedef struct sxd_emad_pagt_reg_acl_id {
    uint8_t reserved[2];
    net16_t acl_id;
} PACK_SUFFIX sxd_emad_pagt_reg_acl_id_t;


/**
 * sxd_emad_pagt_reg_t structure is used to store PAGT register
 * layout.
 */
typedef struct sxd_emad_pagt_reg {
    uint8_t                    e;
    net16_t                    reserved1;
    uint8_t                    size;
    net16_t                    reserved2[3];
    net16_t                    acl_group_id;
    uint8_t                    reserved3[36];
    sxd_emad_pagt_reg_acl_id_t acl_ids[SXD_MAX_ACL_IN_GROUP];
} PACK_SUFFIX sxd_emad_pagt_reg_t;


/**
 * sxd_emad_pprr_reg_t structure is used to store PPRR register
 * layout.
 */
typedef struct sxd_emad_pprr_reg {
    uint8_t flags;
    uint8_t inner_outer_ip_length;
    uint8_t reserved1;
    uint8_t register_index;
    net16_t port_range_min;
    net16_t port_range_max;
    uint8_t reserved2[8];
} PACK_SUFFIX sxd_emad_pprr_reg_t;


/**
 * sxd_emad_pvgt_reg_t structure is used to store PVGT register
 * layout.
 */
typedef struct sxd_emad_pvgt_reg {
    uint8_t swid;
    uint8_t op;
    net16_t vid;
    net16_t reserved1;
    net16_t vlan_group;
    uint8_t reserved2[8];
} PACK_SUFFIX sxd_emad_pvgt_reg_t;


/**
 * sxd_emad_pgcr_reg_t structure is used to store PGCR register
 * layout.
 */
typedef struct sxd_emad_pgcr_reg {
    uint8_t reserved[2];
    net16_t pbs_table_size;
    uint8_t reserved1[4];
    net16_t max_eacl;
    net16_t max_iacl;
    uint8_t reserved3[6];
    net16_t parsing_depth;
    uint8_t reserved4[12];
} PACK_SUFFIX sxd_emad_pgcr_reg_t;


/**
 * sxd_emad_ppbs_uni_record_t structure is used to store PPBS
 * unicast record register layout.
 */
typedef struct sxd_emad_ppbs_uni_record {
    uint8_t v_fid;
    uint8_t sub_port;
    net16_t fid;
    uint8_t action;
    uint8_t reserved;
    net16_t system_port;
} PACK_SUFFIX sxd_emad_ppbs_uni_record_t;

/**
 * sxd_emad_ppbs_lag_record_t structure is used to store PPBS
 * lag record register layout.
 */
typedef struct sxd_emad_ppbs_lag_record {
    uint8_t reserved;
    uint8_t sub_port;
    net16_t update_vid_vid;
    uint8_t reserved1[2];
    net16_t lag_id;
} PACK_SUFFIX sxd_emad_ppbs_lag_record_t;

/**
 * sxd_emad_ppbs_mcast_record_t structure is used to store PPBS
 * multicast record register layout.
 */
typedef struct sxd_emad_ppbs_mcast_record {
    net16_t pgi;
    net16_t fid;
    uint8_t action;
    uint8_t reserved1;
    net16_t mid;
} PACK_SUFFIX sxd_emad_ppbs_mcast_record_t;

typedef struct sxd_emad_ppbs_tunnel_uni_record {
    net32_t udip;
    uint8_t protocol;
    uint8_t reserved[3];
} PACK_SUFFIX sxd_emad_ppbs_tunnel_uni_record_t;

typedef struct sxd_emad_ppbs_tunnel_mcast_record {
    net16_t underlay_mc_ptr_msb;
    net16_t fid;
    uint8_t underlay_mc_ptr_lsb;
    uint8_t v_fid;
    net16_t mid;
} PACK_SUFFIX sxd_emad_ppbs_tunnel_mcast_record_t;


/**
 * sxd_emad_ppbs_record_reg_t structure is used to store PPBS
 * record types
 */
typedef union sxd_emad_ppbs_record_reg {
    sxd_emad_ppbs_uni_record_t          unicast;   /* Also for IPv6 */
    sxd_emad_ppbs_lag_record_t          lag;
    sxd_emad_ppbs_mcast_record_t        mcast;
    sxd_emad_ppbs_tunnel_mcast_record_t tunnel_mcast;
    sxd_emad_ppbs_tunnel_uni_record_t   tunnel_unicast;
    uint8_t                             raw[8];
} PACK_SUFFIX sxd_emad_ppbs_record_reg_t;


/**
 * sxd_emad_ppbs_reg_t structure is used to store PPBS register
 * layout.
 */
typedef struct sxd_emad_ppbs_reg {
    uint8_t                    reserved[4];
    uint8_t                    swid;
    uint8_t                    type;
    uint8_t                    reserved1[2];
    net32_t                    index;
    sxd_emad_ppbs_record_reg_t pbs_record;
} PACK_SUFFIX sxd_emad_ppbs_reg_t;

/**
 * sxd_emad_puet_reg_t structure is used to store PUET register
 * layout.
 */
typedef struct sxd_emad_puet_reg {
    uint8_t reserved[3];
    uint8_t index;
    net16_t reserved1;
    net16_t ethertype;
    net32_t reserved2[2];
} PACK_SUFFIX sxd_emad_puet_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

#endif /* ifndef __SXD_EMAD_ACL_REG_H__ */
