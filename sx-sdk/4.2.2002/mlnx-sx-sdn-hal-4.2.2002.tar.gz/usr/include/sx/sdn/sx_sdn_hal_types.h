/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_TYPES_H__
#define __SX_SDN_HAL_TYPES_H__

#include <stdint.h>
#include <stddef.h>
#include <sx/sdn/sx_sdn_hal_access_cmd.h>
#include <sx/sdn/sx_sdn_hal_events.h>
#include <sx/sdn/sx_sdn_hal_general.h>
#include <sx/sdn/sx_sdn_hal_port.h>
#include <sx/sdn/sx_sdn_hal_protocol.h>
#include <sx/sdn/sx_sdn_hal_status.h>
#include <sx/sdn/sx_sdn_hal_stp.h>
#include <sx/sdn/sx_sdn_hal_system.h>

#endif /* __SX_SDN_HAL_TYPES_H__ */
