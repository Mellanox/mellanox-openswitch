/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_STATUS_H__
#define __SX_SDN_HAL_STATUS_H__

#include <sx/sdn/sx_sdn_hal_general.h>

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sx_sdn_hal_status_t
 * Enumerated type - Provides functions' return values.
 */
typedef enum sx_sdn_hal_status {
    SX_SDN_HAL_STATUS_SUCCESS = 0,
    SX_SDN_HAL_STATUS_ERROR = 1,
    SX_SDN_HAL_STATUS_SDK_ERROR = 2,
    SX_SDN_HAL_STATUS_NOT_INITIALIZED = 3,
    SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND = 4,
    SX_SDN_HAL_STATUS_ENTRY_ALREADY_EXISTS = 5,
    SX_SDN_HAL_STATUS_CMD_UNSUPPORTED = 6,
    SX_SDN_HAL_STATUS_PARAM_ERROR = 7,
    SX_SDN_HAL_STATUS_PARAM_NULL = 8,
    SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE = 9,
    SX_SDN_HAL_STATUS_NO_RESOURCES = 10,
    SX_SDN_HAL_STATUS_RESOURCE_IN_USE = 11,

    SX_SDN_HAL_STATUS_MIN = SX_SDN_HAL_STATUS_SUCCESS,
    SX_SDN_HAL_STATUS_MAX = SX_SDN_HAL_STATUS_RESOURCE_IN_USE,
} sx_sdn_hal_status_t;

#define SX_SDN_HAL_STATUS_CHECK_RANGE(STATUS) \
    SX_SDN_HAL_CHECK_RANGE(SX_SDN_HAL_STATUS_MIN, (int)STATUS, SX_SDN_HAL_STATUS_MAX)

static __attribute__((__used__)) const char *sx_sdn_hal_status2str_arr[] = {
    /* SX_SDN_HAL_STATUS_SUCCESS = 0 */
    "Success",
    /* SX_SDN_HAL_STATUS_ERROR = 1 */
    "Internal Error",
    /* SX_SDN_HAL_STATUS_SDK_ERROR = 2 */
    "SDK Error",
    /* SX_SDN_HAL_STATUS_NOT_INITIALIZED = 3 */
    "SwitchX SDN HAL wasn't Initialized",
    /* SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND = 4 */
    "Entry not found",
    /* SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND = 5 */
    "Entry already exists",
    /* SX_SDN_HAL_STATUS_CMD_UNSUPPORTED = 6 */
    "Command unsupported",
    /* SX_SDN_HAL_STATUS_PARAM_ERROR = 7 */
    "Parameter Error",
    /* SX_SDN_HAL_STATUS_PARAM_NULL = 8 */
    "NULL parameter",
    /* SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE = 9 */
    "Parameter exceeds range",
    /* SX_SDN_HAL_STATUS_NO_RESOURCES = 10 */
    "No resources",
    /* SX_SDN_HAL_STATUS_RESOURCE_IN_USE = 11 */
    "Resource is in use",
};

#define SX_SDN_HAL_STATUS_MSG(STATUS)       \
    SX_SDN_HAL_STATUS_CHECK_RANGE(STATUS) ? \
    sx_sdn_hal_status2str_arr[STATUS] : "Unknown return code"

#endif /* __SX_SDN_HAL_STATUS_H__ */
