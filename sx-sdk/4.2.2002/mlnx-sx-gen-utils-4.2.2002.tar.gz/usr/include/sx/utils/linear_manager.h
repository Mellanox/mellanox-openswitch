/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __UTILS_LINEAR_MANAGER_H__
#define __UTILS_LINEAR_MANAGER_H__

/**
 * Linear manager module responsible for management of linear tables
 * The module has the following operations:
 *  - Init/Deinit.
 *  - Add block/Delete block
 *  - Add link to link list / Delete link
 *  - Add reference to block/ Delete reference (for cost calculation)
 */

#include <complib/cl_types.h>
#include <sx/utils/sx_utils_status.h>
#include "gbin_allocator.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define LINEAR_MANAGER_MAX_CLIENTS     10
#define LINEAR_MANAGER_MAX_TYPES       BIN_ALLOC_MAX_TYPES
#define LINEAR_MANAGER_MAX_ALLOC_SIZES BIN_ALLOC_MAX_ALLOC_SIZES
/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef void* linear_manager_db_t;

typedef ba_index_t linear_manager_index_t;

typedef linear_manager_index_t linear_manager_handle_t;

typedef uint32_t linear_manager_block_length_t;

typedef uint8_t linear_manager_allocation_types_t;

typedef ba_cb_free_group_t linear_manager_free_group_t;

typedef ba_cb_alloc_group_t linear_manager_alloc_group_t;

typedef struct linear_manager_allocation_types_params {
    uint16_t alloc_sizes[LINEAR_MANAGER_MAX_ALLOC_SIZES];
} linear_manager_allocation_types_params_t;

typedef enum {
    LINEAR_MANAGER_BLOCK_TYPE_INVALID_E = 0,
    LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E = 1,
    LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E = 2,
    LINEAR_MANAGER_BLOCK_TYPE_MAX_E = LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E,
    LINEAR_MANAGER_BLOCK_TYPE_MIN_E = LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E
} linear_manager_block_type_e;


/**
 * Callback function.
 * Copies contents of block from old index to new index and changes all references to the block
 * This callback is called when bin allocator relocates a block
 * @param handle                [in] The handle to the block which is being relocated
 * @param size                  [in] The block size
 * @param offset                [in] The offset of entry in data block to relocate
 * @param old_index_p          [in] Array of indexes to relocate from
 * @param new_index          [in] new index to relocate to
 * In case data is contiguous block offset will be 0. size will be the size of the block.
 * The contents from old_index_p until old_index_p+size should be copied
 * In case data is link list offset will be the link to relocate, and size will be size of block
 * old_index_p contains the old indexes of all links,  new_index contains the index
 * of the link to relocate
 * It is guaranteed that this callback is never called on a locked block
 */
typedef sx_utils_status_t (*linear_manager_block_relocate_t)(linear_manager_handle_t       handle,
                                                             linear_manager_block_length_t size,
                                                             linear_manager_block_length_t offset,
                                                             linear_manager_index_t      * old_index_p,
                                                             linear_manager_index_t        new_index);

/**
 * linear_manager_params_t
 * array_size - Number of entries in the total register space being managed
 * allocation_types_num - The number of supported types, different allocation types will be
 *                   allocated on different groups
 * alignment  - The alignment for each of the max_group valid suballocation
 *              regions.  Note that (array_size / group_cnt) == alignment.
 * relocate_cb - callback function which will be called each time a block is relocated
 * physical_id_cb - Return physical ID based on offset and type
 * alloc_group_cb - Provide bin allocator with a new group
 * free_group_cb - Release an now empty group
 * relocation_threshold - Threshold in percent [0..100] of packing efficiency that
 *              triggers relocation in a group.
 *  relocation_count   - The maximum number of blocks to reallocate every time
 *              the background relocation thread dispatches.
 **/
typedef struct linear_manager_params {
    linear_manager_index_t                   array_size;
    linear_manager_allocation_types_t        allocation_types_num;
    linear_manager_allocation_types_params_t allocation_types_params[LINEAR_MANAGER_MAX_TYPES];
    uint32_t                                 alignment;
    linear_manager_block_relocate_t          relocate_cb;
    linear_manager_alloc_group_t             alloc_group_cb;
    linear_manager_free_group_t              free_group_cb;
    uint8_t                                  relocation_threshold;
    uint8_t                                  relocation_count;
} linear_manager_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize linear manager datastructure
 *
 * @param database              [out] Will be filled with the datastructure handle
 * @param param_p               [in] Pointer to initialisation parameters
 */
sx_utils_status_t linear_manager_init(linear_manager_db_t    * database_p,
                                      linear_manager_params_t *param_p);

/**
 * Deinitialize linear manager datastructure
 * @param database              [in] A handle to a linear manager db
 *
 */
sx_utils_status_t linear_manager_deinit(linear_manager_db_t database);


/**
 * Add block to linear manager table
 * A user calls this function to add new block.
 * The allocated block is either contiguous or linked-list, according to block type.
 * Further operations on the block are done using the returned handle.
 *
 * @param database             [in] A handle to a linear manager db
 * @param allocation_types      [in] the allocation type of the block
 * @param block_type           [in] type of block - link list / contiguous
 * @param size                  [in] Size of block
 * @param handle                [out] Returns a handle to the new block
 *
 */
sx_utils_status_t linear_manager_block_add(linear_manager_db_t               database,
                                           linear_manager_allocation_types_t allocation_types,
                                           linear_manager_block_type_e       block_type,
                                           linear_manager_block_length_t     size,
                                           linear_manager_handle_t         * handle);

/**
 * Delete a block from linear table
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to a block
 */
sx_utils_status_t linear_manager_block_delete(linear_manager_db_t     database,
                                              linear_manager_handle_t handle);

/**
 * Get size of block
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 * @param size                 [out] Returns the size of the block
 *
 */
sx_utils_status_t linear_manager_block_size_get(linear_manager_db_t            database,
                                                linear_manager_handle_t        handle,
                                                linear_manager_block_length_t *size);

/**
 * Lock a block in order to perform HW operations
 * Call this function to prevent relocation of the block until it is released.
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 * @param index_p             [out] Caller-provided array to be filled with indexes
 * @param size                 [in out] On input, the size of the caller's array
 *                                      Returns the actual size of the block
 */
sx_utils_status_t linear_manager_handle_lock(linear_manager_db_t            database,
                                             linear_manager_handle_t        handle,
                                             linear_manager_index_t       * index_p,
                                             linear_manager_block_length_t* size_p);

/**
 * Release a locked block, so it can be relocated again
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to block
 */
sx_utils_status_t linear_manager_handle_release(linear_manager_db_t     database,
                                                linear_manager_handle_t handle);

/**
 * Add link to block in given offset
 * This API can be called only for block of type link list
 * Before calling link add call block lock function
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to block
 * @param allocation_type      [in] the allocation type of the block
 * @param offset               [in] The offset of the new link in the linked-list
 * @param index_p             [out] filled with index for the new link
 */
sx_utils_status_t linear_manager_link_add(linear_manager_db_t               database,
                                          linear_manager_handle_t           handle,
                                          linear_manager_allocation_types_t allocation_type,
                                          linear_manager_block_length_t     offset,
                                          linear_manager_index_t          * index_p);

/**
 * Delete link from block in given offset
 * This API can be called only for block of type link list
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to block
 * @param offset               [in] The offset of link to delete in the linked-list
 */
sx_utils_status_t linear_manager_link_delete(linear_manager_db_t           database,
                                             linear_manager_handle_t       handle,
                                             linear_manager_block_length_t offset);

/**
 * Add a reference to a block, and update its relocation cost
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 */
sx_utils_status_t linear_manager_ref_add(linear_manager_db_t     database,
                                         linear_manager_handle_t handle);

/**
 * Delete a reference to a block, and update its relocation cost
 *
 * @param database             [in] A handle to a linear manager db
 * @param handle               [in] A handle to the block
 */
sx_utils_status_t linear_manager_ref_delete(linear_manager_db_t     database,
                                            linear_manager_handle_t handle);


/**
 * Swap between block indexes of 2 handles. The blocks must be of the same type.
 * If one of the blocks is of size 0, then the other block may not be referenced.
 *
 * @param database             [in] A handle to a linear manager db
 * @param first_handle         [in] A handle to a block
 * @param second_handle        [in] A handle to a block
 */
sx_utils_status_t linear_manager_swap_handles(linear_manager_db_t     database,
                                              linear_manager_handle_t first_handle,
                                              linear_manager_handle_t second_handle);

#endif /* __UTILS_LINEAR_MANAGER_H__ */
